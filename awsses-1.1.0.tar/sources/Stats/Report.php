<?php
/**
 * AWS SES — statystyki (zakładka „Statystyki”).
 *
 * collect() pobiera dane z bazy, render() buduje HTML z gotowej tablicy — bez zależności od IPS,
 * dzięki czemu obliczenia i wygląd są testowane lokalnie (tests/stats.php).
 *
 * Kolor słupków #3987e5 zwalidowany na tle ACP jasnym (#fff) i ciemnym (#2f333b), kontrast ≥ 3:1.
 * Statusy (odbicia/skargi) zawsze z ikoną i opisem, nie samym kolorem.
 *
 * @author  IQL vel Espectro
 * @package awsses
 */

namespace IPS\awsses\Stats;

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( isset( $_SERVER['SERVER_PROTOCOL'] ) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

/**
 * Stats report
 */
class _Report
{
	/**
	 * @brief	Dozwolone okresy (dni)
	 */
	const PERIODS = array( 7, 30, 90 );

	/**
	 * @brief	Etykiety zdarzeń
	 */
	const EVENT_LABELS = array(
		'send'          => 'Wysłano',
		'delivery'      => 'Dostarczono',
		'open'          => 'Otwarcie',
		'click'         => 'Kliknięcie',
		'bounce'        => 'Odbicie',
		'complaint'     => 'Skarga',
		'reject'        => 'Odrzucenie',
		'deliverydelay' => 'Opóźnienie doręczenia',
		'subscription'  => 'Subskrypcja SNS',
	);

	/* ============================================================ */
	/* Dane                                                          */
	/* ============================================================ */

	/**
	 * Zbierz dane z bazy
	 *
	 * @param	int	$days
	 * @return	array
	 */
	public static function collect( int $days ): array
	{
		$days  = \in_array( $days, static::PERIODS, TRUE ) ? $days : 30;
		$now   = \time();
		$since = $now - $days * 86400;
		$db    = \IPS\Db::i();

		$data = array(
			'days' => $days, 'now' => $now, 'since' => $since, 'noTable' => FALSE,
			'counts' => array(), 'unique' => array(), 'hardBounces' => 0, 'daily' => array(),
			'campaigns' => array(), 'links' => array(), 'bounceTypes' => array(), 'recent' => array(),
			'suppressionCount' => 0, 'suppressions' => array(), 'hasCampaigns' => FALSE,
		);

		if ( !$db->checkForTable( 'awsses_events' ) )
		{
			$data['noTable'] = TRUE;
			return $data;
		}

		$hasCampaigns = $db->checkForColumn( 'awsses_events', 'ev_campaign' );
		$data['hasCampaigns'] = $hasCampaigns;
		$where = array( 'ev_ts>?', $since );

		/* Liczby zdarzeń i unikalni odbiorcy (dla otwarć/kliknięć: unikalni per kampania) */
		$uniqueExpr = $hasCampaigns ? "COUNT(DISTINCT CONCAT(IFNULL(ev_email,''),'|',IFNULL(ev_campaign,'')))" : 'COUNT(DISTINCT ev_email)';
		foreach ( $db->select( "ev_type, COUNT(*) AS c, {$uniqueExpr} AS u", 'awsses_events', $where, NULL, NULL, 'ev_type' ) as $r )
		{
			$data['counts'][ $r['ev_type'] ] = (int) $r['c'];
			$data['unique'][ $r['ev_type'] ] = (int) $r['u'];
		}

		/* Twarde odbicia (do wskaźnika SES). Zdarzenia sprzed 1.1.0 nie mają rodzaju — liczymy je jako twarde. */
		$data['hardBounces'] = $hasCampaigns
			? (int) $db->select( 'COUNT(*)', 'awsses_events', array( "ev_type='bounce' AND ev_ts>? AND ( ev_detail IS NULL OR ev_detail LIKE 'Permanent%' )", $since ) )->first()
			: (int) ( $data['counts']['bounce'] ?? 0 );

		/* Dziennie (dni UTC) */
		foreach ( $db->select( 'FLOOR(ev_ts/86400) AS dn, ev_type, COUNT(*) AS c', 'awsses_events', $where, NULL, NULL, 'dn, ev_type' ) as $r )
		{
			$data['daily'][ (int) $r['dn'] ][ $r['ev_type'] ] = (int) $r['c'];
		}

		if ( $hasCampaigns )
		{
			/* Kampanie */
			$campaigns = array();
			foreach ( $db->select( 'ev_campaign, ev_type, COUNT(*) AS c, COUNT(DISTINCT ev_email) AS u, MAX(ev_ts) AS last', 'awsses_events', array( 'ev_ts>? AND ev_campaign IS NOT NULL', $since ), NULL, NULL, 'ev_campaign, ev_type' ) as $r )
			{
				$key = (string) $r['ev_campaign'];
				if ( !isset( $campaigns[ $key ] ) )
				{
					$campaigns[ $key ] = array( 'key' => $key, 'label' => static::campaignLabel( $key ), 'counts' => array(), 'unique' => array(), 'last' => 0 );
				}
				$campaigns[ $key ]['counts'][ $r['ev_type'] ] = (int) $r['c'];
				$campaigns[ $key ]['unique'][ $r['ev_type'] ] = (int) $r['u'];
				$campaigns[ $key ]['last'] = \max( $campaigns[ $key ]['last'], (int) $r['last'] );
			}
			\usort( $campaigns, function( $a, $b ) { return $b['last'] <=> $a['last']; } );
			foreach ( \array_slice( $campaigns, 0, 20 ) as $c )
			{
				$c['lastLabel'] = (string) \IPS\DateTime::ts( $c['last'] );
				$data['campaigns'][] = $c;
			}

			/* Najczęściej klikane linki */
			foreach ( $db->select( 'ev_detail, COUNT(*) AS c, COUNT(DISTINCT ev_email) AS u', 'awsses_events', array( "ev_type='click' AND ev_ts>? AND ev_detail IS NOT NULL", $since ), 'c DESC', 10, 'ev_detail' ) as $r )
			{
				$data['links'][] = array( 'url' => static::linkTarget( (string) $r['ev_detail'] ), 'count' => (int) $r['c'], 'unique' => (int) $r['u'] );
			}

			/* Rodzaje odbić */
			foreach ( $db->select( 'ev_detail, COUNT(*) AS c', 'awsses_events', array( "ev_type='bounce' AND ev_ts>?", $since ), 'c DESC', 10, 'ev_detail' ) as $r )
			{
				$data['bounceTypes'][] = array( 'type' => (string) ( $r['ev_detail'] ?? '' ), 'count' => (int) $r['c'] );
			}
		}

		/* Ostatnie zdarzenia */
		foreach ( $db->select( '*', 'awsses_events', $where, 'ev_id DESC', 25 ) as $r )
		{
			$data['recent'][] = array(
				'time'     => (string) \IPS\DateTime::ts( (int) $r['ev_ts'] ),
				'type'     => (string) $r['ev_type'],
				'email'    => (string) ( $r['ev_email'] ?? '' ),
				'campaign' => $hasCampaigns ? static::campaignLabel( $r['ev_campaign'] ?? NULL ) : '',
				'detail'   => $hasCampaigns ? (string) ( $r['ev_detail'] ?? '' ) : '',
			);
		}

		/* Supresja */
		if ( $db->checkForTable( 'awsses_suppressions' ) )
		{
			$data['suppressionCount'] = (int) $db->select( 'COUNT(*)', 'awsses_suppressions' )->first();
			foreach ( $db->select( '*', 'awsses_suppressions', NULL, 'sup_ts DESC', 50 ) as $r )
			{
				$data['suppressions'][] = array( 'email' => (string) $r['sup_email'], 'reason' => (string) $r['sup_reason'], 'time' => (string) \IPS\DateTime::ts( (int) $r['sup_ts'] ) );
			}
		}

		return $data;
	}

	/**
	 * Czytelna nazwa kampanii
	 *
	 * @param	string|NULL	$campaign
	 * @return	string
	 */
	public static function campaignLabel( $campaign ): string
	{
		$campaign = (string) $campaign;
		if ( $campaign === '' )                { return 'Bez znacznika (sprzed 1.1.0)'; }
		if ( $campaign === 'bulk' )            { return 'Bulk Mail'; }
		if ( $campaign === 'test' )            { return 'Test z ustawień AWS SES'; }
		if ( $campaign === 'newsletter-test' ) { return 'Test newslettera'; }
		if ( $campaign === 'mass' OR $campaign === 'other' ) { return 'Inne'; }

		if ( \preg_match( '/^newsletter-(\d+)$/', $campaign, $m ) )
		{
			$label = 'Newsletter — wydanie #' . $m[1];
			try
			{
				if ( \IPS\Application::appIsEnabled( 'newsletters' ) )
				{
					$issue = \IPS\newsletters\Issue::load( (int) $m[1] );
					$label = $issue->container()->_title . ' — ' . \IPS\DateTime::ts( (int) $issue->issue_date )->localeDate() . ' (#' . $m[1] . ')';
				}
			}
			catch ( \Throwable $e ) {}
			return $label;
		}

		return $campaign;
	}

	/**
	 * Docelowy adres linku (Newsletters opakowuje linki w ?do=click&...&src=<cel>)
	 *
	 * @param	string	$link
	 * @return	string
	 */
	public static function linkTarget( string $link ): string
	{
		$query = (string) \parse_url( $link, PHP_URL_QUERY );
		if ( $query !== '' )
		{
			\parse_str( $query, $params );
			if ( !empty( $params['src'] ) AND \is_string( $params['src'] ) )
			{
				return $params['src'];
			}
		}
		return $link;
	}

	/* ============================================================ */
	/* Obliczenia                                                    */
	/* ============================================================ */

	/**
	 * Wskaźniki i statusy
	 *
	 * @param	array	$d	wynik collect()
	 * @return	array
	 */
	public static function metrics( array $d ): array
	{
		$c = $d['counts'] ?? array();
		$u = $d['unique'] ?? array();

		$sent       = (int) ( $c['send'] ?? 0 );
		$delivered  = (int) ( $c['delivery'] ?? 0 );
		$opens      = (int) ( $u['open'] ?? 0 );
		$clicks     = (int) ( $u['click'] ?? 0 );
		$hard       = (int) ( $d['hardBounces'] ?? 0 );
		$complaints = (int) ( $c['complaint'] ?? 0 );
		$base       = $sent > 0 ? $sent : $delivered;

		$ratio = function( $a, $b ) { return $b > 0 ? $a / $b : NULL; };

		$m = array(
			'sent' => $sent, 'delivered' => $delivered, 'opens' => $opens, 'clicks' => $clicks,
			'bounces' => (int) ( $c['bounce'] ?? 0 ), 'hardBounces' => $hard, 'complaints' => $complaints,
			'rejects' => (int) ( $c['reject'] ?? 0 ), 'base' => $base,
			'deliveryRate'  => $ratio( $delivered, $sent ),
			'openRate'      => $ratio( $opens, $delivered ),
			'clickRate'     => $ratio( $clicks, $delivered ),
			'ctor'          => $ratio( $clicks, $opens ),
			'bounceRate'    => $ratio( $hard, $base ),
			'complaintRate' => $ratio( $complaints, $base ),
		);

		/* Progi SES: odbicia 5 % (uwaga) / 10 % (ryzyko blokady), skargi 0,1 % / 0,5 %. Poniżej 100 wysyłek — za mało danych. */
		$m['bounceStatus']    = static::status( $m['bounceRate'], $base, 0.05, 0.10 );
		$m['complaintStatus'] = static::status( $m['complaintRate'], $base, 0.001, 0.005 );

		return $m;
	}

	/**
	 * Status wskaźnika względem progów
	 *
	 * @return	string	good|warning|critical|neutral
	 */
	public static function status( $rate, int $base, float $warn, float $crit ): string
	{
		if ( $rate === NULL OR $base < 100 )
		{
			return 'neutral';
		}
		if ( $rate >= $crit ) { return 'critical'; }
		if ( $rate >= $warn ) { return 'warning'; }
		return 'good';
	}

	/**
	 * Seria dzienna do wykresu (pełne dni, także zerowe)
	 *
	 * @param	array	$d
	 * @return	array	[ 'metric' => 'delivery'|'send', 'days' => [ [ 'dn', 'label', 'value', 'all' => [typ => liczba] ], ... ] ]
	 */
	public static function series( array $d ): array
	{
		$daily  = $d['daily'] ?? array();
		$metric = 'delivery';
		$hasDelivery = FALSE;
		foreach ( $daily as $types ) { if ( !empty( $types['delivery'] ) ) { $hasDelivery = TRUE; break; } }
		if ( !$hasDelivery ) { $metric = 'send'; }

		$first = (int) \floor( ( (int) $d['since'] ) / 86400 ) + 1;
		$last  = (int) \floor( ( (int) $d['now'] ) / 86400 );
		$days  = array();
		for ( $dn = $first; $dn <= $last; $dn++ )
		{
			$all = $daily[ $dn ] ?? array();
			$days[] = array( 'dn' => $dn, 'label' => \gmdate( 'd.m', $dn * 86400 ), 'value' => (int) ( $all[ $metric ] ?? 0 ), 'all' => $all );
		}
		return array( 'metric' => $metric, 'days' => $days );
	}

	/* ============================================================ */
	/* HTML                                                          */
	/* ============================================================ */

	protected static function e( $v ): string { return \htmlspecialchars( (string) $v, ENT_QUOTES, 'UTF-8' ); }
	protected static function n( $v ): string { return \number_format( (float) $v, 0, ',', ' ' ); }
	protected static function pct( $r ): string { return $r === NULL ? '—' : \number_format( $r * 100, $r < 0.01 && $r > 0 ? 2 : 1, ',', ' ' ) . ' %'; }

	/**
	 * Zbuduj HTML zakładki
	 *
	 * @param	array	$d			wynik collect()
	 * @param	array	$periodUrls	[ dni => url ]
	 * @return	string
	 */
	public static function render( array $d, array $periodUrls = array() ): string
	{
		$h  = static::css();
		$h .= "<div class='awsses-stats'>";

		/* Okres */
		$h .= "<div class='ast-head'><h3>Zdarzenia SES</h3><div class='ast-periods' role='group' aria-label='Okres'>";
		foreach ( static::PERIODS as $p )
		{
			$active = ( (int) $d['days'] === $p );
			$label  = ( $active ? '✓ ' : '' ) . "{$p} dni";
			$url    = $periodUrls[ $p ] ?? '#';
			$h .= "<a href='" . static::e( $url ) . "'" . ( $active ? " class='ast-active' aria-current='true'" : '' ) . ">" . static::e( $label ) . "</a>";
		}
		$h .= "</div></div>";

		if ( !empty( $d['noTable'] ) )
		{
			return $h . "<p>Brak tabeli zdarzeń — przeinstaluj aplikację.</p></div>";
		}

		$m = static::metrics( $d );

		/* Podpowiedzi konfiguracyjne */
		if ( $m['sent'] === 0 AND $m['delivered'] === 0 )
		{
			$h .= "<div class='ast-note'><strong>Brak zdarzeń „Wysłane” i „Dostarczone”.</strong> W AWS → SES → Configuration sets → Twój zestaw → Event destinations: cel Amazon SNS musi mieć zaznaczone <em>Sends</em> i <em>Deliveries</em> (oraz <em>Opens</em>, <em>Clicks</em>) i wskazywać temat z subskrypcją tej aplikacji. Statystyki liczą tylko maile wysłane przez SES.</div>";
		}

		/* KPI */
		$h .= "<div class='ast-kpis'>";
		$h .= static::kpi( static::n( $m['sent'] ), 'Wysłane', $m['sent'] ? '' : 'brak zdarzeń Send' );
		$h .= static::kpi( static::n( $m['delivered'] ), 'Dostarczone', 'doręczalność ' . static::pct( $m['deliveryRate'] ) );
		$h .= static::kpi( static::n( $m['opens'] ), 'Otwarcia (unikalne)', 'wskaźnik otwarć ' . static::pct( $m['openRate'] ) );
		$h .= static::kpi( static::n( $m['clicks'] ), 'Kliknięcia (unikalne)', 'CTR ' . static::pct( $m['clickRate'] ) . ' · CTOR ' . static::pct( $m['ctor'] ) );
		$h .= static::kpi( static::n( $m['hardBounces'] ), 'Odbicia twarde', static::badge( $m['bounceStatus'], static::pct( $m['bounceRate'] ) . ' (próg AWS 5 %)' ) . ( $m['bounces'] > $m['hardBounces'] ? ' · miękkie: ' . static::n( $m['bounces'] - $m['hardBounces'] ) : '' ) );
		$h .= static::kpi( static::n( $m['complaints'] ), 'Skargi (spam)', static::badge( $m['complaintStatus'], static::pct( $m['complaintRate'] ) . ' (próg AWS 0,1 %)' ) );
		$h .= "</div>";

		/* Wykres dzienny */
		$h .= static::chart( static::series( $d ) );

		/* Kampanie */
		$h .= "<h3>Kampanie i wydania newslettera</h3>";
		if ( empty( $d['hasCampaigns'] ) )
		{
			$h .= "<p class='ast-muted'>Dokończ aktualizację aplikacji do 1.1.0 — zestawienie kampanii wymaga nowych kolumn w bazie.</p>";
		}
		elseif ( empty( $d['campaigns'] ) )
		{
			$h .= "<p class='ast-muted'>Brak wysyłek ze znacznikiem kampanii w tym okresie. Pojawią się przy następnej wysyłce przez SES (od wersji 1.1.0 każdy mail dostaje znacznik).</p>";
		}
		else
		{
			$h .= "<div class='ast-scroll'><table class='ipsTable ast-table'><thead><tr><th>Kampania</th><th>Wysłane</th><th>Dostarczone</th><th>Otwarcia</th><th>Kliknięcia</th><th>Odbicia</th><th>Skargi</th><th>Ostatnie zdarzenie</th></tr></thead><tbody>";
			foreach ( $d['campaigns'] as $c )
			{
				$cc = $c['counts']; $cu = $c['unique'];
				$del = (int) ( $cc['delivery'] ?? 0 );
				$op  = (int) ( $cu['open'] ?? 0 );
				$cl  = (int) ( $cu['click'] ?? 0 );
				$h .= "<tr><td>" . static::e( $c['label'] ) . "</td>"
					. "<td>" . static::n( $cc['send'] ?? 0 ) . "</td>"
					. "<td>" . static::n( $del ) . "</td>"
					. "<td>" . static::n( $op ) . " <span class='ast-muted'>(" . static::pct( $del ? $op / $del : NULL ) . ")</span></td>"
					. "<td>" . static::n( $cl ) . " <span class='ast-muted'>(" . static::pct( $del ? $cl / $del : NULL ) . ")</span></td>"
					. "<td>" . static::n( $cc['bounce'] ?? 0 ) . "</td>"
					. "<td>" . static::n( $cc['complaint'] ?? 0 ) . "</td>"
					. "<td class='ast-muted'>" . static::e( $c['lastLabel'] ?? '' ) . "</td></tr>";
			}
			$h .= "</tbody></table></div>";
		}

		/* Linki i odbicia obok siebie */
		$h .= "<div class='ast-two'>";

		$h .= "<div><h3>Najczęściej klikane linki</h3>";
		if ( empty( $d['links'] ) )
		{
			$h .= "<p class='ast-muted'>Brak kliknięć w tym okresie.</p>";
		}
		else
		{
			$max = \max( \array_column( $d['links'], 'count' ) ) ?: 1;
			$h .= "<ul class='ast-meters'>";
			foreach ( $d['links'] as $l )
			{
				$w = \max( 2, (int) \round( $l['count'] / $max * 100 ) );
				$h .= "<li><div class='ast-meter-name' title='" . static::e( $l['url'] ) . "'>" . static::e( $l['url'] ) . "</div>"
					. "<div class='ast-meter-row'><div class='ast-meter'><span style='width:{$w}%'></span></div>"
					. "<div class='ast-meter-val'>" . static::n( $l['count'] ) . " <span class='ast-muted'>(" . static::n( $l['unique'] ) . " os.)</span></div></div></li>";
			}
			$h .= "</ul>";
		}
		$h .= "</div>";

		$h .= "<div><h3>Rodzaje odbić</h3>";
		if ( empty( $d['bounceTypes'] ) )
		{
			$h .= "<p class='ast-muted'>Brak odbić w tym okresie.</p>";
		}
		else
		{
			$h .= "<table class='ipsTable ast-table'><thead><tr><th>Rodzaj</th><th>Liczba</th></tr></thead><tbody>";
			foreach ( $d['bounceTypes'] as $b )
			{
				$type = $b['type'] !== '' ? $b['type'] : 'nieznany (sprzed 1.1.0)';
				$hint = \stripos( $type, 'Permanent' ) === 0 ? ' — twarde, adres trafia na listę supresji' : ( \stripos( $type, 'Transient' ) === 0 ? ' — miękkie, chwilowe' : '' );
				$h .= "<tr><td>" . static::e( $type ) . "<span class='ast-muted'>" . static::e( $hint ) . "</span></td><td>" . static::n( $b['count'] ) . "</td></tr>";
			}
			$h .= "</tbody></table>";
		}
		$h .= "</div></div>";

		/* Ostatnie zdarzenia */
		$h .= "<h3>Ostatnie zdarzenia</h3>";
		if ( empty( $d['recent'] ) )
		{
			$h .= "<p class='ast-muted'>Brak zdarzeń w tym okresie.</p>";
		}
		else
		{
			$h .= "<div class='ast-scroll'><table class='ipsTable ast-table'><thead><tr><th>Czas</th><th>Zdarzenie</th><th>Adres</th><th>Kampania</th><th>Szczegół</th></tr></thead><tbody>";
			foreach ( $d['recent'] as $r )
			{
				$h .= "<tr><td class='ast-nowrap'>" . static::e( $r['time'] ) . "</td><td>" . static::e( static::EVENT_LABELS[ $r['type'] ] ?? $r['type'] ) . "</td><td>" . static::e( $r['email'] ) . "</td><td>" . static::e( $r['campaign'] ) . "</td><td class='ast-break'>" . static::e( $r['type'] === 'click' ? static::linkTarget( $r['detail'] ) : $r['detail'] ) . "</td></tr>";
			}
			$h .= "</tbody></table></div>";
		}

		/* Supresja */
		$h .= "<details class='ast-details'><summary>Lista supresji: " . static::n( $d['suppressionCount'] ?? 0 ) . " adres(ów) — adresy po twardym odbiciu lub skardze, pomijane przy wysyłce</summary>";
		if ( !empty( $d['suppressions'] ) )
		{
			$h .= "<table class='ipsTable ast-table'><thead><tr><th>Adres</th><th>Powód</th><th>Data</th></tr></thead><tbody>";
			foreach ( $d['suppressions'] as $s )
			{
				$h .= "<tr><td>" . static::e( $s['email'] ) . "</td><td>" . static::e( $s['reason'] === 'complaint' ? 'skarga' : 'twarde odbicie' ) . "</td><td>" . static::e( $s['time'] ) . "</td></tr>";
			}
			$h .= "</tbody></table>";
		}
		$h .= "</details>";

		$h .= "</div>";
		return $h;
	}

	/**
	 * Kafelek KPI
	 */
	protected static function kpi( string $value, string $label, string $sub ): string
	{
		return "<div class='ast-kpi'><div class='ast-kpi-v'>{$value}</div><div class='ast-kpi-l'>" . static::e( $label ) . "</div>"
			. ( $sub !== '' ? "<div class='ast-kpi-s'>{$sub}</div>" : '' ) . "</div>";
	}

	/**
	 * Znaczek statusu — ikona + opis + kolor (nigdy sam kolor)
	 */
	protected static function badge( string $status, string $text ): string
	{
		$map = array(
			'good'     => array( '✓', 'OK', 'var(--ast-good)' ),
			'warning'  => array( '!', 'Uwaga', 'var(--ast-warn)' ),
			'critical' => array( '✕', 'Krytycznie', 'var(--ast-crit)' ),
			'neutral'  => array( '·', 'Za mało danych', 'currentColor' ),
		);
		list( $icon, $label, $color ) = $map[ $status ] ?? $map['neutral'];
		return "<span class='ast-badge'><span class='ast-badge-i' style='color:{$color}' aria-hidden='true'>{$icon}</span>"
			. static::e( $label ) . "</span> <span class='ast-muted'>" . static::e( $text ) . "</span>";
	}

	/**
	 * Wykres słupkowy dzienny (jedna seria, podpowiedź po najechaniu, widok tabeli)
	 */
	protected static function chart( array $series ): string
	{
		$days   = $series['days'];
		$name   = $series['metric'] === 'delivery' ? 'Dostarczone' : 'Wysłane';
		$count  = \count( $days );
		$max    = 0;
		foreach ( $days as $day ) { $max = \max( $max, $day['value'] ); }
		$scale  = $max > 0 ? $max : 1;
		$every  = $count <= 10 ? 1 : ( $count <= 31 ? 5 : 15 );

		$h  = "<h3>{$name} dziennie</h3>";
		$h .= "<div class='ast-chart-wrap'><div class='ast-yaxis'><span>" . static::n( $max ) . "</span><span>" . static::n( $max / 2 ) . "</span><span>0</span></div>";
		$h .= "<div class='ast-chart' role='img' aria-label='" . static::e( "{$name} dziennie, maksimum " . static::n( $max ) ) . "'>";
		$h .= "<div class='ast-grid' style='top:0'></div><div class='ast-grid' style='top:50%'></div>";

		foreach ( $days as $i => $day )
		{
			$pctH = $day['value'] > 0 ? \max( 2, \round( $day['value'] / $scale * 100, 1 ) ) : 0;
			$edge = $i < 3 ? ' ast-tip-l' : ( $i >= $count - 3 ? ' ast-tip-r' : '' );
			$tip  = "<strong>" . static::e( $day['label'] ) . "</strong>";
			foreach ( array( 'send', 'delivery', 'open', 'click', 'bounce', 'complaint' ) as $t )
			{
				$tip .= "<span>" . static::e( static::EVENT_LABELS[ $t ] ) . ": " . static::n( $day['all'][ $t ] ?? 0 ) . "</span>";
			}
			$h .= "<div class='ast-col' tabindex='0'><div class='ast-bar' style='height:{$pctH}%'></div><div class='ast-tip{$edge}'>{$tip}</div></div>";
		}
		$h .= "</div></div>";

		$h .= "<div class='ast-xaxis'>";
		foreach ( $days as $i => $day )
		{
			$show = ( $i % $every === 0 ) || ( $i === $count - 1 );
			$h .= "<span>" . ( $show ? static::e( $day['label'] ) : '' ) . "</span>";
		}
		$h .= "</div>";

		/* Widok tabeli */
		$h .= "<details class='ast-details'><summary>Pokaż tabelę dzienną</summary><div class='ast-scroll'><table class='ipsTable ast-table'><thead><tr><th>Dzień (UTC)</th>";
		foreach ( array( 'send', 'delivery', 'open', 'click', 'bounce', 'complaint' ) as $t ) { $h .= "<th>" . static::e( static::EVENT_LABELS[ $t ] ) . "</th>"; }
		$h .= "</tr></thead><tbody>";
		foreach ( \array_reverse( $days ) as $day )
		{
			$h .= "<tr><td>" . static::e( \gmdate( 'Y-m-d', $day['dn'] * 86400 ) ) . "</td>";
			foreach ( array( 'send', 'delivery', 'open', 'click', 'bounce', 'complaint' ) as $t ) { $h .= "<td>" . static::n( $day['all'][ $t ] ?? 0 ) . "</td>"; }
			$h .= "</tr>";
		}
		$h .= "</tbody></table></div></details>";

		return $h;
	}

	/**
	 * Style (zakres .awsses-stats). Tekst dziedziczy kolor ACP — działa w jasnym i ciemnym motywie.
	 */
	protected static function css(): string
	{
		return "<style>
.awsses-stats{--ast-bar:#3987e5;--ast-good:#0ca30c;--ast-warn:#fab219;--ast-crit:#d03b3b;--ast-line:rgba(128,128,128,.28);--ast-soft:rgba(128,128,128,.12)}
.awsses-stats h3{margin:22px 0 10px}
.awsses-stats .ast-head{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}
.awsses-stats .ast-head h3{margin:6px 0}
.awsses-stats .ast-periods{display:inline-flex;border:1px solid var(--ast-line);border-radius:6px;overflow:hidden}
.awsses-stats .ast-periods a{padding:6px 12px;text-decoration:none;color:inherit;border-left:1px solid var(--ast-line)}
.awsses-stats .ast-periods a:first-child{border-left:0}
.awsses-stats .ast-periods a:hover{background:var(--ast-soft)}
.awsses-stats .ast-periods a.ast-active{font-weight:700;background:var(--ast-soft)}
.awsses-stats .ast-note{border:1px solid var(--ast-line);border-left:4px solid var(--ast-warn);border-radius:6px;padding:10px 14px;margin:10px 0}
.awsses-stats .ast-kpis{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:12px;margin:12px 0 8px}
.awsses-stats .ast-kpi{border:1px solid var(--ast-line);border-radius:8px;padding:12px 14px}
.awsses-stats .ast-kpi-v{font-size:28px;font-weight:700;line-height:1.1}
.awsses-stats .ast-kpi-l{opacity:.8;font-size:13px;margin-top:2px}
.awsses-stats .ast-kpi-s{font-size:12px;margin-top:8px;line-height:1.5}
.awsses-stats .ast-badge{font-weight:700;white-space:nowrap}
.awsses-stats .ast-badge-i{font-weight:700;margin-right:3px}
.awsses-stats .ast-muted{opacity:.7}
.awsses-stats .ast-chart-wrap{display:flex;gap:8px;align-items:stretch}
.awsses-stats .ast-yaxis{display:flex;flex-direction:column;justify-content:space-between;font-size:11px;opacity:.7;text-align:right;min-width:28px;font-variant-numeric:tabular-nums}
.awsses-stats .ast-chart{position:relative;flex:1;height:180px;display:flex;align-items:stretch;gap:2px;border-bottom:1px solid var(--ast-line)}
.awsses-stats .ast-grid{position:absolute;left:0;right:0;border-top:1px dashed var(--ast-line);pointer-events:none}
.awsses-stats .ast-col{position:relative;flex:1;min-width:3px;display:flex;align-items:flex-end;outline:none}
.awsses-stats .ast-col:hover,.awsses-stats .ast-col:focus{background:var(--ast-soft)}
.awsses-stats .ast-bar{width:100%;background:var(--ast-bar);border-radius:4px 4px 0 0}
.awsses-stats .ast-tip{display:none;position:absolute;top:4px;left:50%;transform:translateX(-50%);z-index:5;background:rgba(20,20,22,.94);color:#fff;border-radius:6px;padding:8px 10px;font-size:12px;line-height:1.55;white-space:nowrap;box-shadow:0 4px 14px rgba(0,0,0,.35)}
.awsses-stats .ast-tip span,.awsses-stats .ast-tip strong{display:block}
.awsses-stats .ast-tip.ast-tip-l{left:0;transform:none}
.awsses-stats .ast-tip.ast-tip-r{left:auto;right:0;transform:none}
.awsses-stats .ast-col:hover .ast-tip,.awsses-stats .ast-col:focus .ast-tip{display:block}
.awsses-stats .ast-xaxis{display:flex;gap:2px;margin-left:36px;font-size:11px;opacity:.7;font-variant-numeric:tabular-nums}
.awsses-stats .ast-xaxis span{flex:1;min-width:3px;white-space:nowrap;overflow:visible}
.awsses-stats .ast-details{margin:10px 0}
.awsses-stats .ast-details summary{cursor:pointer;opacity:.85}
.awsses-stats .ast-scroll{overflow-x:auto}
.awsses-stats .ast-table td,.awsses-stats .ast-table th{white-space:nowrap}
.awsses-stats .ast-table td.ast-break{white-space:normal;word-break:break-all;max-width:420px}
.awsses-stats .ast-two{display:grid;grid-template-columns:1fr 1fr;gap:24px}
@media (max-width:900px){.awsses-stats .ast-two{grid-template-columns:1fr}}
.awsses-stats .ast-meters{list-style:none;margin:0;padding:0}
.awsses-stats .ast-meters li{margin:0 0 10px}
.awsses-stats .ast-meter-name{font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.awsses-stats .ast-meter-row{display:flex;align-items:center;gap:8px;margin-top:3px}
.awsses-stats .ast-meter{flex:1;height:8px;background:var(--ast-soft);border-radius:4px;overflow:hidden}
.awsses-stats .ast-meter span{display:block;height:100%;background:var(--ast-bar);border-radius:4px}
.awsses-stats .ast-meter-val{font-size:12px;white-space:nowrap;font-variant-numeric:tabular-nums}
.awsses-stats .ast-nowrap{white-space:nowrap}
</style>";
	}
}
