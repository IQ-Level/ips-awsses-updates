//<?php

/**
 * AWS SES Integration — hook supresji (code hook na \IPS\Email).
 *
 * Nadpisuje emailIsBlocked(): adres z listy supresji (twarde bounce / complaint z SNS)
 * jest zablokowany. Zabezpieczenie dodatkowe — główną egzekucję zapewnia allow_admin_mails=0
 * ustawiane przez endpoint SNS (filtr Bulk Mail / newsletterów).
 *
 * @author  IQL vel Espectro
 * @package awsses
 */

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	exit;
}

class awsses_hook_SesBlocked extends _HOOK_CLASS_
{
	/**
	 * Czy adres jest zablokowany?
	 *
	 * @param	string		$email
	 * @param	string|null	$type
	 * @return	bool
	 */
	public static function emailIsBlocked( string $email, ?string $type = null ) : bool
	{
		try
		{
			if ( \IPS\awsses\Suppression::isSuppressed( $email ) )
			{
				return TRUE;
			}
		}
		catch ( \Error | \RuntimeException $e )
		{
			if ( \defined( '\IPS\DEBUG_HOOKS' ) AND \IPS\DEBUG_HOOKS )
			{
				\IPS\Log::log( $e, 'hook_exception' );
			}
		}

		return \call_user_func_array( 'parent::emailIsBlocked', \func_get_args() );
	}
}
