//<?php

/**
 * AWS SES Integration — routing hook (code hook na \IPS\Email).
 *
 * Nadpisuje factory($type): dla Bulk Mail i newsletterów zwraca transport SES,
 * reszta (transakcyjne) leci dalej przez parent::factory() (SMTP).
 * Wzorzec 1:1 z applications/newsletters/hooks/NewsletterEmail.php.
 *
 * @author  IQL vel Espectro
 * @package awsses
 */

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	exit;
}

class awsses_hook_SesFactory extends _HOOK_CLASS_
{
	/**
	 * Factory
	 *
	 * @param	string	$type	transactional / list / bulk / newsletter
	 * @return	\IPS\Email
	 */
	protected static function factory( $type )
	{
		try
		{
			if ( \IPS\Settings::i()->awsses_enabled AND static::awssesConfigured() )
			{
				if ( $type === \IPS\Email::TYPE_BULK AND \IPS\Settings::i()->awsses_route_bulk )
				{
					return static::awssesHandler();
				}
				if ( $type === 'newsletter' AND \IPS\Settings::i()->awsses_route_newsletter )
				{
					return static::awssesHandler();
				}
			}

			return \call_user_func_array( 'parent::factory', \func_get_args() );
		}
		catch ( \Error | \RuntimeException $e )
		{
			if ( \defined( '\IPS\DEBUG_HOOKS' ) AND \IPS\DEBUG_HOOKS )
			{
				\IPS\Log::log( $e, 'hook_exception' );
			}

			if ( method_exists( get_parent_class(), __FUNCTION__ ) )
			{
				return \call_user_func_array( 'parent::' . __FUNCTION__, \func_get_args() );
			}
			else
			{
				throw $e;
			}
		}
	}

	/**
	 * Czy SES ma minimalną konfigurację?
	 *
	 * @return	bool
	 */
	protected static function awssesConfigured(): bool
	{
		if ( !\IPS\Settings::i()->awsses_region )
		{
			return FALSE;
		}

		if ( \IPS\Settings::i()->awsses_mode === 'api' )
		{
			return (bool) ( \IPS\Settings::i()->awsses_access_key AND \IPS\Settings::i()->awsses_secret_key );
		}

		return (bool) ( \IPS\Settings::i()->awsses_smtp_user AND \IPS\Settings::i()->awsses_smtp_pass );
	}

	/**
	 * Zbuduj transport SES wg wybranego trybu.
	 *
	 * @return	\IPS\Email
	 */
	protected static function awssesHandler(): \IPS\Email
	{
		$region = \IPS\Settings::i()->awsses_region;

		/* Tryb API v2 (SigV4) — klasa autoloadowana z sources/Api/Api.php */
		if ( \IPS\Settings::i()->awsses_mode === 'api' )
		{
			return new \IPS\awsses\Api\Api();
		}

		/* Tryb SMTP — rdzeniowy transport wskazany na endpoint SES */
		return new \IPS\Email\Outgoing\Smtp(
			'tls',
			static::smtpHost(),
			587,
			\IPS\Settings::i()->awsses_smtp_user,
			\IPS\Settings::i()->awsses_smtp_pass
		);
	}

	/**
	 * Host SMTP: własny (awsses_smtp_host) albo domyślny email-smtp.<region>.amazonaws.com.
	 *
	 * @return	string
	 */
	public static function smtpHost(): string
	{
		$custom = \trim( (string) \IPS\Settings::i()->awsses_smtp_host );
		if ( $custom !== '' )
		{
			return $custom;
		}
		return 'email-smtp.' . \IPS\Settings::i()->awsses_region . '.amazonaws.com';
	}

	/**
	 * Wysyłka testowa PRZEZ SES — niezależna od przełączników routingu.
	 * Metoda w podklasie \IPS\Email, więc ma dostęp do chronionych właściwości transportu.
	 *
	 * @param	string	$to
	 * @param	string	$subject
	 * @param	string	$html
	 * @return	void
	 * @throws	\IPS\Email\Outgoing\Exception
	 */
	public static function awssesSendTest( string $to, string $subject, string $html )
	{
		$from = \IPS\Settings::i()->awsses_from ?: \IPS\Settings::i()->email_out;

		$handler = static::awssesHandler();
		$handler->type             = \IPS\Email::TYPE_TRANSACTIONAL;
		$handler->subject          = $subject;
		$handler->htmlContent      = $html;
		$handler->plaintextContent = \IPS\Email::buildPlaintextBody( $html );
		$handler->useWrapper       = \IPS\Email::WRAPPER_NONE;

		$handler->_send( $to, array(), array(), $from ?: NULL );
	}
}
