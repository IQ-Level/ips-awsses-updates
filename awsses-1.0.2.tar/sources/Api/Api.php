<?php
/**
 * AWS SES — transport przez API v2 (SigV4).
 *
 * Dziedziczy po Smtp dla metod kompilacji treści/MIME (compileFullEmail, _parseRecipients),
 * ale wysyłkę nadpisuje na HTTPS API: POST /v2/email/outbound-emails (tryb Raw — zachowuje
 * nagłówki List-Unsubscribe i tracking).
 *
 * @author  IQL vel Espectro
 * @package awsses
 */

namespace IPS\awsses\Api;

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( isset( $_SERVER['SERVER_PROTOCOL'] ) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

/**
 * SES API v2 transport
 */
class _Api extends \IPS\Email\Outgoing\Smtp
{
	/** @var string */
	protected $region;
	/** @var string */
	protected $accessKey;
	/** @var string */
	protected $secretKey;
	/** @var string */
	protected $configurationSet;
	/** @var string */
	protected $apiLog = '';

	/**
	 * Konstruktor — czyta ustawienia SES.
	 */
	public function __construct()
	{
		$this->region           = \IPS\Settings::i()->awsses_region;
		$this->accessKey        = \IPS\Settings::i()->awsses_access_key;
		$this->secretKey        = \IPS\Settings::i()->awsses_secret_key;
		$this->configurationSet = \IPS\Settings::i()->awsses_configuration_set;

		$host = \trim( (string) \IPS\Settings::i()->awsses_smtp_host ) ?: "email-smtp.{$this->region}.amazonaws.com";
		parent::__construct( 'tls', $host, 587, \IPS\Settings::i()->awsses_smtp_user, \IPS\Settings::i()->awsses_smtp_pass );
	}

	/**
	 * Wyślij pojedynczą wiadomość przez SES API v2 (Raw).
	 *
	 * @param	mixed	$to
	 * @param	mixed	$cc
	 * @param	mixed	$bcc
	 * @param	mixed	$fromEmail
	 * @param	mixed	$fromName
	 * @param	array	$additionalHeaders
	 * @return	void
	 * @throws	\IPS\Email\Outgoing\Exception
	 */
	public function _send( $to, $cc = array(), $bcc = array(), $fromEmail = NULL, $fromName = NULL, $additionalHeaders = array() )
	{
		$fromEmail = $fromEmail ?: \IPS\Settings::i()->email_out;

		if ( empty( $additionalHeaders['Message-ID'] ) )
		{
			$additionalHeaders['Message-ID'] = $this->generateMessageId();
		}

		$rawMime = $this->compileFullEmail( $to, $cc, array(), $fromEmail, $fromName, $additionalHeaders );

		$dest = array( 'ToAddresses' => $this->_addrList( $to ) );
		if ( $cc )  { $dest['CcAddresses']  = $this->_addrList( $cc ); }
		if ( $bcc ) { $dest['BccAddresses'] = $this->_addrList( $bcc ); }

		$body = array(
			'FromEmailAddress' => $fromEmail,
			'Destination'      => $dest,
			'Content'          => array( 'Raw' => array( 'Data' => \base64_encode( $rawMime ) ) ),
		);
		if ( $this->configurationSet )
		{
			$body['ConfigurationSetName'] = $this->configurationSet;
		}

		$payload  = \json_encode( $body );
		$response = $this->_signedRequest( 'POST', '/v2/email/outbound-emails', $payload );

		$code = $response->httpResponseCode;
		if ( (int) $code < 200 OR (int) $code >= 300 )
		{
			$decoded = @$response->decodeJson();
			$message = ( \is_array( $decoded ) AND isset( $decoded['message'] ) ) ? $decoded['message'] : ( 'HTTP ' . $code );
			throw new \IPS\Email\Outgoing\Exception( $message, (int) $code );
		}
	}

	/**
	 * Odbiorcy -> lista adresów.
	 *
	 * @param	mixed	$data
	 * @return	array
	 */
	protected function _addrList( $data ): array
	{
		$flat = static::_parseRecipients( $data, TRUE );
		$out  = array();
		foreach ( \explode( ',', $flat ) as $a )
		{
			$a = \trim( $a );
			if ( $a !== '' ) { $out[] = $a; }
		}
		return \array_values( \array_unique( $out ) );
	}

	/**
	 * Podpisane (SigV4) żądanie POST do SES API v2.
	 *
	 * @param	string	$method
	 * @param	string	$path
	 * @param	string	$payload
	 * @return	\IPS\Http\Response
	 * @throws	\IPS\Email\Outgoing\Exception
	 */
	protected function _signedRequest( string $method, string $path, string $payload )
	{
		if ( !$this->region OR !$this->accessKey OR !$this->secretKey )
		{
			throw new \IPS\Email\Outgoing\Exception( 'awsses_api_not_configured' );
		}

		$service = 'ses';
		$host    = "email.{$this->region}.amazonaws.com";
		$url     = "https://{$host}{$path}";

		$amzDate   = \gmdate( 'Ymd\THis\Z' );
		$dateStamp = \gmdate( 'Ymd' );
		$hashedPayload = \hash( 'sha256', $payload );

		$canonicalHeaders = "content-type:application/json\n"
			. "host:{$host}\n"
			. "x-amz-content-sha256:{$hashedPayload}\n"
			. "x-amz-date:{$amzDate}\n";
		$signedHeaders = 'content-type;host;x-amz-content-sha256;x-amz-date';

		$canonicalRequest = $method . "\n" . $path . "\n" . '' . "\n"
			. $canonicalHeaders . "\n" . $signedHeaders . "\n" . $hashedPayload;

		$scope = "{$dateStamp}/{$this->region}/{$service}/aws4_request";
		$stringToSign = "AWS4-HMAC-SHA256\n{$amzDate}\n{$scope}\n" . \hash( 'sha256', $canonicalRequest );

		$kDate    = \hash_hmac( 'sha256', $dateStamp, 'AWS4' . $this->secretKey, TRUE );
		$kRegion  = \hash_hmac( 'sha256', $this->region, $kDate, TRUE );
		$kService = \hash_hmac( 'sha256', $service, $kRegion, TRUE );
		$kSigning = \hash_hmac( 'sha256', 'aws4_request', $kService, TRUE );
		$signature = \hash_hmac( 'sha256', $stringToSign, $kSigning );

		$authorization = "AWS4-HMAC-SHA256 "
			. "Credential={$this->accessKey}/{$scope}, "
			. "SignedHeaders={$signedHeaders}, "
			. "Signature={$signature}";

		$this->apiLog = "POST {$url}\nx-amz-date: {$amzDate}\nSignedHeaders: {$signedHeaders}\n";

		try
		{
			$req = \IPS\Http\Url::external( $url )
				->request( \IPS\LONG_REQUEST_TIMEOUT )
				->setHeaders( array(
					'Content-Type'         => 'application/json',
					'X-Amz-Date'           => $amzDate,
					'X-Amz-Content-Sha256' => $hashedPayload,
					'Authorization'        => $authorization,
				) );

			return $req->post( $payload );
		}
		catch ( \IPS\Http\Request\Exception $e )
		{
			throw new \IPS\Email\Outgoing\Exception( $e->getMessage() );
		}
	}

	/**
	 * Lekki, podpisany GET (diagnostyka, np. /v2/email/account).
	 *
	 * @param	string	$path
	 * @return	array|NULL
	 */
	public function apiGet( string $path )
	{
		$service = 'ses';
		$host    = "email.{$this->region}.amazonaws.com";
		$url     = "https://{$host}{$path}";
		$amzDate   = \gmdate( 'Ymd\THis\Z' );
		$dateStamp = \gmdate( 'Ymd' );
		$hashedPayload = \hash( 'sha256', '' );

		$canonicalHeaders = "host:{$host}\n"
			. "x-amz-content-sha256:{$hashedPayload}\n"
			. "x-amz-date:{$amzDate}\n";
		$signedHeaders = 'host;x-amz-content-sha256;x-amz-date';
		$canonicalRequest = "GET\n" . $path . "\n\n" . $canonicalHeaders . "\n" . $signedHeaders . "\n" . $hashedPayload;

		$scope = "{$dateStamp}/{$this->region}/{$service}/aws4_request";
		$stringToSign = "AWS4-HMAC-SHA256\n{$amzDate}\n{$scope}\n" . \hash( 'sha256', $canonicalRequest );

		$kDate    = \hash_hmac( 'sha256', $dateStamp, 'AWS4' . $this->secretKey, TRUE );
		$kRegion  = \hash_hmac( 'sha256', $this->region, $kDate, TRUE );
		$kService = \hash_hmac( 'sha256', $service, $kRegion, TRUE );
		$kSigning = \hash_hmac( 'sha256', 'aws4_request', $kService, TRUE );
		$signature = \hash_hmac( 'sha256', $stringToSign, $kSigning );

		$authorization = "AWS4-HMAC-SHA256 Credential={$this->accessKey}/{$scope}, SignedHeaders={$signedHeaders}, Signature={$signature}";

		$response = \IPS\Http\Url::external( $url )
			->request( \IPS\LONG_REQUEST_TIMEOUT )
			->setHeaders( array(
				'X-Amz-Date'           => $amzDate,
				'X-Amz-Content-Sha256' => $hashedPayload,
				'Authorization'        => $authorization,
			) )
			->get();

		return @$response->decodeJson();
	}

	/**
	 * Log do core_mail_error_logs (mlog_smtp_log).
	 *
	 * @return	string
	 */
	public function getLog()
	{
		return $this->apiLog;
	}
}
