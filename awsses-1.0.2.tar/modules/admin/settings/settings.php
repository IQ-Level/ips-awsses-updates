<?php
/**
 * AWS SES Integration — kontroler ustawień ACP.
 *
 * Zakładki: Połączenie, Routing, Diagnostyka, Statystyki.
 * Test wysyłki to OSOBNA akcja (do=test) — żadnych zagnieżdżonych <form> w formularzu ustawień.
 *
 * @author  IQL vel Espectro
 * @package awsses
 */

namespace IPS\awsses\modules\admin\settings;

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( isset( $_SERVER['SERVER_PROTOCOL'] ) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

/**
 * settings
 */
class _settings extends \IPS\Dispatcher\Controller
{
	/**
	 * Execute
	 *
	 * @return	void
	 */
	public function execute()
	{
		\IPS\Dispatcher::i()->checkAcpPermission( 'settings_manage' );
		parent::execute();
	}

	/**
	 * Regiony SES
	 *
	 * @return	array
	 */
	protected function sesRegions(): array
	{
		return array(
			'eu-central-1' => 'Europe (Frankfurt) — eu-central-1',
			'eu-west-1'    => 'Europe (Ireland) — eu-west-1',
			'eu-west-2'    => 'Europe (London) — eu-west-2',
			'eu-north-1'   => 'Europe (Stockholm) — eu-north-1',
			'eu-south-1'   => 'Europe (Milan) — eu-south-1',
			'us-east-1'    => 'US East (N. Virginia) — us-east-1',
			'us-east-2'    => 'US East (Ohio) — us-east-2',
			'us-west-2'    => 'US West (Oregon) — us-west-2',
		);
	}

	/**
	 * Parsuj CSV poświadczeń SMTP z AWS → [host, user, pass] albo NULL.
	 *
	 * @param	string	$text
	 * @return	array|NULL
	 */
	public static function parseAwsCsv( string $text )
	{
		$lines = \preg_split( '/\r\n|\r|\n/', \trim( $text ) );
		$lines = \array_values( \array_filter( \array_map( 'trim', $lines ), function( $l ) { return $l !== ''; } ) );
		if ( !$lines ) { return NULL; }

		$header = NULL;
		$data   = NULL;
		foreach ( $lines as $l )
		{
			$cols = \str_getcsv( $l );
			if ( $header === NULL AND ( \stripos( $l, 'Username' ) !== FALSE OR \stripos( $l, 'SMTP Endpoint' ) !== FALSE OR \stripos( $l, 'Access Key' ) !== FALSE ) )
			{
				$header = \array_map( 'trim', $cols );
				continue;
			}
			$data = $cols;
			break;
		}
		if ( $data === NULL ) { return NULL; }
		$data = \array_map( 'trim', $data );

		$idx = function( $names ) use ( $header ) {
			if ( !$header ) { return NULL; }
			foreach ( $header as $i => $h )
			{
				foreach ( $names as $n ) { if ( \strcasecmp( $h, $n ) === 0 ) { return $i; } }
			}
			return NULL;
		};

		if ( $header )
		{
			$iHost = $idx( array( 'SMTP Endpoint', 'Endpoint' ) );
			$iUser = $idx( array( 'Username', 'SMTP Username', 'IAM User Name' ) );
			$iPass = $idx( array( 'Password', 'SMTP Password' ) );
			$host = ( $iHost !== NULL AND isset( $data[ $iHost ] ) ) ? $data[ $iHost ] : '';
			$user = ( $iUser !== NULL AND isset( $data[ $iUser ] ) ) ? $data[ $iUser ] : '';
			$pass = ( $iPass !== NULL AND isset( $data[ $iPass ] ) ) ? $data[ $iPass ] : '';
		}
		else
		{
			/* Bez nagłówka — zakładamy układ AWS: Endpoint,Port,Username,Username(B64),Password,Password(B64)
			   albo zwykłe IAM: "IAM User Name","SMTP Username","SMTP Password" (3 kolumny) */
			if ( \count( $data ) >= 6 )
			{
				$host = $data[0]; $user = $data[2]; $pass = $data[4];
			}
			elseif ( \count( $data ) === 3 )
			{
				$host = ''; $user = $data[1]; $pass = $data[2];
			}
			elseif ( \count( $data ) === 2 )
			{
				$host = ''; $user = $data[0]; $pass = $data[1];
			}
			else { return NULL; }
		}

		if ( $user === '' AND $pass === '' ) { return NULL; }
		return array( 'host' => $host, 'user' => $user, 'pass' => $pass );
	}

	/**
	 * Manage Settings
	 *
	 * @return	void
	 */
	protected function manage()
	{
		$settings = \IPS\Settings::i();
		$self     = \IPS\Http\Url::internal( 'app=awsses&module=settings&controller=settings' );
		$esc      = function( $s ) { return \htmlspecialchars( (string) $s, ENT_QUOTES, 'UTF-8' ); };

		$fromAddress = $settings->awsses_from ?: $settings->email_out;
		$fromDomain  = ( $fromAddress AND \strpos( $fromAddress, '@' ) !== FALSE )
			? \mb_strtolower( \trim( \substr( \strrchr( $fromAddress, '@' ), 1 ) ) ) : '';

		$form = new \IPS\Helpers\Form;

		/* Zakładka: Połączenie */
		$form->addTab( 'awsses_tab_connection', 'cloud' );
		$form->addHeader( 'awsses_hdr_general' );
		$form->add( new \IPS\Helpers\Form\YesNo( 'awsses_enabled', $settings->awsses_enabled, FALSE ) );
		$form->add( new \IPS\Helpers\Form\Select( 'awsses_mode', $settings->awsses_mode, TRUE, array(
			'options' => array( 'smtp' => 'awsses_mode_smtp', 'api' => 'awsses_mode_api' ),
			'toggles' => array( 'api' => array( 'awsses_access_key', 'awsses_secret_key', 'awsses_configuration_set' ) )
		) ) );
		$form->add( new \IPS\Helpers\Form\Select( 'awsses_region', $settings->awsses_region, TRUE, array( 'options' => $this->sesRegions() ) ) );
		$form->add( new \IPS\Helpers\Form\Text( 'awsses_from', $settings->awsses_from, FALSE, array( 'placeholder' => $settings->email_out ) ) );

		$form->addHeader( 'awsses_hdr_smtp' );
		$form->add( new \IPS\Helpers\Form\TextArea( 'awsses_csv', '', FALSE, array( 'rows' => 3, 'placeholder' => "Wklej tu zawartość .csv z AWS (nagłówek + dane) — Host/User/Hasło uzupełnią się same." ), NULL, NULL, NULL, 'awsses_csv' ) );
		$form->add( new \IPS\Helpers\Form\Text( 'awsses_smtp_host', $settings->awsses_smtp_host, FALSE, array( 'placeholder' => 'email-smtp.' . $settings->awsses_region . '.amazonaws.com' ) ) );
		$form->add( new \IPS\Helpers\Form\Text( 'awsses_smtp_user', $settings->awsses_smtp_user, FALSE ) );
		$form->add( new \IPS\Helpers\Form\Password( 'awsses_smtp_pass', $settings->awsses_smtp_pass, FALSE, array( 'enforceMaxLimit' => FALSE ) ) );

		$form->addHeader( 'awsses_hdr_api' );
		$form->add( new \IPS\Helpers\Form\Text( 'awsses_access_key', $settings->awsses_access_key, FALSE, array(), NULL, NULL, NULL, 'awsses_access_key' ) );
		$form->add( new \IPS\Helpers\Form\Password( 'awsses_secret_key', $settings->awsses_secret_key, FALSE, array( 'enforceMaxLimit' => FALSE ), NULL, NULL, NULL, 'awsses_secret_key' ) );
		$form->add( new \IPS\Helpers\Form\Text( 'awsses_configuration_set', $settings->awsses_configuration_set, FALSE, array(), NULL, NULL, NULL, 'awsses_configuration_set' ) );
		$form->add( new \IPS\Helpers\Form\Text( 'awsses_sns_token', $settings->awsses_sns_token, FALSE ) );

		/* Zakładka: Routing */
		$form->addTab( 'awsses_tab_routing', 'random' );
		$form->addMessage( 'awsses_routing_help', 'ipsMessage ipsMessage_info' );
		$form->add( new \IPS\Helpers\Form\YesNo( 'awsses_route_bulk', $settings->awsses_route_bulk, FALSE ) );
		$form->add( new \IPS\Helpers\Form\YesNo( 'awsses_route_newsletter', $settings->awsses_route_newsletter, FALSE ) );

		/* Zapis */
		if ( $values = $form->values() )
		{
			/* Auto-parsowanie CSV → nadpisuje Host/User/Hasło */
			if ( !empty( $values['awsses_csv'] ) )
			{
				$parsed = static::parseAwsCsv( $values['awsses_csv'] );
				if ( $parsed )
				{
					if ( $parsed['host'] !== '' ) { $values['awsses_smtp_host'] = $parsed['host']; }
					$values['awsses_smtp_user'] = $parsed['user'];
					$values['awsses_smtp_pass'] = $parsed['pass'];
				}
			}
			unset( $values['awsses_csv'] );

			$form->saveAsSettings( $values );
			\IPS\Data\Cache::i()->clearAll();
			\IPS\Output::i()->redirect( $self, 'saved' );
		}

		/* Zakładka: Diagnostyka (tylko wyświetlanie — żadnych zagnieżdżonych <form>) */
		$form->addTab( 'awsses_tab_diagnostics', 'stethoscope' );
		$form->addHtml( $this->diagnosticsHtml( $settings, $fromDomain, $esc, $self ) );

		/* Zakładka: Statystyki */
		$form->addTab( 'awsses_tab_stats', 'bar-chart' );
		$form->addHtml( $this->statsHtml( $esc ) );

		\IPS\Output::i()->title  = \IPS\Member::loggedIn()->language()->addToStack( 'awsses_settings' );
		\IPS\Output::i()->output = $form;
	}

	/**
	 * Wysyłka testowa (osobna strona z własnym formularzem IPS — CSRF obsługuje IPS).
	 *
	 * @return	void
	 */
	protected function test()
	{
		$self = \IPS\Http\Url::internal( 'app=awsses&module=settings&controller=settings' );

		$form = new \IPS\Helpers\Form( 'awsses_test', 'awsses_do_test' );
		$form->add( new \IPS\Helpers\Form\Email( 'test_email', \IPS\Member::loggedIn()->email, TRUE ) );

		if ( $values = $form->values() )
		{
			try
			{
				\IPS\Email::awssesSendTest(
					$values['test_email'],
					'AWS SES — test wysyłki',
					'<p>Testowa wiadomość z integracji AWS SES (IQL vel Espectro).</p>'
				);
				\IPS\Output::i()->redirect( $self, 'awsses_test_sent' );
			}
			catch ( \Exception $e )
			{
				$form->error = $e->getMessage();
			}
		}

		\IPS\Output::i()->title  = \IPS\Member::loggedIn()->language()->addToStack( 'awsses_do_test' );
		\IPS\Output::i()->output = $form;
	}

	/**
	 * HTML diagnostyki
	 */
	protected function diagnosticsHtml( $settings, $fromDomain, $esc, $self ): string
	{
		$row = function( $state, $label, $detail = '' ) {
			$color = $state === 'pass' ? '#1a7f37' : ( $state === 'warn' ? '#9a6700' : '#b42318' );
			$icon  = $state === 'pass' ? '✓' : ( $state === 'warn' ? '!' : '✕' );
			$d = $detail ? "<div style='color:#555;margin-top:2px'>{$detail}</div>" : '';
			return "<div style='padding:6px 0;border-bottom:1px solid #eee'><span style='display:inline-block;width:20px;color:{$color};font-weight:bold'>{$icon}</span><strong>{$label}</strong>{$d}</div>";
		};
		$getTxt = function( $host ) {
			$out = array();
			foreach ( @\dns_get_record( $host, DNS_TXT ) ?: array() as $r )
			{
				if ( isset( $r['txt'] ) ) { $out[] = $r['txt']; }
				elseif ( isset( $r['entries'] ) ) { $out[] = \implode( '', $r['entries'] ); }
			}
			return $out;
		};

		$h  = "<h3>Stan integracji</h3>";
		$h .= $row( $settings->awsses_enabled ? 'pass' : 'warn', 'Integracja ' . ( $settings->awsses_enabled ? 'włączona' : 'wyłączona' ) );
		$h .= $row( $settings->awsses_region ? 'pass' : 'fail', 'Region: ' . ( $settings->awsses_region ? $esc( $settings->awsses_region ) : 'brak' ) );
		$h .= $row( 'pass', 'Tryb: ' . $esc( $settings->awsses_mode ) );
		$h .= $row( $settings->awsses_route_bulk ? 'pass' : 'warn', 'Bulk Mail przez SES: ' . ( $settings->awsses_route_bulk ? 'TAK' : 'nie' ) );
		$h .= $row( $settings->awsses_route_newsletter ? 'pass' : 'warn', 'Newslettery przez SES: ' . ( $settings->awsses_route_newsletter ? 'TAK' : 'nie' ) );
		$h .= $row( $fromDomain ? 'pass' : 'fail', 'Domena nadawcza: ' . ( $fromDomain ? $esc( $fromDomain ) : 'nieustalona' ) );

		$diagUrl = $self->setQueryString( 'awsses_diag', 1 );
		$h .= "<h3 style='margin-top:14px'>DNS domeny nadawczej</h3>";
		if ( \IPS\Request::i()->awsses_diag AND $fromDomain )
		{
			$h .= $row( 'warn', 'DKIM (3× CNAME *._domainkey → *.dkim.amazonses.com)', 'Zweryfikuj 3 rekordy CNAME w konsoli SES (tokenów aplikacja nie zna).' );

			$spf = NULL;
			foreach ( $getTxt( $fromDomain ) as $t ) { if ( \stripos( $t, 'v=spf1' ) === 0 ) { $spf = $t; break; } }
			if ( $spf === NULL ) { $h .= $row( 'fail', 'SPF — brak rekordu', 'Dodaj TXT: v=spf1 include:amazonses.com ~all' ); }
			elseif ( \stripos( $spf, 'amazonses.com' ) !== FALSE ) { $h .= $row( 'pass', 'SPF zawiera include:amazonses.com', $esc( $spf ) ); }
			else { $h .= $row( 'warn', 'SPF bez amazonses.com', $esc( $spf ) ); }

			$dmarc = NULL;
			foreach ( $getTxt( "_dmarc.{$fromDomain}" ) as $t ) { if ( \stripos( $t, 'v=DMARC1' ) === 0 ) { $dmarc = $t; break; } }
			$h .= $dmarc ? $row( 'pass', 'DMARC obecny', $esc( $dmarc ) ) : $row( 'warn', 'DMARC — brak', 'Zalecane: v=DMARC1; p=none; rua=mailto:...' );

			if ( $settings->awsses_mode === 'api' )
			{
				$h .= "<h3 style='margin-top:14px'>Połączenie API z SES</h3>";
				if ( $settings->awsses_region AND $settings->awsses_access_key AND $settings->awsses_secret_key )
				{
					try {
						$api = new \IPS\awsses\Api\Api();
						$acc = $api->apiGet( '/v2/email/account' );
						if ( \is_array( $acc ) AND isset( $acc['SendQuota'] ) )
						{
							$prod = !empty( $acc['ProductionAccessEnabled'] );
							$h .= $row( $prod ? 'pass' : 'warn', 'Dostęp produkcyjny: ' . ( $prod ? 'TAK' : 'piaskownica' ), $prod ? '' : 'Złóż wniosek o wyjście z piaskownicy.' );
							$q = $acc['SendQuota'];
							$h .= $row( 'pass', 'Limit 24h: ' . (int) ( $q['Max24HourSend'] ?? 0 ) . ', wysłane 24h: ' . (int) ( $q['SentLast24Hours'] ?? 0 ) . ', max/s: ' . $esc( (string) ( $q['MaxSendRate'] ?? 0 ) ) );
						}
						else { $h .= $row( 'fail', 'API odpowiedziało nieoczekiwanie', $esc( \substr( (string) \json_encode( $acc ), 0, 300 ) ) ); }
					} catch ( \Exception $e ) { $h .= $row( 'fail', 'Błąd API SES', $esc( $e->getMessage() ) ); }
				}
				else { $h .= $row( 'warn', 'Test API pominięty', 'Uzupełnij region i klucze IAM.' ); }
			}
			else
			{
				$h .= "<h3 style='margin-top:14px'>Połączenie SMTP z SES</h3>";
				if ( ( $settings->awsses_smtp_host OR $settings->awsses_region ) AND $settings->awsses_smtp_user )
				{
					try {
						$host = \trim( (string) $settings->awsses_smtp_host ) ?: ( 'email-smtp.' . $settings->awsses_region . '.amazonaws.com' );
						$s = new \IPS\Email\Outgoing\Smtp( 'tls', $host, 587, $settings->awsses_smtp_user, $settings->awsses_smtp_pass );
						$s->connect();
						$h .= $row( 'pass', 'Połączono i uwierzytelniono w ' . $esc( $host ) . ':587' );
					} catch ( \Exception $e ) { $h .= $row( 'fail', 'Nie udało się połączyć/uwierzytelnić', $esc( $e->getMessage() ) ); }
				}
				else { $h .= $row( 'warn', 'Test SMTP pominięty', 'Uzupełnij host/region i poświadczenia SMTP.' ); }
			}
		}
		else
		{
			$h .= "<p><a class='ipsButton ipsButton_primary ipsButton_small' href='" . $esc( (string) $diagUrl ) . "'>Uruchom diagnostykę DNS / połączenia</a></p>";
		}

		/* Test wysyłki — LINK do osobnej akcji (bez zagnieżdżonego formularza) */
		$testUrl = $self->setQueryString( 'do', 'test' );
		$h .= "<h3 style='margin-top:14px'>Wysyłka testowa</h3>";
		$h .= "<p><a class='ipsButton ipsButton_important ipsButton_small' href='" . $esc( (string) $testUrl ) . "'>Wyślij wiadomość testową przez SES</a></p>";

		/* Endpoint SNS */
		$snsUrl = \rtrim( (string) $settings->base_url, '/' ) . '/applications/awsses/interface/sns/sns.php'
			. ( $settings->awsses_sns_token ? '?t=' . \rawurlencode( $settings->awsses_sns_token ) : '' );
		$h .= "<h3 style='margin-top:14px'>Endpoint SNS (bounce / complaint / statystyki)</h3>";
		$h .= "<p style='color:#555'>Podepnij w subskrypcji SNS (HTTPS) powiązanej z Configuration Set:</p>";
		$h .= "<code style='display:block;padding:8px;background:#f5f5f5;border-radius:6px;word-break:break-all'>" . $esc( $snsUrl ) . "</code>";

		return $h;
	}

	/**
	 * HTML statystyk
	 */
	protected function statsHtml( $esc ): string
	{
		$h = "<h3>Statystyki SES (zdarzenia z SNS, 30 dni)</h3>";
		try
		{
			if ( !\IPS\Db::i()->checkForTable( 'awsses_events' ) )
			{
				return $h . "<p class='ipsType_light'>Brak danych — pojawią się po podpięciu endpointu SNS i Configuration Set.</p>";
			}

			$since = \time() - ( 30 * 86400 );
			$counts = array();
			foreach ( \IPS\Db::i()->select( 'ev_type, COUNT(*) as c', 'awsses_events', array( 'ev_ts>?', $since ), NULL, NULL, 'ev_type' ) as $r )
			{
				$counts[ $r['ev_type'] ] = (int) $r['c'];
			}

			$labels = array( 'send' => 'Wysłane', 'delivery' => 'Dostarczone', 'open' => 'Otwarcia', 'click' => 'Kliknięcia', 'bounce' => 'Odbicia', 'complaint' => 'Skargi', 'reject' => 'Odrzucone' );
			$h .= "<div style='display:flex;flex-wrap:wrap;gap:12px'>";
			foreach ( $labels as $k => $lab )
			{
				$v = $counts[ $k ] ?? 0;
				$h .= "<div style='min-width:110px;padding:10px 14px;border:1px solid #e5e5e5;border-radius:8px;text-align:center'><div style='font-size:22px;font-weight:bold'>" . (int) $v . "</div><div style='color:#666;font-size:12px'>" . $esc( $lab ) . "</div></div>";
			}
			$h .= "</div>";

			$supCount = \IPS\Db::i()->checkForTable( 'awsses_suppressions' ) ? (int) \IPS\Db::i()->select( 'COUNT(*)', 'awsses_suppressions' )->first() : 0;
			$h .= "<p style='margin-top:14px'><strong>Lista supresji:</strong> {$supCount} adres(ów).</p>";
			if ( $supCount )
			{
				$h .= "<table class='ipsTable' style='margin-top:6px'><tr><th>Adres</th><th>Powód</th><th>Data</th></tr>";
				foreach ( \IPS\Db::i()->select( '*', 'awsses_suppressions', NULL, 'sup_ts DESC', 20 ) as $s )
				{
					$h .= "<tr><td>" . $esc( $s['sup_email'] ) . "</td><td>" . $esc( $s['sup_reason'] ) . "</td><td>" . $esc( (string) \IPS\DateTime::ts( $s['sup_ts'] ) ) . "</td></tr>";
				}
				$h .= "</table>";
			}
		}
		catch ( \Exception $e )
		{
			$h .= "<p>Nie udało się odczytać statystyk: " . $esc( $e->getMessage() ) . "</p>";
		}
		return $h;
	}
}
