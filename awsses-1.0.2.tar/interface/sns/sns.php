<?php
/**
 * AWS SES — endpoint SNS (bounce / complaint / statystyki).
 *
 * Plik interface aplikacji. URL do subskrypcji SNS (typ HTTPS):
 *   https://twojeforum/applications/awsses/interface/sns/sns.php?t=<awsses_sns_token>
 *
 * @author  IQL vel Espectro
 * @package awsses
 */

require_once \str_replace( 'applications/awsses/interface/sns/sns.php', 'init.php', \str_replace( '\\', '/', __FILE__ ) );

/* ---------- helpers ---------- */
function awsses_sns_fail( $code, $msg )
{
	\http_response_code( $code );
	\header( 'Content-Type: text/plain; charset=utf-8' );
	echo $msg;
	exit;
}

function awsses_sns_amazonHost( string $url ): bool
{
	$host = \parse_url( $url, PHP_URL_HOST );
	if ( !$host ) { return FALSE; }
	$host = \mb_strtolower( $host );
	return (bool) \preg_match( '/(^|\.)amazonaws\.com$/', $host ) AND \strpos( $url, 'https://' ) === 0;
}

function awsses_sns_verify( array $sns ): bool
{
	if ( empty( $sns['Signature'] ) OR empty( $sns['SigningCertURL'] ) OR !awsses_sns_amazonHost( $sns['SigningCertURL'] ) )
	{
		return FALSE;
	}

	if ( \in_array( $sns['Type'], array( 'SubscriptionConfirmation', 'UnsubscribeConfirmation' ) ) )
	{
		$keys = array( 'Message', 'MessageId', 'SubscribeURL', 'Timestamp', 'Token', 'TopicArn', 'Type' );
	}
	else
	{
		$keys = array( 'Message', 'MessageId', 'Subject', 'Timestamp', 'TopicArn', 'Type' );
	}

	$stringToSign = '';
	foreach ( $keys as $k )
	{
		if ( isset( $sns[ $k ] ) AND $sns[ $k ] !== '' )
		{
			$stringToSign .= $k . "\n" . $sns[ $k ] . "\n";
		}
	}

	try
	{
		$pem = (string) \IPS\Http\Url::external( $sns['SigningCertURL'] )->request( \IPS\LONG_REQUEST_TIMEOUT )->get();
	}
	catch ( \Exception $e )
	{
		return FALSE;
	}

	$publicKey = @\openssl_pkey_get_public( $pem );
	if ( !$publicKey )
	{
		return FALSE;
	}

	$algo = ( isset( $sns['SignatureVersion'] ) AND $sns['SignatureVersion'] == '2' ) ? OPENSSL_ALGO_SHA256 : OPENSSL_ALGO_SHA1;
	return \openssl_verify( $stringToSign, \base64_decode( $sns['Signature'] ), $publicKey, $algo ) === 1;
}

function awsses_sns_handleEvent( array $m ): void
{
	$type = $m['eventType'] ?? ( $m['notificationType'] ?? '' );
	$config = $m['mail']['tags']['ses:configuration-set'][0] ?? '';

	switch ( $type )
	{
		case 'Bounce':
			$bounceType = $m['bounce']['bounceType'] ?? '';
			foreach ( ( $m['bounce']['bouncedRecipients'] ?? array() ) as $r )
			{
				$addr = $r['emailAddress'] ?? '';
				if ( $addr )
				{
					\IPS\awsses\Suppression::recordEvent( 'bounce', $addr, $config );
					if ( $bounceType === 'Permanent' )
					{
						\IPS\awsses\Suppression::suppress( $addr, 'bounce', 'Permanent: ' . ( $r['diagnosticCode'] ?? '' ) );
					}
				}
			}
			break;

		case 'Complaint':
			foreach ( ( $m['complaint']['complainedRecipients'] ?? array() ) as $r )
			{
				$addr = $r['emailAddress'] ?? '';
				if ( $addr )
				{
					\IPS\awsses\Suppression::recordEvent( 'complaint', $addr, $config );
					\IPS\awsses\Suppression::suppress( $addr, 'complaint', $m['complaint']['complaintFeedbackType'] ?? '' );
				}
			}
			break;

		case 'Delivery':
		case 'Send':
		case 'Open':
		case 'Click':
		case 'Reject':
			$addr = $m['mail']['destination'][0] ?? '';
			\IPS\awsses\Suppression::recordEvent( \mb_strtolower( $type ), (string) $addr, $config );
			break;
	}
}

/* ---------- opcjonalny sekret ---------- */
$expectedToken = \IPS\Settings::i()->awsses_sns_token;
if ( $expectedToken )
{
	$given = isset( $_GET['t'] ) ? (string) $_GET['t'] : '';
	if ( !\hash_equals( $expectedToken, $given ) )
	{
		awsses_sns_fail( 403, 'forbidden' );
	}
}

/* ---------- odczyt / parsowanie ---------- */
$raw = \file_get_contents( 'php://input' );
if ( !$raw ) { awsses_sns_fail( 400, 'empty' ); }

$sns = \json_decode( $raw, TRUE );
if ( !\is_array( $sns ) OR !isset( $sns['Type'] ) ) { awsses_sns_fail( 400, 'bad json' ); }

/* ---------- weryfikacja podpisu ---------- */
if ( !awsses_sns_verify( $sns ) )
{
	\IPS\Log::log( 'AWS SNS: nieprawidłowy podpis', 'awsses_sns' );
	awsses_sns_fail( 403, 'bad signature' );
}

/* ---------- obsługa ---------- */
switch ( $sns['Type'] )
{
	case 'SubscriptionConfirmation':
	case 'UnsubscribeConfirmation':
		if ( isset( $sns['SubscribeURL'] ) AND awsses_sns_amazonHost( $sns['SubscribeURL'] ) )
		{
			try
			{
				\IPS\Http\Url::external( $sns['SubscribeURL'] )->request( \IPS\LONG_REQUEST_TIMEOUT )->get();
				\IPS\awsses\Suppression::recordEvent( 'subscription', '', '' );
			}
			catch ( \Exception $e ) { \IPS\Log::log( $e, 'awsses_sns' ); }
		}
		break;

	case 'Notification':
		$message = \json_decode( $sns['Message'] ?? '', TRUE );
		if ( \is_array( $message ) ) { awsses_sns_handleEvent( $message ); }
		break;
}

\http_response_code( 200 );
echo 'ok';
