<?php
/**
 * AWS SES Integration — Lista supresji (ACP: AWS SES → Lista supresji).
 *
 * Adresy po twardym odbiciu lub skardze: podsumowanie, PW z prośbą o zmianę adresu (wszystkim w tle
 * albo pojedynczo), ręczne zdjęcie adresu z listy.
 *
 * @author  IQL vel Espectro
 * @package awsses
 */

namespace IPS\awsses\modules\admin\settings;

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( isset( $_SERVER['SERVER_PROTOCOL'] ) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

/**
 * suppression
 */
class _suppression extends \IPS\Dispatcher\Controller
{
	/**
	 * @brief	Akcje (pmAll, pmOne, delete) same sprawdzają csrfCheck(); tabela ma parametry sortowania/szukania.
	 */
	public static $csrfProtected = TRUE;

	/**
	 * Execute
	 *
	 * @return	void
	 */
	public function execute()
	{
		\IPS\Dispatcher::i()->checkAcpPermission( 'settings_manage' );
		parent::execute();
	}

	/**
	 * Adres strony
	 */
	protected function url(): \IPS\Http\Url
	{
		return \IPS\Http\Url::internal( 'app=awsses&module=settings&controller=suppression' );
	}

	/**
	 * Escapowanie
	 */
	protected function e( $v ): string
	{
		return \htmlspecialchars( (string) $v, ENT_QUOTES, 'UTF-8' );
	}

	/**
	 * Lista
	 *
	 * @return	void
	 */
	protected function manage()
	{
		$s       = \IPS\Settings::i();
		$sum     = \IPS\awsses\Suppression::summary();
		$sender  = \IPS\Member::load( (int) $s->awsses_pm_sender );
		$settingsUrl = \IPS\Http\Url::internal( 'app=awsses&module=settings&controller=settings' )->setQueryString( 'activeTab', 'awsses_tab_notify' );

		/* Podsumowanie + działania */
		$h  = "<div class='ipsBox ipsPad ipsSpacer_bottom'>";
		$h .= "<p>Adresy, na które SES nie dostarcza poczty (twarde odbicie) albo których właściciel zgłosił spam. Kolejne wysyłki przez SES je pomijają, a kontom forum z tymi adresami wyłączono maile od administracji.</p>";
		$h .= "<ul class='ipsList_inline ipsSpacer_top'>"
			. "<li><strong>" . (int) $sum['total'] . "</strong> adresów na liście</li>"
			. "<li><strong>" . (int) $sum['withMember'] . "</strong> nadal przypisanych do konta na forum</li>"
			. "<li><strong>" . (int) $sum['pmSent'] . "</strong> dostało PW</li>"
			. "<li><strong>" . (int) $sum['resolved'] . "</strong> zmieniło adres</li>"
			. "<li><strong>" . (int) $sum['pending'] . "</strong> czeka na PW</li></ul>";

		$h .= "<p class='ipsSpacer_top'>Komunikat na forum dla tych użytkowników: <strong>" . ( $s->awsses_notice_enabled ? 'włączony' : 'wyłączony' ) . "</strong>"
			. " · Automatyczna PW po nowym odbiciu: <strong>" . ( $s->awsses_pm_auto ? 'włączona' : 'wyłączona' ) . "</strong>"
			. " · Nadawca PW: <strong>" . ( $sender->member_id ? $this->e( $sender->name ) : 'nie ustawiono' ) . "</strong>"
			. " — <a href='" . $this->e( $settingsUrl ) . "'>zmień w ustawieniach</a></p>";

		if ( !$sender->member_id )
		{
			$h .= "<div class='ipsMessage ipsMessage_warning'>Aby wysyłać PW, ustaw nadawcę (konto, od którego przyjdzie wiadomość) w <a href='" . $this->e( $settingsUrl ) . "'>AWS SES → Ustawienia → Martwe adresy</a>.</div>";
		}
		elseif ( $sum['pending'] > 0 )
		{
			$h .= "<p class='ipsSpacer_top'><a class='ipsButton ipsButton_primary' href='" . $this->e( $this->url()->setQueryString( 'do', 'pmAll' )->csrf() ) . "' data-confirm data-confirmMessage='" . $this->e( "Wysłać PW z prośbą o zmianę adresu do {$sum['pending']} użytkowników? Wysyłka idzie w tle; powiadomień e-mail o PW nie wysyłamy (adresy nie działają)." ) . "'>Wyślij PW do " . (int) $sum['pending'] . " użytkowników</a>"
				. " <span class='ipsType_light'>Każdy dostaje jedną PW. Po zmianie adresu komunikat znika, a maile od administracji wracają.</span></p>";
		}
		else
		{
			$h .= "<p class='ipsSpacer_top ipsType_light'>Nikt nie czeka na PW.</p>";
		}
		$h .= "</div>";

		/* Tabela */
		$table = new \IPS\Helpers\Table\Db( 'awsses_suppressions', $this->url() );
		$table->langPrefix  = 'awsses_sup_';
		$table->include     = \IPS\awsses\Suppression::hasMemberColumns()
			? array( 'sup_email', 'sup_member', 'sup_reason', 'sup_detail', 'sup_ts', 'sup_status' )
			: array( 'sup_email', 'sup_member', 'sup_reason', 'sup_detail', 'sup_ts' );
		$table->mainColumn  = 'sup_email';
		$table->sortBy      = $table->sortBy ?: 'sup_ts';
		$table->sortDirection = $table->sortDirection ?: 'desc';
		$table->noSort      = array( 'sup_member', 'sup_detail', 'sup_status' );
		$table->quickSearch = 'sup_email';
		if ( \IPS\awsses\Suppression::hasMemberColumns() )
		{
			$table->filters = array(
				'awsses_sup_f_pending'  => 'sup_pm_ts=0 AND sup_resolved_ts=0',
				'awsses_sup_f_pm'       => 'sup_pm_ts>0',
				'awsses_sup_f_resolved' => 'sup_resolved_ts>0',
			);
		}

		$e = function( $v ) { return \htmlspecialchars( (string) $v, ENT_QUOTES, 'UTF-8' ); };
		$table->parsers = array(
			'sup_member' => function( $val, $row ) use ( $e )
			{
				$member = \IPS\Member::load( (string) $row['sup_email'], 'email' );
				if ( !$member->member_id AND !empty( $row['sup_member_id'] ) )
				{
					$member = \IPS\Member::load( (int) $row['sup_member_id'] );
				}
				if ( !$member->member_id )
				{
					return "<span class='ipsType_light'>brak konta</span>";
				}
				return "<a href='" . $e( $member->acpUrl() ) . "'>" . $e( $member->name ) . "</a>";
			},
			'sup_reason' => function( $val ) { return $val === 'complaint' ? 'skarga (spam)' : 'twarde odbicie'; },
			'sup_detail' => function( $val ) use ( $e )
			{
				$code = \trim( \preg_replace( '/^Permanent:\s*/', '', (string) $val ) );
				if ( $code === '' ) { return '—'; }
				$hint = \IPS\awsses\Stats\Report::smtpHint( $code );
				return ( $hint !== '' ? '<strong>' . $e( $hint ) . '</strong><br>' : '' ) . "<span class='ipsType_light ipsType_small'>" . $e( \mb_substr( $code, 0, 200 ) ) . '</span>';
			},
			'sup_ts'     => function( $val ) { return (string) \IPS\DateTime::ts( (int) $val ); },
			'sup_status' => function( $val, $row )
			{
				if ( !empty( $row['sup_resolved_ts'] ) ) { return '✓ zmienił adres ' . \IPS\DateTime::ts( (int) $row['sup_resolved_ts'] )->localeDate(); }
				if ( !empty( $row['sup_pm_ts'] ) )       { return '✉ PW wysłana ' . \IPS\DateTime::ts( (int) $row['sup_pm_ts'] )->localeDate(); }
				return '· czeka';
			},
		);

		$url = $this->url();
		$canPm = (bool) $sender->member_id;
		$table->rowButtons = function( $row ) use ( $url, $canPm )
		{
			$buttons = array();
			if ( $canPm AND empty( $row['sup_resolved_ts'] ) )
			{
				$buttons['pm'] = array(
					'icon'  => 'envelope',
					'title' => empty( $row['sup_pm_ts'] ) ? 'awsses_sup_pm_one' : 'awsses_sup_pm_again',
					'link'  => $url->setQueryString( array( 'do' => 'pmOne', 'id' => $row['sup_id'] ) )->csrf(),
				);
			}
			$buttons['delete'] = array(
				'icon'  => 'times-circle',
				'title' => 'awsses_sup_remove',
				'link'  => $url->setQueryString( array( 'do' => 'delete', 'id' => $row['sup_id'] ) )->csrf(),
				'data'  => array( 'delete' => '', 'delete-warning' => \IPS\Member::loggedIn()->language()->addToStack( 'awsses_sup_remove_warning' ) ),
			);
			return $buttons;
		};

		\IPS\Output::i()->sidebar['actions']['stats'] = array( 'icon' => 'bar-chart', 'title' => 'awsses_menu_stats_link', 'link' => \IPS\Http\Url::internal( 'app=awsses&module=settings&controller=stats' ) );
		\IPS\Output::i()->sidebar['actions']['settings'] = array( 'icon' => 'cog', 'title' => 'awsses_menu_settings_link', 'link' => $settingsUrl );

		\IPS\Output::i()->title  = \IPS\Member::loggedIn()->language()->addToStack( 'awsses_sup_title' );
		\IPS\Output::i()->output = $h . (string) $table;
	}

	/**
	 * PW do wszystkich czekających (zadanie w tle)
	 *
	 * @return	void
	 */
	protected function pmAll()
	{
		\IPS\Session::i()->csrfCheck();
		if ( !\IPS\Member::load( (int) \IPS\Settings::i()->awsses_pm_sender )->member_id )
		{
			\IPS\Output::i()->error( 'awsses_sup_no_sender', '1AWS/1', 403, '' );
		}
		\IPS\Task::queue( 'awsses', 'SuppressionPm', array(), 3, array() );
		\IPS\Session::i()->log( 'awsses_log_pm_all' );
		\IPS\Output::i()->redirect( $this->url(), 'awsses_sup_pm_queued' );
	}

	/**
	 * PW do jednej osoby
	 *
	 * @return	void
	 */
	protected function pmOne()
	{
		\IPS\Session::i()->csrfCheck();
		try
		{
			$row = \IPS\Db::i()->select( '*', 'awsses_suppressions', array( 'sup_id=?', (int) \IPS\Request::i()->id ) )->first();
		}
		catch ( \UnderflowException $e )
		{
			\IPS\Output::i()->error( 'node_error', '2AWS/2', 404, '' );
		}

		try
		{
			$sent = \IPS\awsses\Suppression::sendPm( $row );
		}
		catch ( \DomainException $e )
		{
			\IPS\Output::i()->error( 'awsses_sup_no_sender', '1AWS/3', 403, '' );
		}
		\IPS\Output::i()->redirect( $this->url(), $sent ? 'awsses_sup_pm_sent' : 'awsses_sup_pm_skipped' );
	}

	/**
	 * Zdejmij z listy
	 *
	 * @return	void
	 */
	protected function delete()
	{
		\IPS\Session::i()->csrfCheck();
		\IPS\Request::i()->confirmedDelete();
		\IPS\awsses\Suppression::remove( (int) \IPS\Request::i()->id );
		\IPS\Output::i()->redirect( $this->url(), 'awsses_sup_removed' );
	}
}
