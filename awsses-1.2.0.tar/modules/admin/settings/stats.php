<?php
/**
 * AWS SES Integration — statystyki wysyłki (osobna strona ACP: AWS SES → Statystyki).
 *
 * @author  IQL vel Espectro
 * @package awsses
 */

namespace IPS\awsses\modules\admin\settings;

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( isset( $_SERVER['SERVER_PROTOCOL'] ) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

/**
 * stats
 */
class _stats extends \IPS\Dispatcher\Controller
{
	/**
	 * @brief	Strona tylko wyświetla dane; linki okresu mają parametr awsses_days — bez tej flagi IPS ACP
	 *			wymusza csrfCheck() na każdym żądaniu z parametrem spoza app/module/controller/id (błąd 2S119/1).
	 */
	public static $csrfProtected = TRUE;

	/**
	 * Execute
	 *
	 * @return	void
	 */
	public function execute()
	{
		\IPS\Dispatcher::i()->checkAcpPermission( 'settings_manage' );
		parent::execute();
	}

	/**
	 * Statystyki
	 *
	 * @return	void
	 */
	protected function manage()
	{
		$self = \IPS\Http\Url::internal( 'app=awsses&module=settings&controller=stats' );
		$days = (int) \IPS\Request::i()->awsses_days;
		$urls = array();
		foreach ( \IPS\awsses\Stats\Report::PERIODS as $p )
		{
			$urls[ $p ] = (string) $self->setQueryString( 'awsses_days', $p );
		}

		try
		{
			$html = \IPS\awsses\Stats\Report::render( \IPS\awsses\Stats\Report::collect( $days ?: 30 ), $urls );
		}
		catch ( \Exception $e )
		{
			\IPS\Log::log( $e, 'awsses' );
			$html = "<p>Błąd odczytu statystyk: " . \htmlspecialchars( $e->getMessage(), ENT_QUOTES, 'UTF-8' ) . "</p>";
		}

		\IPS\Output::i()->sidebar['actions']['settings'] = array(
			'icon'  => 'cog',
			'title' => 'awsses_menu_settings_link',
			'link'  => \IPS\Http\Url::internal( 'app=awsses&module=settings&controller=settings' ),
		);

		\IPS\Output::i()->title  = \IPS\Member::loggedIn()->language()->addToStack( 'awsses_stats_title' );
		\IPS\Output::i()->output = "<div class='ipsBox ipsPad'>{$html}</div>";
	}
}
