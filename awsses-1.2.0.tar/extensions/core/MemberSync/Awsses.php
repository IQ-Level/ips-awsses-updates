<?php
/**
 * AWS SES Integration — zmiana adresu e-mail: wpis supresji starego adresu oznaczany jako rozwiązany,
 * maile od administracji wracają (jeśli wyłączyła je ta aplikacja), komunikat na forum znika.
 *
 * @author  IQL vel Espectro
 * @package awsses
 */

namespace IPS\awsses\extensions\core\MemberSync;

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( isset( $_SERVER['SERVER_PROTOCOL'] ) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

/**
 * Member Sync
 */
class _Awsses
{
	/**
	 * Adres e-mail zmieniony (front: ustawienia konta, ACP: edycja członka)
	 *
	 * @param	\IPS\Member	$member
	 * @param	string		$newEmail
	 * @param	string		$oldEmail
	 * @return	void
	 */
	public function onEmailChange( $member, $newEmail, $oldEmail )
	{
		try
		{
			\IPS\awsses\Suppression::resolveEmailChange( $member, (string) $oldEmail, (string) $newEmail );
		}
		catch ( \Exception $e )
		{
			\IPS\Log::log( $e, 'awsses' );
		}
	}
}
