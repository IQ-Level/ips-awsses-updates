<?php
/**
 * AWS SES Integration — widget pulpitu ACP: wysyłka przez SES z ostatnich 7 dni.
 *
 * @author  IQL vel Espectro
 * @package awsses
 */

namespace IPS\awsses\extensions\core\Dashboard;

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( isset( $_SERVER['SERVER_PROTOCOL'] ) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

/**
 * Dashboard extension: Overview
 */
class _Overview
{
	/**
	 * Czy administrator może zobaczyć widget? (te same uprawnienia co strona aplikacji)
	 *
	 * @return	bool
	 */
	public function canView()
	{
		return \IPS\Member::loggedIn()->hasAcpRestriction( 'awsses', 'settings', 'settings_manage' );
	}

	/**
	 * HTML widgetu
	 *
	 * @return	string
	 */
	public function getBlock()
	{
		try
		{
			return \IPS\awsses\Stats\Report::renderWidget(
				\IPS\awsses\Stats\Report::collect( 7 ),
				(string) \IPS\Http\Url::internal( 'app=awsses&module=settings&controller=stats' )
			);
		}
		catch ( \Exception $e )
		{
			\IPS\Log::log( $e, 'awsses' );
			return "<div class='ipsPad'>Błąd odczytu statystyk SES: " . \htmlspecialchars( $e->getMessage(), ENT_QUOTES, 'UTF-8' ) . "</div>";
		}
	}
}
