<?php
/**
 * AWS SES Integration — zadanie w tle: PW z prośbą o zmianę adresu do wszystkich z listy supresji,
 * którzy mają konto na forum, nadal mają ten adres i jeszcze nie dostali PW.
 *
 * @author  IQL vel Espectro
 * @package awsses
 */

namespace IPS\awsses\extensions\core\Queue;

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( isset( $_SERVER['SERVER_PROTOCOL'] ) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

/**
 * Background Task
 */
class _SuppressionPm
{
	/**
	 * @brief	PW w jednym kroku kolejki
	 */
	const PER_CYCLE = 25;

	/**
	 * Parse data before queuing
	 *
	 * @param	array	$data
	 * @return	array
	 */
	public function preQueueData( $data )
	{
		$data['count'] = \IPS\awsses\Suppression::pendingPmCount();
		$data['done']  = 0;
		$data['sent']  = 0;
		return $data;
	}

	/**
	 * Run Background Task
	 *
	 * @param	mixed	$data
	 * @param	int		$offset
	 * @return	int
	 * @throws	\IPS\Task\Queue\OutOfRangeException
	 */
	public function run( &$data, $offset )
	{
		$lastId = (int) ( $data['lastId'] ?? 0 );
		$rows   = \IPS\awsses\Suppression::pendingPmRows( $lastId, static::PER_CYCLE );
		if ( !$rows )
		{
			throw new \IPS\Task\Queue\OutOfRangeException;
		}

		foreach ( $rows as $row )
		{
			$lastId = (int) $row['sup_id'];
			try
			{
				if ( \IPS\awsses\Suppression::sendPm( $row ) ) { $data['sent']++; }
			}
			catch ( \DomainException $e )
			{
				/* Brak nadawcy — nie ma sensu kontynuować */
				\IPS\Log::log( $e, 'awsses' );
				throw new \IPS\Task\Queue\OutOfRangeException;
			}
			catch ( \Exception $e )
			{
				\IPS\Log::log( $e, 'awsses' );
			}
			$data['done']++;
		}

		$data['lastId'] = $lastId;
		return $lastId;
	}

	/**
	 * Get Progress
	 *
	 * @param	mixed	$data
	 * @param	int		$offset
	 * @return	array
	 */
	public function getProgress( $data, $offset )
	{
		$count = \max( 1, (int) ( $data['count'] ?? 1 ) );
		return array(
			'text'     => \IPS\Member::loggedIn()->language()->addToStack( 'awsses_queue_pm' ),
			'complete' => \min( 100, \round( 100 / $count * (int) ( $data['done'] ?? 0 ), 2 ) ),
		);
	}
}
