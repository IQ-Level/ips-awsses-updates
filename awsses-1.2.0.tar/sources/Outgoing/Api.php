<?php
/**
 * AWS SES — transport przez API v2 (SigV4).
 *
 * Dziedziczy po \IPS\awsses\Outgoing\Smtp: nadawcę, znaczniki kampanii, tempo, ponowienia,
 * wymuszenie SES w mergeAndSend() i filtr supresji. Nadpisuje tylko samo wysłanie:
 * POST /v2/email/outbound-emails (Raw MIME — zostają nagłówki List-Unsubscribe i tracking).
 *
 * @author  IQL vel Espectro
 * @package awsses
 */

namespace IPS\awsses\Outgoing;

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( isset( $_SERVER['SERVER_PROTOCOL'] ) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

/**
 * SES API v2 transport
 */
class _Api extends \IPS\awsses\Outgoing\Smtp
{
	/** @var string */
	protected $apiLog = '';

	/**
	 * Host API
	 *
	 * @return	string
	 */
	protected static function apiHost(): string
	{
		return 'email.' . \IPS\Settings::i()->awsses_region . '.amazonaws.com';
	}

	/**
	 * Wysłanie przez SES API v2 (Raw)
	 *
	 * @throws	\IPS\Email\Outgoing\Exception
	 */
	protected function awssesTransmit( $to, $cc, $bcc, $fromEmail, $fromName, array $additionalHeaders ): void
	{
		$fromEmail = $fromEmail ?: \IPS\Settings::i()->email_out;

		/* Znaczniki i Configuration Set idą polami API, nie nagłówkami */
		$tags = array();
		if ( !empty( $additionalHeaders['X-SES-MESSAGE-TAGS'] ) )
		{
			foreach ( \explode( ',', (string) $additionalHeaders['X-SES-MESSAGE-TAGS'] ) as $pair )
			{
				$kv = \explode( '=', $pair, 2 );
				if ( \count( $kv ) === 2 AND \trim( $kv[0] ) !== '' )
				{
					$tags[] = array( 'Name' => \trim( $kv[0] ), 'Value' => \trim( $kv[1] ) );
				}
			}
		}
		unset( $additionalHeaders['X-SES-MESSAGE-TAGS'], $additionalHeaders['X-SES-CONFIGURATION-SET'] );

		if ( empty( $additionalHeaders['Message-ID'] ) )
		{
			$additionalHeaders['Message-ID'] = $this->generateMessageId();
		}

		$rawMime = $this->compileFullEmail( $to, $cc, array(), $fromEmail, $fromName, $additionalHeaders );

		$dest = array( 'ToAddresses' => $this->addrList( $to ) );
		if ( $cc )  { $dest['CcAddresses']  = $this->addrList( $cc ); }
		if ( $bcc ) { $dest['BccAddresses'] = $this->addrList( $bcc ); }

		$body = array(
			'FromEmailAddress' => $fromEmail,
			'Destination'      => $dest,
			'Content'          => array( 'Raw' => array( 'Data' => \base64_encode( $rawMime ) ) ),
		);
		if ( \IPS\Settings::i()->awsses_configuration_set )
		{
			$body['ConfigurationSetName'] = \IPS\Settings::i()->awsses_configuration_set;
		}
		if ( $tags )
		{
			$body['EmailTags'] = $tags;
		}

		$response = $this->request( 'POST', '/v2/email/outbound-emails', \json_encode( $body ) );
		$code = (int) $response->httpResponseCode;
		if ( $code < 200 OR $code >= 300 )
		{
			$decoded = @$response->decodeJson();
			$message = ( \is_array( $decoded ) AND isset( $decoded['message'] ) ) ? $decoded['message'] : ( 'HTTP ' . $code );
			throw new \IPS\Email\Outgoing\Exception( 'SES API: ' . $message, $code );
		}
	}

	/**
	 * GET do diagnostyki (np. /v2/email/account)
	 *
	 * @param	string	$path
	 * @return	array|NULL
	 * @throws	\IPS\Email\Outgoing\Exception
	 */
	public function apiGet( string $path )
	{
		$response = $this->request( 'GET', $path, '' );
		$decoded  = @$response->decodeJson();
		if ( (int) $response->httpResponseCode >= 300 )
		{
			$msg = ( \is_array( $decoded ) AND isset( $decoded['message'] ) ) ? $decoded['message'] : ( 'HTTP ' . $response->httpResponseCode );
			throw new \IPS\Email\Outgoing\Exception( 'SES API: ' . $msg );
		}
		return $decoded;
	}

	/**
	 * Podpisane żądanie
	 *
	 * @param	string	$method
	 * @param	string	$path
	 * @param	string	$payload
	 * @return	\IPS\Http\Response
	 * @throws	\IPS\Email\Outgoing\Exception
	 */
	protected function request( string $method, string $path, string $payload )
	{
		$s = \IPS\Settings::i();
		if ( !$s->awsses_region OR !$s->awsses_access_key OR !$s->awsses_secret_key )
		{
			throw new \IPS\Email\Outgoing\Exception( 'SES API: brak regionu lub kluczy IAM' );
		}

		$host    = static::apiHost();
		$headers = \IPS\awsses\Aws\Signer::sign(
			$method, $host, $path, '', $payload,
			$s->awsses_region, 'ses', $s->awsses_access_key, $s->awsses_secret_key,
			\gmdate( 'Ymd\THis\Z' ),
			array( 'x-amz-content-sha256' => \hash( 'sha256', $payload ) )
		);
		if ( $method === 'POST' )
		{
			$headers['Content-Type'] = 'application/json';
		}

		$this->apiLog = "{$method} https://{$host}{$path}\n";

		try
		{
			$req = \IPS\Http\Url::external( "https://{$host}{$path}" )->request( \IPS\LONG_REQUEST_TIMEOUT )->setHeaders( $headers );
			return $method === 'POST' ? $req->post( $payload ) : $req->get();
		}
		catch ( \IPS\Http\Request\Exception $e )
		{
			throw new \IPS\Email\Outgoing\Exception( 'SES API: ' . $e->getMessage() );
		}
	}

	/**
	 * Odbiorcy → lista adresów
	 *
	 * @param	mixed	$data
	 * @return	array
	 */
	protected function addrList( $data ): array
	{
		$out = array();
		foreach ( \explode( ',', (string) static::_parseRecipients( $data, TRUE ) ) as $a )
		{
			$a = \trim( $a );
			if ( $a !== '' ) { $out[] = $a; }
		}
		return \array_values( \array_unique( $out ) );
	}

	/**
	 * Log do core_mail_error_logs
	 *
	 * @return	string
	 */
	public function getLog()
	{
		return $this->apiLog;
	}
}
