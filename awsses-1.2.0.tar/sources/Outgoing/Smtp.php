<?php
/**
 * AWS SES — transport SMTP.
 *
 * Rozszerza rdzeniowy \IPS\Email\Outgoing\Smtp (połączenie, STARTTLS, AUTH, logowanie błędów).
 * Dodaje:
 *  - konfigurację z ustawień aplikacji (host / użytkownik / hasło),
 *  - domyślnego nadawcę = awsses_from,
 *  - nagłówek X-SES-CONFIGURATION-SET (zdarzenia SNS) i X-SES-MESSAGE-TAGS (kampania → statystyki),
 *  - tempo wysyłki ≤ awsses_max_rate maili/s i ponowienie przy „throttling” SES,
 *  - mergeAndSend(): SES dla KAŻDEGO odbiorcy + pominięcie adresów z listy supresji,
 *  - MAX_EMAILS_PER_GO = 100 (wielkość paczki Bulk Mail / Newsletters, gdy kieruje je SES).
 *
 * @author  IQL vel Espectro
 * @package awsses
 */

namespace IPS\awsses\Outgoing;

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( isset( $_SERVER['SERVER_PROTOCOL'] ) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

/**
 * SES SMTP transport
 */
class _Smtp extends \IPS\Email\Outgoing\Smtp
{
	/**
	 * @brief	Maks. maili w jednej paczce kolejki (Bulk Mail, Newsletters). Przy 12/s to ok. 9 s na paczkę.
	 */
	const MAX_EMAILS_PER_GO = 100;

	/**
	 * @brief	Moment ostatniej wysyłki (do pilnowania tempa) — wspólny dla procesu
	 */
	protected static $awssesLastSend = 0.0;

	/**
	 * Host SMTP: własny albo email-smtp.<region>.amazonaws.com
	 *
	 * @return	string
	 */
	public static function sesHost(): string
	{
		$custom = \trim( (string) \IPS\Settings::i()->awsses_smtp_host );
		return $custom !== '' ? $custom : 'email-smtp.' . \IPS\Settings::i()->awsses_region . '.amazonaws.com';
	}

	/**
	 * Wartość znacznika SES — dozwolone tylko litery, cyfry, „_” i „-”
	 *
	 * @param	string	$value
	 * @return	string
	 */
	public static function campaignTag( string $value ): string
	{
		$value = (string) \preg_replace( '/[^A-Za-z0-9_\-]/', '-', $value );
		return $value !== '' ? \substr( $value, 0, 200 ) : 'other';
	}

	/**
	 * Czy błąd to przekroczenie limitu SES (do ponowienia)?
	 *
	 * @param	\Exception	$e
	 * @return	bool
	 */
	public static function awssesIsThrottle( \Exception $e ): bool
	{
		$message = (string) $e->getMessage();
		return \in_array( (int) $e->getCode(), array( 454, 429 ), TRUE )
			OR \stripos( $message, 'throttl' ) !== FALSE
			OR \stripos( $message, 'rate exceeded' ) !== FALSE
			OR \stripos( $message, 'TooManyRequests' ) !== FALSE;
	}

	/**
	 * Konstruktor — parametry z ustawień aplikacji
	 */
	public function __construct()
	{
		parent::__construct( 'tls', static::sesHost(), 587, \IPS\Settings::i()->awsses_smtp_user, \IPS\Settings::i()->awsses_smtp_pass );
	}

	/**
	 * Nadawca, Configuration Set i znacznik kampanii
	 *
	 * @param	mixed	$fromEmail
	 * @param	array	$additionalHeaders
	 * @return	array	[ $fromEmail, $additionalHeaders ]
	 */
	protected function awssesPrepare( $fromEmail, array $additionalHeaders ): array
	{
		$s = \IPS\Settings::i();

		if ( !$fromEmail AND $s->awsses_from )
		{
			$fromEmail = $s->awsses_from;
		}
		if ( $s->awsses_configuration_set )
		{
			$additionalHeaders['X-SES-CONFIGURATION-SET'] = $s->awsses_configuration_set;
		}
		if ( empty( $additionalHeaders['X-SES-MESSAGE-TAGS'] ) )
		{
			if ( \IPS\Email::$awssesCampaign )
			{
				$campaign = \IPS\Email::$awssesCampaign;
			}
			elseif ( \IPS\Email::awssesIsNewsletterTest() )
			{
				$campaign = 'newsletter-test';
			}
			else
			{
				$campaign = ( $this->type === \IPS\Email::TYPE_BULK ) ? 'bulk' : 'other';
			}
			$additionalHeaders['X-SES-MESSAGE-TAGS'] = 'campaign=' . static::campaignTag( $campaign );
		}
		else
		{
			/* Oczyść znaczniki (np. niepodstawione *|issue_id|*) — SES odrzuca niedozwolone znaki */
			$pairs = array();
			foreach ( \explode( ',', (string) $additionalHeaders['X-SES-MESSAGE-TAGS'] ) as $pair )
			{
				$kv = \explode( '=', $pair, 2 );
				if ( \count( $kv ) === 2 AND \trim( $kv[0] ) !== '' )
				{
					$pairs[] = static::campaignTag( \trim( $kv[0] ) ) . '=' . static::campaignTag( \trim( $kv[1] ) );
				}
			}
			$additionalHeaders['X-SES-MESSAGE-TAGS'] = $pairs ? \implode( ', ', $pairs ) : 'campaign=other';
		}

		return array( $fromEmail, $additionalHeaders );
	}

	/**
	 * Odczekaj tak, żeby nie przekroczyć awsses_max_rate maili na sekundę
	 *
	 * @return	void
	 */
	protected function awssesPace(): void
	{
		$rate = (float) \IPS\Settings::i()->awsses_max_rate;
		if ( $rate <= 0 )
		{
			return;
		}

		$wait = static::$awssesLastSend + ( 1.0 / $rate ) - \microtime( TRUE );
		if ( $wait > 0 )
		{
			\usleep( (int) \ceil( $wait * 1000000 ) );
		}
		static::$awssesLastSend = \microtime( TRUE );
	}

	/**
	 * Właściwe wysłanie (SMTP rdzenia). Transport API nadpisuje tę metodę.
	 *
	 * @throws	\IPS\Email\Outgoing\Exception
	 */
	protected function awssesTransmit( $to, $cc, $bcc, $fromEmail, $fromName, array $additionalHeaders ): void
	{
		parent::_send( $to, $cc, $bcc, $fromEmail, $fromName, $additionalHeaders );
	}

	/**
	 * Wyczyść stan sesji SMTP przed ponowieniem
	 *
	 * @return	void
	 */
	protected function awssesReset(): void
	{
		try
		{
			if ( isset( static::$smtp[ $this->connectionKey ] ) )
			{
				$this->_sendCommand( 'RSET' );
			}
		}
		catch ( \Throwable $e ) {}
	}

	/**
	 * Wyślij (z tempem i ponowieniem przy „throttling”)
	 *
	 * @param	mixed	$to
	 * @param	mixed	$cc
	 * @param	mixed	$bcc
	 * @param	mixed	$fromEmail
	 * @param	mixed	$fromName
	 * @param	array	$additionalHeaders
	 * @return	void
	 * @throws	\IPS\Email\Outgoing\Exception
	 */
	public function _send( $to, $cc = array(), $bcc = array(), $fromEmail = NULL, $fromName = NULL, $additionalHeaders = array() )
	{
		list( $fromEmail, $additionalHeaders ) = $this->awssesPrepare( $fromEmail, (array) $additionalHeaders );

		for ( $attempt = 0; ; $attempt++ )
		{
			$this->awssesPace();
			try
			{
				$this->awssesTransmit( $to, $cc, $bcc, $fromEmail, $fromName, $additionalHeaders );
				return;
			}
			catch ( \IPS\Email\Outgoing\Exception $e )
			{
				if ( $attempt >= 2 OR !static::awssesIsThrottle( $e ) )
				{
					throw $e;
				}
				$this->awssesReset();
				\usleep( 1000000 * ( $attempt + 1 ) );
			}
		}
	}

	/**
	 * Wysyłka masowa — każdy odbiorca przez SES, bez adresów z supresji, ze znacznikiem kampanii.
	 *
	 * @param	array			$recipients			[ email => [ zmienne ] ]
	 * @param	mixed			$fromEmail
	 * @param	mixed			$fromName
	 * @param	array			$additionalHeaders
	 * @param	\IPS\Lang|NULL	$language
	 * @return	int				Liczba udanych wysyłek
	 */
	public function mergeAndSend( $recipients, $fromEmail = NULL, $fromName = NULL, $additionalHeaders = array(), ?\IPS\Lang $language = NULL )
	{
		$recipients = \IPS\awsses\Suppression::filterRecipients( (array) $recipients );
		if ( !\count( $recipients ) )
		{
			return 0;
		}

		$additionalHeaders = (array) $additionalHeaders;
		if ( empty( $additionalHeaders['X-SES-MESSAGE-TAGS'] ) )
		{
			$first = \reset( $recipients );
			if ( \is_array( $first ) AND isset( $first['issue_id'] ) )
			{
				/* Newsletters: *|issue_id|* podmienia rdzeń dla każdego odbiorcy */
				$campaign = 'newsletter-*|issue_id|*';
			}
			else
			{
				$campaign = ( $this->type === \IPS\Email::TYPE_BULK ) ? 'bulk' : 'mass';
			}
			$additionalHeaders['X-SES-MESSAGE-TAGS'] = 'campaign=' . $campaign;
		}

		$previous = \IPS\Email::$awssesForce;
		\IPS\Email::$awssesForce = TRUE;
		try
		{
			return parent::mergeAndSend( $recipients, $fromEmail, $fromName, $additionalHeaders, $language );
		}
		finally
		{
			\IPS\Email::$awssesForce = $previous;
		}
	}
}
