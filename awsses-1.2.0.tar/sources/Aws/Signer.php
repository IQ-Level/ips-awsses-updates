<?php
/**
 * AWS Signature Version 4 — czysta funkcja (bez zależności od IPS), testowalna osobno.
 *
 * @author  IQL vel Espectro
 * @package awsses
 */

namespace IPS\awsses\Aws;

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( isset( $_SERVER['SERVER_PROTOCOL'] ) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

/**
 * SigV4 signer
 */
class _Signer
{
	/**
	 * Podpisz żądanie. Zwraca nagłówki do wysłania (Authorization, X-Amz-Date + przekazane extra).
	 *
	 * Podpisywane są: host, x-amz-date oraz nagłówki z $signedExtra (np. x-amz-content-sha256).
	 * Celowo NIE podpisujemy Content-Type — klient HTTP może go zmodyfikować.
	 *
	 * @param	string	$method			GET / POST
	 * @param	string	$host			np. email.eu-north-1.amazonaws.com
	 * @param	string	$path			np. /v2/email/outbound-emails
	 * @param	string	$query			kanoniczny query string ('' gdy brak)
	 * @param	string	$payload		ciało żądania
	 * @param	string	$region
	 * @param	string	$service		'ses'
	 * @param	string	$accessKey
	 * @param	string	$secretKey
	 * @param	string	$amzDate		format Ymd\THis\Z (UTC)
	 * @param	array	$signedExtra	dodatkowe nagłówki do podpisania [nazwa => wartość]
	 * @return	array	nagłówki HTTP
	 */
	public static function sign( string $method, string $host, string $path, string $query, string $payload, string $region, string $service, string $accessKey, string $secretKey, string $amzDate, array $signedExtra = array() ): array
	{
		$dateStamp     = \substr( $amzDate, 0, 8 );
		$hashedPayload = \hash( 'sha256', $payload );

		$canon = array();
		foreach ( $signedExtra as $k => $v )
		{
			$canon[ \strtolower( $k ) ] = \trim( (string) $v );
		}
		$canon['host']       = $host;
		$canon['x-amz-date'] = $amzDate;
		\ksort( $canon );

		$canonicalHeaders = '';
		foreach ( $canon as $k => $v )
		{
			$canonicalHeaders .= $k . ':' . $v . "\n";
		}
		$signedHeaders = \implode( ';', \array_keys( $canon ) );

		$canonicalRequest = $method . "\n" . $path . "\n" . $query . "\n" . $canonicalHeaders . "\n" . $signedHeaders . "\n" . $hashedPayload;

		$scope        = "{$dateStamp}/{$region}/{$service}/aws4_request";
		$stringToSign = "AWS4-HMAC-SHA256\n{$amzDate}\n{$scope}\n" . \hash( 'sha256', $canonicalRequest );

		$kDate     = \hash_hmac( 'sha256', $dateStamp, 'AWS4' . $secretKey, TRUE );
		$kRegion   = \hash_hmac( 'sha256', $region, $kDate, TRUE );
		$kService  = \hash_hmac( 'sha256', $service, $kRegion, TRUE );
		$kSigning  = \hash_hmac( 'sha256', 'aws4_request', $kService, TRUE );
		$signature = \hash_hmac( 'sha256', $stringToSign, $kSigning );

		$headers = array(
			'Authorization' => "AWS4-HMAC-SHA256 Credential={$accessKey}/{$scope}, SignedHeaders={$signedHeaders}, Signature={$signature}",
			'X-Amz-Date'    => $amzDate,
		);
		foreach ( $signedExtra as $k => $v )
		{
			$headers[ $k ] = $v;
		}
		return $headers;
	}
}
