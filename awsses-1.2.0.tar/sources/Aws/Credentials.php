<?php
/**
 * Parser pliku CSV z poświadczeniami SMTP z AWS — czysta funkcja (bez zależności od IPS).
 *
 * Obsługiwane formaty:
 *  - Mail Manager / nowy kreator: "SMTP Endpoint,Port,Username,Username (Base64),Password,Password (Base64)"
 *  - IAM SMTP credentials:        "IAM User Name,Smtp Username,Smtp Password"
 *  - bez nagłówka — rozpoznanie po liczbie kolumn
 *
 * @author  IQL vel Espectro
 * @package awsses
 */

namespace IPS\awsses\Aws;

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( isset( $_SERVER['SERVER_PROTOCOL'] ) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

/**
 * Credentials CSV parser
 */
class _Credentials
{
	/**
	 * Parsuj CSV → array( host, port, user, pass ) albo NULL.
	 *
	 * @param	string	$text	Zawartość pliku
	 * @return	array|NULL
	 */
	public static function parseCsv( string $text )
	{
		/* Usuń BOM i podziel na niepuste linie */
		$text  = \preg_replace( '/^\xEF\xBB\xBF/', '', $text );
		$lines = \array_values( \array_filter( \array_map( 'trim', \preg_split( '/\r\n|\r|\n/', \trim( $text ) ) ), 'strlen' ) );
		if ( !$lines )
		{
			return NULL;
		}

		$header = NULL;
		$data   = NULL;
		foreach ( $lines as $line )
		{
			$cols = \array_map( 'trim', \str_getcsv( $line ) );
			if ( $header === NULL AND static::looksLikeHeader( $cols ) )
			{
				$header = $cols;
				continue;
			}
			$data = $cols;
			break;
		}
		if ( $data === NULL )
		{
			return NULL;
		}

		$host = ''; $port = ''; $user = ''; $pass = '';

		if ( $header !== NULL )
		{
			$map = array();
			foreach ( $header as $i => $name )
			{
				$map[ \strtolower( \preg_replace( '/\s+/', ' ', $name ) ) ] = $i;
			}
			$get = function( array $names ) use ( $map, $data ) {
				foreach ( $names as $n )
				{
					if ( isset( $map[ $n ] ) AND isset( $data[ $map[ $n ] ] ) )
					{
						return $data[ $map[ $n ] ];
					}
				}
				return '';
			};
			/* Kolumny Base64 celowo pomijamy — bierzemy wartości jawne */
			$host = $get( array( 'smtp endpoint', 'endpoint', 'smtp host', 'host' ) );
			$port = $get( array( 'port' ) );
			$user = $get( array( 'username', 'smtp username', 'smtp user name' ) );
			$pass = $get( array( 'password', 'smtp password' ) );
		}
		else
		{
			$n = \count( $data );
			if ( $n >= 6 )      { list( $host, $port, $user, , $pass ) = $data; }
			elseif ( $n === 3 ) { $user = $data[1]; $pass = $data[2]; }
			elseif ( $n === 2 ) { $user = $data[0]; $pass = $data[1]; }
			else                { return NULL; }
		}

		if ( $user === '' OR $pass === '' )
		{
			return NULL;
		}

		return array( 'host' => $host, 'port' => $port, 'user' => $user, 'pass' => $pass );
	}

	/**
	 * Czy wiersz to nagłówek?
	 *
	 * @param	array	$cols
	 * @return	bool
	 */
	protected static function looksLikeHeader( array $cols ): bool
	{
		foreach ( $cols as $c )
		{
			$c = \strtolower( $c );
			if ( $c === 'username' OR $c === 'password' OR \strpos( $c, 'smtp username' ) !== FALSE OR \strpos( $c, 'smtp endpoint' ) !== FALSE OR \strpos( $c, 'iam user name' ) !== FALSE )
			{
				return TRUE;
			}
		}
		return FALSE;
	}
}
