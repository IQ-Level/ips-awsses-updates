<?php
/**
 * @brief		AWS SES Integration — Application Class
 * @author		IQL vel Espectro
 * @package		IPS Community Suite
 * @subpackage	AWS SES Integration
 * @since		25 Nov 2026
 * @version		1.0.0
 */

namespace IPS\awsses;

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( isset( $_SERVER['SERVER_PROTOCOL'] ) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

/**
 * AWS SES Integration Application Class
 */
class _Application extends \IPS\Application
{
	/**
	 * [Node] Get Icon for tree
	 *
	 * @return	string|null
	 */
	protected function get__icon()
	{
		return 'paper-plane';
	}
}
