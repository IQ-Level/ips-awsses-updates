//<?php

/**
 * AWS SES Integration — routing hook (code hook na \IPS\Email).
 *
 * MUSI być `abstract class`: \IPS\Email jest abstrakcyjna (abstract _send, isUsable),
 * a nieabstrakcyjny hook w łańcuchu monkeyPatch to fatal error PHP.
 *
 * Decyzja (awssesRoutes):
 *  - $awssesForce = TRUE (trwa wysyłka masowa przez SES albo test) → SES,
 *  - 'bulk'       + awsses_route_bulk       → SES,
 *  - 'newsletter' + awsses_route_newsletter → SES,
 *  - test z formularza Newsletters (transakcyjny) + awsses_route_newsletter → SES,
 *  - reszta (transakcyjne, powiadomienia) → zwykła droga forum.
 * classToUse() zwraca klasę SES dla tych samych typów, więc kolejki Bulk Mail / Newsletters
 * biorą MAX_EMAILS_PER_GO z transportu SES (paczki po 100).
 *
 * @author  IQL vel Espectro
 * @package awsses
 */

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	exit;
}

abstract class awsses_hook_SesFactory extends _HOOK_CLASS_
{
	/**
	 * @brief	Wymuszenie transportu SES (wysyłka masowa przez SES, test)
	 */
	public static $awssesForce = FALSE;

	/**
	 * @brief	Wymuszony znacznik kampanii (np. 'test')
	 */
	public static $awssesCampaign = NULL;

	/**
	 * Klasa transportu dla typu
	 *
	 * @param	string	$type
	 * @return	string
	 */
	public static function classToUse( $type )
	{
		try
		{
			if ( static::$awssesForce OR static::awssesRoutes( (string) $type ) )
			{
				return static::awssesHandlerClass();
			}
		}
		catch ( \Error | \RuntimeException $e )
		{
			\IPS\Log::log( $e, 'awsses' );
		}

		return parent::classToUse( $type );
	}

	/**
	 * Factory
	 *
	 * @param	string	$type
	 * @return	\IPS\Email
	 */
	protected static function factory( $type )
	{
		try
		{
			if ( static::$awssesForce OR static::awssesRoutes( (string) $type ) )
			{
				return static::awssesHandler();
			}
		}
		catch ( \Error | \RuntimeException $e )
		{
			/* Problem po stronie SES nie może zablokować poczty forum: logujemy (ACP → Support → System Logs,
			   kategoria awsses) i wysyłamy zwykłą drogą. */
			\IPS\Log::log( $e, 'awsses' );
		}

		return parent::factory( $type );
	}

	/**
	 * Czy dany typ maila ma iść przez SES?
	 *
	 * @param	string	$type
	 * @return	bool
	 */
	public static function awssesRoutes( string $type ): bool
	{
		$s = \IPS\Settings::i();
		if ( !$s->awsses_enabled OR !static::awssesConfigured() )
		{
			return FALSE;
		}

		if ( $type === \IPS\Email::TYPE_BULK )
		{
			return (bool) $s->awsses_route_bulk;
		}
		if ( $type === 'newsletter' )
		{
			return (bool) $s->awsses_route_newsletter;
		}
		if ( $type === \IPS\Email::TYPE_TRANSACTIONAL AND $s->awsses_route_newsletter AND static::awssesIsNewsletterTest() )
		{
			return TRUE;
		}
		return FALSE;
	}

	/**
	 * Czy bieżące żądanie to „wyślij test” z aplikacji Newsletters (ACP lub front)?
	 *
	 * @return	bool
	 */
	public static function awssesIsNewsletterTest(): bool
	{
		$request = \IPS\Request::i();
		return ( $request->app === 'newsletters' && (string) $request->newsletter_test_email !== '' );
	}

	/**
	 * Czy SES ma minimalną konfigurację?
	 *
	 * @return	bool
	 */
	public static function awssesConfigured(): bool
	{
		$s = \IPS\Settings::i();
		if ( $s->awsses_mode === 'api' )
		{
			return (bool) ( $s->awsses_region AND $s->awsses_access_key AND $s->awsses_secret_key );
		}
		return (bool) ( ( $s->awsses_smtp_host OR $s->awsses_region ) AND $s->awsses_smtp_user AND $s->awsses_smtp_pass );
	}

	/**
	 * Nazwa klasy transportu wg trybu
	 *
	 * @return	string
	 */
	public static function awssesHandlerClass(): string
	{
		return ( \IPS\Settings::i()->awsses_mode === 'api' ) ? 'IPS\awsses\Outgoing\Api' : 'IPS\awsses\Outgoing\Smtp';
	}

	/**
	 * Transport SES wg trybu
	 *
	 * @return	\IPS\Email
	 */
	public static function awssesHandler(): \IPS\Email
	{
		$class = '\\' . static::awssesHandlerClass();
		return new $class;
	}

	/**
	 * Wysyłka testowa przez SES — tą samą ścieżką co prawdziwa wysyłka (buildFromContent rdzenia),
	 * niezależnie od włącznika i przełączników routingu. Rzuca wyjątek z treścią błędu.
	 *
	 * @param	string	$to
	 * @return	void
	 * @throws	\IPS\Email\Outgoing\Exception
	 */
	public static function awssesSendTest( string $to )
	{
		$html = '<p>To jest testowa wiadomość z integracji <strong>AWS SES</strong> (IQL vel Espectro).</p>'
			. '<p>Tryb: <strong>' . \htmlspecialchars( (string) \IPS\Settings::i()->awsses_mode, ENT_QUOTES, 'UTF-8' ) . '</strong>'
			. ', host: <strong>' . \htmlspecialchars( \IPS\awsses\Outgoing\Smtp::sesHost(), ENT_QUOTES, 'UTF-8' ) . '</strong>.</p>';

		$previousForce    = static::$awssesForce;
		$previousCampaign = static::$awssesCampaign;
		static::$awssesForce    = TRUE;
		static::$awssesCampaign = 'test';
		try
		{
			$email = \IPS\Email::buildFromContent( 'AWS SES — test wysyłki', $html, NULL, \IPS\Email::TYPE_TRANSACTIONAL, \IPS\Email::WRAPPER_USE, 'awsses_test', FALSE );
			$email->_send( $to );
		}
		finally
		{
			static::$awssesForce    = $previousForce;
			static::$awssesCampaign = $previousCampaign;
		}
	}
}
