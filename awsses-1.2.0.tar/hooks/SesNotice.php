//<?php

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	exit;
}

/**
 * Komunikat na forum dla zalogowanego, którego adres e-mail jest na liście supresji SES
 * (odbicia / skargi): „Twój adres nie działa — zmień go”. \IPS\Dispatcher\Front nie jest abstrakcyjna.
 */
class awsses_hook_SesNotice extends _HOOK_CLASS_
{
	/**
	 * Finish
	 *
	 * @return	void
	 */
	public function finish()
	{
		try
		{
			if ( !\IPS\Request::i()->isAjax() AND \IPS\Settings::i()->awsses_notice_enabled AND \IPS\Member::loggedIn()->member_id )
			{
				$notice = \IPS\awsses\Suppression::noticeHtml( \IPS\Member::loggedIn() );
				if ( $notice !== '' )
				{
					\IPS\Output::i()->output = $notice . \IPS\Output::i()->output;
				}
			}
		}
		catch ( \Throwable $e )
		{
			/* Komunikat nigdy nie może zepsuć strony forum */
		}

		return parent::finish();
	}
}
