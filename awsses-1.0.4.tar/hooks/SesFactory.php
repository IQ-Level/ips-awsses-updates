//<?php

/**
 * AWS SES Integration — routing hook (code hook na \IPS\Email).
 *
 * factory($type):
 *  - gdy $awssesForce = TRUE (trwa wysyłka masowa przez SES albo test) → zawsze transport SES,
 *  - 'bulk' + awsses_route_bulk → SES,
 *  - 'newsletter' + awsses_route_newsletter → SES,
 *  - reszta (transakcyjne, powiadomienia) → parent::factory() (SMTP forum).
 *
 * @author  IQL vel Espectro
 * @package awsses
 */

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	exit;
}

class awsses_hook_SesFactory extends _HOOK_CLASS_
{
	/**
	 * @brief	Wymuszenie transportu SES (ustawiane przez mergeAndSend transportu SES i przez test).
	 */
	public static $awssesForce = FALSE;

	/**
	 * Factory
	 *
	 * @param	string	$type
	 * @return	\IPS\Email
	 */
	protected static function factory( $type )
	{
		try
		{
			if ( static::$awssesForce )
			{
				return static::awssesHandler();
			}

			if ( \IPS\Settings::i()->awsses_enabled AND static::awssesConfigured() )
			{
				if ( $type === \IPS\Email::TYPE_BULK AND \IPS\Settings::i()->awsses_route_bulk )
				{
					return static::awssesHandler();
				}
				if ( $type === 'newsletter' AND \IPS\Settings::i()->awsses_route_newsletter )
				{
					return static::awssesHandler();
				}
			}

			return \call_user_func_array( 'parent::factory', \func_get_args() );
		}
		catch ( \Error | \RuntimeException $e )
		{
			if ( \defined( '\IPS\DEBUG_HOOKS' ) AND \IPS\DEBUG_HOOKS )
			{
				\IPS\Log::log( $e, 'hook_exception' );
			}

			if ( method_exists( get_parent_class(), __FUNCTION__ ) )
			{
				return \call_user_func_array( 'parent::' . __FUNCTION__, \func_get_args() );
			}
			else
			{
				throw $e;
			}
		}
	}

	/**
	 * Czy SES ma minimalną konfigurację?
	 *
	 * @return	bool
	 */
	public static function awssesConfigured(): bool
	{
		$s = \IPS\Settings::i();
		if ( $s->awsses_mode === 'api' )
		{
			return (bool) ( $s->awsses_region AND $s->awsses_access_key AND $s->awsses_secret_key );
		}
		return (bool) ( ( $s->awsses_smtp_host OR $s->awsses_region ) AND $s->awsses_smtp_user AND $s->awsses_smtp_pass );
	}

	/**
	 * Transport SES wg trybu
	 *
	 * @return	\IPS\Email
	 */
	public static function awssesHandler(): \IPS\Email
	{
		if ( \IPS\Settings::i()->awsses_mode === 'api' )
		{
			return new \IPS\awsses\Outgoing\Api;
		}
		return new \IPS\awsses\Outgoing\Smtp;
	}

	/**
	 * Wysyłka testowa przez SES — tą samą ścieżką co prawdziwa wysyłka (buildFromContent rdzenia),
	 * niezależnie od włącznika i przełączników routingu. Rzuca wyjątek z treścią błędu.
	 *
	 * @param	string	$to
	 * @return	void
	 * @throws	\IPS\Email\Outgoing\Exception
	 */
	public static function awssesSendTest( string $to )
	{
		$html = '<p>To jest testowa wiadomość z integracji <strong>AWS SES</strong> (IQL vel Espectro).</p>'
			. '<p>Tryb: <strong>' . \htmlspecialchars( (string) \IPS\Settings::i()->awsses_mode, ENT_QUOTES, 'UTF-8' ) . '</strong>'
			. ', host: <strong>' . \htmlspecialchars( \IPS\awsses\Outgoing\Smtp::sesHost(), ENT_QUOTES, 'UTF-8' ) . '</strong>.</p>';

		$previous = static::$awssesForce;
		static::$awssesForce = TRUE;
		try
		{
			$email = \IPS\Email::buildFromContent( 'AWS SES — test wysyłki', $html, NULL, \IPS\Email::TYPE_TRANSACTIONAL, \IPS\Email::WRAPPER_USE, 'awsses_test', FALSE );
		}
		finally
		{
			static::$awssesForce = $previous;
		}

		$email->_send( $to );
	}
}
