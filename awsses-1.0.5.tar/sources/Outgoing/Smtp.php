<?php
/**
 * AWS SES — transport SMTP.
 *
 * Rozszerza rdzeniowy \IPS\Email\Outgoing\Smtp (połączenie, STARTTLS, AUTH, logowanie błędów).
 * Dodaje:
 *  - konfigurację z ustawień aplikacji (host / user / hasło),
 *  - domyślny nadawca = awsses_from,
 *  - nagłówek X-SES-CONFIGURATION-SET (zdarzenia SNS: bounce/complaint/statystyki),
 *  - mergeAndSend(): wymusza SES dla KAŻDEGO odbiorcy i pomija adresy z listy supresji.
 *
 * Dlaczego wymuszenie: bazowe mergeAndSend() buduje każdą wiadomość od nowa przez
 * buildFromContent(..., $this->type). Aplikacja Newsletters zmienia typ 'newsletter' na 'list',
 * więc bez wymuszenia wiadomości do odbiorców poszłyby zwykłym SMTP forum.
 *
 * @author  IQL vel Espectro
 * @package awsses
 */

namespace IPS\awsses\Outgoing;

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( isset( $_SERVER['SERVER_PROTOCOL'] ) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

/**
 * SES SMTP transport
 */
class _Smtp extends \IPS\Email\Outgoing\Smtp
{
	/**
	 * Host SMTP wg ustawień: własny albo email-smtp.<region>.amazonaws.com
	 *
	 * @return	string
	 */
	public static function sesHost(): string
	{
		$custom = \trim( (string) \IPS\Settings::i()->awsses_smtp_host );
		return $custom !== '' ? $custom : 'email-smtp.' . \IPS\Settings::i()->awsses_region . '.amazonaws.com';
	}

	/**
	 * Konstruktor — parametry z ustawień aplikacji
	 */
	public function __construct()
	{
		parent::__construct( 'tls', static::sesHost(), 587, \IPS\Settings::i()->awsses_smtp_user, \IPS\Settings::i()->awsses_smtp_pass );
	}

	/**
	 * Domyślny nadawca + nagłówek Configuration Set
	 *
	 * @param	mixed	$fromEmail
	 * @param	array	$additionalHeaders
	 * @return	array	[ $fromEmail, $additionalHeaders ]
	 */
	protected function awssesPrepare( $fromEmail, array $additionalHeaders ): array
	{
		if ( !$fromEmail AND \IPS\Settings::i()->awsses_from )
		{
			$fromEmail = \IPS\Settings::i()->awsses_from;
		}
		if ( \IPS\Settings::i()->awsses_configuration_set )
		{
			$additionalHeaders['X-SES-CONFIGURATION-SET'] = \IPS\Settings::i()->awsses_configuration_set;
		}
		return array( $fromEmail, $additionalHeaders );
	}

	/**
	 * Wyślij (SMTP do SES)
	 *
	 * @param	mixed	$to
	 * @param	mixed	$cc
	 * @param	mixed	$bcc
	 * @param	mixed	$fromEmail
	 * @param	mixed	$fromName
	 * @param	array	$additionalHeaders
	 * @return	void
	 * @throws	\IPS\Email\Outgoing\Exception
	 */
	public function _send( $to, $cc = array(), $bcc = array(), $fromEmail = NULL, $fromName = NULL, $additionalHeaders = array() )
	{
		list( $fromEmail, $additionalHeaders ) = $this->awssesPrepare( $fromEmail, (array) $additionalHeaders );
		parent::_send( $to, $cc, $bcc, $fromEmail, $fromName, $additionalHeaders );
	}

	/**
	 * Wysyłka masowa — każdy odbiorca przez SES, z pominięciem adresów z supresji.
	 *
	 * @param	array			$recipients			[ email => [ zmienne ] ]
	 * @param	mixed			$fromEmail
	 * @param	mixed			$fromName
	 * @param	array			$additionalHeaders
	 * @param	\IPS\Lang|NULL	$language
	 * @return	int				Liczba udanych wysyłek
	 */
	public function mergeAndSend( $recipients, $fromEmail = NULL, $fromName = NULL, $additionalHeaders = array(), \IPS\Lang $language = NULL )
	{
		$recipients = \IPS\awsses\Suppression::filterRecipients( (array) $recipients );
		if ( !\count( $recipients ) )
		{
			return 0;
		}

		$previous = \IPS\Email::$awssesForce;
		\IPS\Email::$awssesForce = TRUE;
		try
		{
			return parent::mergeAndSend( $recipients, $fromEmail, $fromName, $additionalHeaders, $language );
		}
		finally
		{
			\IPS\Email::$awssesForce = $previous;
		}
	}
}
