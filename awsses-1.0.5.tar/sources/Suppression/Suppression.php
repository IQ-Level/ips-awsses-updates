<?php
/**
 * AWS SES Integration — supresja i zdarzenia.
 *
 * Tabele awsses_suppressions / awsses_events tworzy instalator z data/schema.json.
 * Metody statyczne; guard checkForTable na wypadek wywołania przed instalacją.
 *
 * @author  IQL vel Espectro
 * @package awsses
 */

namespace IPS\awsses;

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( isset( $_SERVER['SERVER_PROTOCOL'] ) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

/**
 * Suppression
 */
class _Suppression
{
	/**
	 * Zapisz supresję adresu i zsynchronizuj stan w IPS (allow_admin_mails=0).
	 *
	 * @param	string	$email	 Adres
	 * @param	string	$reason	 'bounce' | 'complaint'
	 * @param	string	$detail	 Szczegół
	 * @return	void
	 */
	public static function suppress( string $email, string $reason, string $detail = '' ): void
	{
		$email = \mb_strtolower( \trim( $email ) );
		if ( $email === '' ) { return; }

		if ( \IPS\Db::i()->checkForTable( 'awsses_suppressions' ) )
		{
			\IPS\Db::i()->insert( 'awsses_suppressions', array(
				'sup_email'  => $email,
				'sup_reason' => $reason,
				'sup_ts'     => \time(),
				'sup_detail' => \mb_substr( $detail, 0, 60000 ),
			), TRUE );
		}

		try
		{
			$member = \IPS\Member::load( $email, 'email' );
			if ( $member->member_id AND $member->allow_admin_mails )
			{
				$member->allow_admin_mails = 0;
				$member->save();
				$member->logHistory( 'core', 'admin_mails', array( 'enabled' => FALSE, 'awsses' => $reason ) );
			}
		}
		catch ( \Exception $e ) {}
	}

	/**
	 * Czy adres jest na liście supresji?
	 *
	 * @param	string	$email
	 * @return	bool
	 */
	public static function isSuppressed( string $email ): bool
	{
		$email = \mb_strtolower( \trim( $email ) );
		if ( $email === '' ) { return FALSE; }

		try
		{
			if ( !\IPS\Db::i()->checkForTable( 'awsses_suppressions' ) ) { return FALSE; }
			return (bool) \IPS\Db::i()->select( 'COUNT(*)', 'awsses_suppressions', array( 'sup_email=?', $email ) )->first();
		}
		catch ( \Exception $e ) { return FALSE; }
	}

	/**
	 * Usuń z listy odbiorców adresy z supresji (jedno zapytanie na paczkę po 500).
	 *
	 * @param	array	$recipients	[ email => zmienne ]
	 * @return	array
	 */
	public static function filterRecipients( array $recipients ): array
	{
		if ( !\count( $recipients ) )
		{
			return $recipients;
		}

		try
		{
			if ( !\IPS\Db::i()->checkForTable( 'awsses_suppressions' ) )
			{
				return $recipients;
			}

			$blocked = array();
			foreach ( \array_chunk( \array_map( function( $e ) { return \mb_strtolower( \trim( (string) $e ) ); }, \array_keys( $recipients ) ), 500 ) as $chunk )
			{
				foreach ( \IPS\Db::i()->select( 'sup_email', 'awsses_suppressions', \IPS\Db::i()->in( 'sup_email', $chunk ) ) as $email )
				{
					$blocked[ $email ] = TRUE;
				}
			}

			if ( !$blocked )
			{
				return $recipients;
			}

			$out = array();
			foreach ( $recipients as $email => $vars )
			{
				if ( !isset( $blocked[ \mb_strtolower( \trim( (string) $email ) ) ] ) )
				{
					$out[ $email ] = $vars;
				}
			}
			return $out;
		}
		catch ( \Exception $e )
		{
			return $recipients;
		}
	}

	/**
	 * Zapisz zdarzenie do statystyk.
	 *
	 * @param	string	$type	 send|delivery|bounce|complaint|open|click|reject|subscription
	 * @param	string	$email
	 * @param	string	$config	 Configuration Set
	 * @return	void
	 */
	public static function recordEvent( string $type, string $email = '', string $config = '' ): void
	{
		if ( !\IPS\Db::i()->checkForTable( 'awsses_events' ) ) { return; }

		\IPS\Db::i()->insert( 'awsses_events', array(
			'ev_type'   => \mb_substr( $type, 0, 20 ),
			'ev_email'  => $email ? \mb_strtolower( \mb_substr( $email, 0, 255 ) ) : NULL,
			'ev_config' => $config ? \mb_substr( $config, 0, 100 ) : NULL,
			'ev_ts'     => \time(),
		) );
	}
}
