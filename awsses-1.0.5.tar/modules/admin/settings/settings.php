<?php
/**
 * AWS SES Integration — kontroler ustawień ACP.
 *
 * Zakładki: Połączenie, Routing, Diagnostyka, Statystyki. Test wysyłki = osobna akcja do=test.
 *
 * @author  IQL vel Espectro
 * @package awsses
 */

namespace IPS\awsses\modules\admin\settings;

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( isset( $_SERVER['SERVER_PROTOCOL'] ) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

/**
 * settings
 */
class _settings extends \IPS\Dispatcher\Controller
{
	/**
	 * @brief	Kontroler sam obsługuje CSRF (formularze IPS mają własną ochronę; linki do=test
	 *			i awsses_diag tylko wyświetlają). Bez tej flagi IPS ACP wymusza csrfCheck() na każdym
	 *			żądaniu z parametrem poza app/module/controller/id → błąd 2S119/1.
	 */
	public static $csrfProtected = TRUE;

	/**
	 * Execute
	 *
	 * @return	void
	 */
	public function execute()
	{
		\IPS\Dispatcher::i()->checkAcpPermission( 'settings_manage' );
		parent::execute();
	}

	/**
	 * Regiony SES
	 *
	 * @return	array
	 */
	protected function sesRegions(): array
	{
		return array(
			'eu-central-1' => 'Europe (Frankfurt) — eu-central-1',
			'eu-west-1'    => 'Europe (Ireland) — eu-west-1',
			'eu-west-2'    => 'Europe (London) — eu-west-2',
			'eu-west-3'    => 'Europe (Paris) — eu-west-3',
			'eu-north-1'   => 'Europe (Stockholm) — eu-north-1',
			'eu-south-1'   => 'Europe (Milan) — eu-south-1',
			'us-east-1'    => 'US East (N. Virginia) — us-east-1',
			'us-east-2'    => 'US East (Ohio) — us-east-2',
			'us-west-2'    => 'US West (Oregon) — us-west-2',
		);
	}

	/**
	 * Ustawienia
	 *
	 * @return	void
	 */
	protected function manage()
	{
		$s    = \IPS\Settings::i();
		$self = \IPS\Http\Url::internal( 'app=awsses&module=settings&controller=settings' );

		$form = new \IPS\Helpers\Form;

		/* --- Połączenie --- */
		$form->addTab( 'awsses_tab_connection', 'cloud' );
		$form->addHeader( 'awsses_hdr_general' );
		$form->add( new \IPS\Helpers\Form\YesNo( 'awsses_enabled', $s->awsses_enabled, FALSE ) );
		$form->add( new \IPS\Helpers\Form\Select( 'awsses_mode', $s->awsses_mode ?: 'smtp', TRUE, array(
			'options' => array( 'smtp' => 'awsses_mode_smtp', 'api' => 'awsses_mode_api' ),
			'toggles' => array( 'smtp' => array( 'awsses_csv_file', 'awsses_smtp_host', 'awsses_smtp_user', 'awsses_smtp_pass' ), 'api' => array( 'awsses_access_key', 'awsses_secret_key' ) )
		) ) );
		$form->add( new \IPS\Helpers\Form\Select( 'awsses_region', $s->awsses_region ?: 'eu-central-1', TRUE, array( 'options' => $this->sesRegions() ) ) );
		$form->add( new \IPS\Helpers\Form\Email( 'awsses_from', $s->awsses_from ?: NULL, FALSE, array( 'placeholder' => $s->email_out ) ) );
		$form->add( new \IPS\Helpers\Form\Text( 'awsses_configuration_set', $s->awsses_configuration_set, FALSE ) );

		$form->addHeader( 'awsses_hdr_smtp' );
		$form->add( new \IPS\Helpers\Form\Upload( 'awsses_csv_file', NULL, FALSE, array( 'allowedFileTypes' => array( 'csv', 'txt' ), 'temporary' => TRUE, 'multiple' => FALSE ), NULL, NULL, NULL, 'awsses_csv_file' ) );
		$form->add( new \IPS\Helpers\Form\Text( 'awsses_smtp_host', $s->awsses_smtp_host, FALSE, array( 'placeholder' => 'email-smtp.' . ( $s->awsses_region ?: 'eu-central-1' ) . '.amazonaws.com' ), NULL, NULL, NULL, 'awsses_smtp_host' ) );
		$form->add( new \IPS\Helpers\Form\Text( 'awsses_smtp_user', $s->awsses_smtp_user, FALSE, array(), NULL, NULL, NULL, 'awsses_smtp_user' ) );
		$form->add( new \IPS\Helpers\Form\Password( 'awsses_smtp_pass', $s->awsses_smtp_pass, FALSE, array( 'enforceMaxLimit' => FALSE ), NULL, NULL, NULL, 'awsses_smtp_pass' ) );

		$form->addHeader( 'awsses_hdr_api' );
		$form->add( new \IPS\Helpers\Form\Text( 'awsses_access_key', $s->awsses_access_key, FALSE, array(), NULL, NULL, NULL, 'awsses_access_key' ) );
		$form->add( new \IPS\Helpers\Form\Password( 'awsses_secret_key', $s->awsses_secret_key, FALSE, array( 'enforceMaxLimit' => FALSE ), NULL, NULL, NULL, 'awsses_secret_key' ) );

		$form->addHeader( 'awsses_hdr_sns' );
		$form->add( new \IPS\Helpers\Form\Text( 'awsses_sns_token', $s->awsses_sns_token, FALSE ) );

		/* --- Routing --- */
		$form->addTab( 'awsses_tab_routing', 'random' );
		$form->addMessage( 'awsses_routing_help', 'ipsMessage ipsMessage_info' );
		$form->add( new \IPS\Helpers\Form\YesNo( 'awsses_route_bulk', $s->awsses_route_bulk, FALSE ) );
		$form->add( new \IPS\Helpers\Form\YesNo( 'awsses_route_newsletter', $s->awsses_route_newsletter, FALSE ) );

		/* --- Zapis --- */
		if ( $values = $form->values() )
		{
			/* Wgrany CSV z AWS → Host/Użytkownik/Hasło (plik tylko czytamy, nie przechowujemy) */
			if ( !empty( $values['awsses_csv_file'] ) AND @\is_file( (string) $values['awsses_csv_file'] ) )
			{
				$parsed = \IPS\awsses\Aws\Credentials::parseCsv( (string) @\file_get_contents( (string) $values['awsses_csv_file'] ) );
				if ( $parsed )
				{
					if ( $parsed['host'] !== '' ) { $values['awsses_smtp_host'] = $parsed['host']; }
					$values['awsses_smtp_user'] = $parsed['user'];
					$values['awsses_smtp_pass'] = $parsed['pass'];
				}
			}
			unset( $values['awsses_csv_file'] );

			$values['awsses_from'] = (string) ( $values['awsses_from'] ?? '' );

			$form->saveAsSettings( $values );
			\IPS\Output::i()->redirect( $self, 'saved' );
		}

		/* --- Diagnostyka / Statystyki (tylko wyświetlanie) --- */
		$form->addTab( 'awsses_tab_diagnostics', 'stethoscope' );
		$form->addHtml( $this->diagnosticsHtml( $self ) );

		$form->addTab( 'awsses_tab_stats', 'bar-chart' );
		$form->addHtml( $this->statsHtml() );

		\IPS\Output::i()->title  = \IPS\Member::loggedIn()->language()->addToStack( 'awsses_settings' );
		\IPS\Output::i()->output = $form;
	}

	/**
	 * Wysyłka testowa (osobna strona z własnym formularzem IPS)
	 *
	 * @return	void
	 */
	protected function test()
	{
		$self = \IPS\Http\Url::internal( 'app=awsses&module=settings&controller=settings' );

		$form = new \IPS\Helpers\Form( 'awsses_test', 'awsses_do_test' );
		$form->add( new \IPS\Helpers\Form\Email( 'awsses_test_email', \IPS\Member::loggedIn()->email, TRUE ) );

		if ( $values = $form->values() )
		{
			try
			{
				\IPS\Email::awssesSendTest( $values['awsses_test_email'] );
				\IPS\Output::i()->redirect( $self, 'awsses_test_sent' );
			}
			catch ( \Exception $e )
			{
				$form->error = \IPS\Member::loggedIn()->language()->addToStack( 'awsses_test_failed' ) . ' ' . $e->getMessage();
			}
		}

		\IPS\Output::i()->title  = \IPS\Member::loggedIn()->language()->addToStack( 'awsses_do_test' );
		\IPS\Output::i()->output = $form;
	}

	/**
	 * Wiersz wyniku
	 */
	protected function row( string $state, string $label, string $detail = '' ): string
	{
		$color = $state === 'pass' ? '#1a7f37' : ( $state === 'warn' ? '#9a6700' : '#b42318' );
		$icon  = $state === 'pass' ? '✓' : ( $state === 'warn' ? '!' : '✕' );
		$d = $detail !== '' ? "<div style='opacity:.8;margin-top:2px'>{$detail}</div>" : '';
		return "<div style='padding:6px 0;border-bottom:1px solid rgba(128,128,128,.2)'><span style='display:inline-block;width:20px;color:{$color};font-weight:bold'>{$icon}</span><strong>{$label}</strong>{$d}</div>";
	}

	/**
	 * Escapowanie
	 */
	protected function e( $v ): string
	{
		return \htmlspecialchars( (string) $v, ENT_QUOTES, 'UTF-8' );
	}

	/**
	 * Rekordy TXT
	 */
	protected function txt( string $host ): array
	{
		$out = array();
		foreach ( @\dns_get_record( $host, DNS_TXT ) ?: array() as $r )
		{
			if ( isset( $r['txt'] ) ) { $out[] = $r['txt']; }
			elseif ( isset( $r['entries'] ) ) { $out[] = \implode( '', $r['entries'] ); }
		}
		return $out;
	}

	/**
	 * HTML diagnostyki
	 */
	protected function diagnosticsHtml( \IPS\Http\Url $self ): string
	{
		$s       = \IPS\Settings::i();
		$from    = $s->awsses_from ?: $s->email_out;
		$domain  = ( $from AND \strpos( $from, '@' ) !== FALSE ) ? \mb_strtolower( \substr( \strrchr( $from, '@' ), 1 ) ) : '';
		$isApi   = ( $s->awsses_mode === 'api' );
		$host    = \IPS\awsses\Outgoing\Smtp::sesHost();
		$config  = \IPS\Email::awssesConfigured();

		$h  = "<h3>Stan integracji</h3>";
		$h .= $this->row( $s->awsses_enabled ? 'pass' : 'warn', 'Integracja ' . ( $s->awsses_enabled ? 'włączona' : 'wyłączona (poczta idzie jak dotąd)' ) );
		$h .= $this->row( $config ? 'pass' : 'fail', $config ? 'Konfiguracja kompletna' : 'Konfiguracja niekompletna', $config ? '' : ( $isApi ? 'Uzupełnij region i klucze IAM.' : 'Uzupełnij użytkownika i hasło SMTP (najprościej: wgraj plik CSV z AWS).' ) );
		$h .= $this->row( 'pass', 'Tryb: ' . ( $isApi ? 'API v2' : 'SMTP' ) . ( $isApi ? ' — email.' . $this->e( $s->awsses_region ) . '.amazonaws.com' : ' — ' . $this->e( $host ) . ':587' ) );
		$h .= $this->row( $domain ? 'pass' : 'fail', 'Nadawca (From): ' . ( $from ? $this->e( $from ) : 'brak' ) );
		$h .= $this->row( $s->awsses_route_bulk ? 'pass' : 'warn', 'Bulk Mail przez SES: ' . ( $s->awsses_route_bulk ? 'TAK' : 'nie' ) );
		$h .= $this->row( $s->awsses_route_newsletter ? 'pass' : 'warn', 'Newslettery przez SES: ' . ( $s->awsses_route_newsletter ? 'TAK' : 'nie' ) );
		$h .= $this->row( $s->awsses_configuration_set ? 'pass' : 'warn', 'Configuration Set: ' . ( $s->awsses_configuration_set ? $this->e( $s->awsses_configuration_set ) : 'brak (bez niego nie będzie bounce/complaint ani statystyk)' ) );

		if ( !$isApi AND \stripos( $host, 'mail-manager' ) !== FALSE )
		{
			$h .= $this->row( 'warn', 'Host to endpoint Mail Managera',
				'To endpoint ingress Mail Managera — poczta zostanie przyjęta, ale do odbiorców trafi tylko, jeśli w Mail Managerze masz regułę z akcją „Send to Internet”. '
				. 'Prościej i taniej: SES → SMTP settings → <em>Create IAM SMTP credentials</em> (host email-smtp.' . $this->e( $s->awsses_region ) . '.amazonaws.com).' );
		}

		/* DNS + połączenie (na żądanie) */
		$h .= "<h3 style='margin-top:16px'>DNS i połączenie</h3>";
		if ( \IPS\Request::i()->awsses_diag )
		{
			if ( $domain )
			{
				$spf = NULL;
				foreach ( $this->txt( $domain ) as $t ) { if ( \stripos( $t, 'v=spf1' ) === 0 ) { $spf = $t; break; } }
				if ( $spf === NULL ) { $h .= $this->row( 'warn', "SPF ({$this->e( $domain )}) — brak", 'Przy custom MAIL FROM wystarczy SPF na subdomenie MAIL FROM; inaczej dodaj include:amazonses.com.' ); }
				elseif ( \stripos( $spf, 'amazonses.com' ) !== FALSE ) { $h .= $this->row( 'pass', 'SPF zawiera amazonses.com', $this->e( $spf ) ); }
				else { $h .= $this->row( 'warn', 'SPF bez amazonses.com', $this->e( $spf ) . ' — OK, jeśli używasz custom MAIL FROM.' ); }

				$dmarc = $this->txt( "_dmarc.{$domain}" );
				$dmarc = \array_values( \array_filter( $dmarc, function( $t ) { return \stripos( $t, 'v=DMARC1' ) === 0; } ) );
				if ( \count( $dmarc ) === 1 ) { $h .= $this->row( 'pass', 'DMARC obecny', $this->e( $dmarc[0] ) ); }
				elseif ( \count( $dmarc ) > 1 ) { $h .= $this->row( 'fail', 'DMARC — ' . \count( $dmarc ) . ' rekordy (ma być dokładnie jeden)', $this->e( \implode( ' | ', $dmarc ) ) ); }
				else { $h .= $this->row( 'warn', 'DMARC — brak', 'Zalecane: v=DMARC1; p=none; rua=mailto:...' ); }

				$h .= $this->row( 'warn', 'DKIM', 'Status DKIM sprawdź w konsoli SES (Verified identities → domena); aplikacja nie zna tokenów CNAME.' );
			}

			try
			{
				if ( $isApi )
				{
					$acc = ( new \IPS\awsses\Outgoing\Api )->apiGet( '/v2/email/account' );
					$prod = !empty( $acc['ProductionAccessEnabled'] );
					$h .= $this->row( 'pass', 'API SES: połączono i uwierzytelniono' );
					$h .= $this->row( $prod ? 'pass' : 'warn', 'Dostęp produkcyjny: ' . ( $prod ? 'TAK' : 'NIE — piaskownica (wysyłka tylko do zweryfikowanych adresów)' ) );
					if ( isset( $acc['SendQuota'] ) )
					{
						$q = $acc['SendQuota'];
						$h .= $this->row( 'pass', 'Limit 24h: ' . (int) ( $q['Max24HourSend'] ?? 0 ) . ', wysłane 24h: ' . (int) ( $q['SentLast24Hours'] ?? 0 ) . ', max/s: ' . $this->e( $q['MaxSendRate'] ?? 0 ) );
					}
				}
				elseif ( $config )
				{
					( new \IPS\awsses\Outgoing\Smtp )->connect();
					$h .= $this->row( 'pass', 'SMTP: połączono i uwierzytelniono w ' . $this->e( $host ) . ':587' );
				}
				else
				{
					$h .= $this->row( 'warn', 'Test połączenia pominięty', 'Najpierw uzupełnij i zapisz poświadczenia.' );
				}
			}
			catch ( \Exception $e )
			{
				$h .= $this->row( 'fail', 'Połączenie nieudane', $this->e( $e->getMessage() ) );
			}
		}
		else
		{
			$h .= "<p><a class='ipsButton ipsButton_primary ipsButton_small' href='" . $this->e( $self->setQueryString( array( 'awsses_diag' => 1, 'activeTab' => 'awsses_tab_diagnostics' ) ) ) . "'>Sprawdź DNS i połączenie</a></p>";
		}

		/* Test */
		$h .= "<h3 style='margin-top:16px'>Wysyłka testowa</h3>";
		$h .= "<p><a class='ipsButton ipsButton_important ipsButton_small' href='" . $this->e( $self->setQueryString( 'do', 'test' ) ) . "'>Wyślij wiadomość testową przez SES</a></p>";

		/* SNS */
		$sns = \rtrim( (string) $s->base_url, '/' ) . '/applications/awsses/interface/sns/sns.php' . ( $s->awsses_sns_token ? '?t=' . \rawurlencode( $s->awsses_sns_token ) : '' );
		$h .= "<h3 style='margin-top:16px'>Endpoint SNS (bounce / complaint / statystyki)</h3>";
		$h .= "<p>W SES: Configuration Set → Event destinations → Amazon SNS → subskrypcja HTTPS na adres:</p>";
		$h .= "<code style='display:block;padding:8px;border-radius:6px;word-break:break-all;background:rgba(128,128,128,.15)'>" . $this->e( $sns ) . "</code>";

		return $h;
	}

	/**
	 * HTML statystyk
	 */
	protected function statsHtml(): string
	{
		$h = "<h3>Zdarzenia SES z ostatnich 30 dni</h3>";
		try
		{
			if ( !\IPS\Db::i()->checkForTable( 'awsses_events' ) )
			{
				return $h . "<p>Brak tabeli zdarzeń — przeinstaluj aplikację.</p>";
			}

			$counts = array();
			foreach ( \IPS\Db::i()->select( 'ev_type, COUNT(*) as c', 'awsses_events', array( 'ev_ts>?', \time() - 30 * 86400 ), NULL, NULL, 'ev_type' ) as $r )
			{
				$counts[ $r['ev_type'] ] = (int) $r['c'];
			}

			$labels = array( 'send' => 'Wysłane', 'delivery' => 'Dostarczone', 'open' => 'Otwarcia', 'click' => 'Kliknięcia', 'bounce' => 'Odbicia', 'complaint' => 'Skargi', 'reject' => 'Odrzucone' );
			$h .= "<div style='display:flex;flex-wrap:wrap;gap:12px'>";
			foreach ( $labels as $k => $lab )
			{
				$h .= "<div style='min-width:110px;padding:10px 14px;border:1px solid rgba(128,128,128,.3);border-radius:8px;text-align:center'><div style='font-size:22px;font-weight:bold'>" . (int) ( $counts[ $k ] ?? 0 ) . "</div><div style='opacity:.7;font-size:12px'>" . $this->e( $lab ) . "</div></div>";
			}
			$h .= "</div>";

			if ( !$counts )
			{
				$h .= "<p style='margin-top:10px;opacity:.8'>Brak zdarzeń — pojawią się po podpięciu Configuration Set + SNS (adres w zakładce Diagnostyka).</p>";
			}

			$sup = \IPS\Db::i()->checkForTable( 'awsses_suppressions' ) ? (int) \IPS\Db::i()->select( 'COUNT(*)', 'awsses_suppressions' )->first() : 0;
			$h .= "<h3 style='margin-top:16px'>Lista supresji: {$sup}</h3>";
			if ( $sup )
			{
				$h .= "<table class='ipsTable'><tr><th>Adres</th><th>Powód</th><th>Data</th></tr>";
				foreach ( \IPS\Db::i()->select( '*', 'awsses_suppressions', NULL, 'sup_ts DESC', 20 ) as $r )
				{
					$h .= "<tr><td>" . $this->e( $r['sup_email'] ) . "</td><td>" . $this->e( $r['sup_reason'] ) . "</td><td>" . $this->e( \IPS\DateTime::ts( $r['sup_ts'] ) ) . "</td></tr>";
				}
				$h .= "</table>";
			}
		}
		catch ( \Exception $e )
		{
			$h .= "<p>Błąd odczytu: " . $this->e( $e->getMessage() ) . "</p>";
		}
		return $h;
	}
}
