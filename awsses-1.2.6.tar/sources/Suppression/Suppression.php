<?php
/**
 * AWS SES Integration — supresja i zdarzenia.
 *
 * Tabele awsses_suppressions / awsses_events tworzy instalator z data/schema.json.
 * Metody statyczne; guard checkForTable na wypadek wywołania przed instalacją.
 *
 * @author  IQL vel Espectro
 * @package awsses
 */

namespace IPS\awsses;

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( isset( $_SERVER['SERVER_PROTOCOL'] ) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

/**
 * Suppression
 */
class _Suppression
{
	/**
	 * Zapisz supresję adresu i zsynchronizuj stan w IPS (allow_admin_mails=0).
	 *
	 * @param	string	$email	 Adres
	 * @param	string	$reason	 'bounce' | 'complaint'
	 * @param	string	$detail	 Szczegół
	 * @return	void
	 */
	public static function suppress( string $email, string $reason, string $detail = '' ): void
	{
		$email = \mb_strtolower( \trim( $email ) );
		if ( $email === '' ) { return; }

		/* Konto forum z tym adresem: wyłącz maile od administracji (zapamiętaj, że to my — przy zmianie adresu wrócą) */
		$memberId = 0;
		$mailsOff = 0;
		try
		{
			$member = \IPS\Member::load( $email, 'email' );
			if ( $member->member_id )
			{
				$memberId = (int) $member->member_id;
				if ( $member->allow_admin_mails )
				{
					$member->allow_admin_mails = 0;
					$member->save();
					$member->logHistory( 'core', 'admin_mails', array( 'enabled' => FALSE, 'awsses' => $reason ) );
					$mailsOff = 1;
				}
			}
		}
		catch ( \Exception $e ) {}

		if ( !\IPS\Db::i()->checkForTable( 'awsses_suppressions' ) )
		{
			return;
		}

		$base = array( 'sup_email' => $email, 'sup_reason' => $reason, 'sup_ts' => \time(), 'sup_detail' => \mb_substr( $detail, 0, 60000 ) );
		if ( !static::hasMemberColumns() )
		{
			/* Niedokończona aktualizacja do 1.2.0 */
			\IPS\Db::i()->insert( 'awsses_suppressions', $base, TRUE );
			return;
		}

		try
		{
			$existing = \IPS\Db::i()->select( '*', 'awsses_suppressions', array( 'sup_email=?', $email ) )->first();
			/* Ponowne odbicie: nie gub informacji o PW i o wyłączonych mailach */
			\IPS\Db::i()->update( 'awsses_suppressions', array(
				'sup_reason'      => $reason,
				'sup_ts'          => $base['sup_ts'],
				'sup_detail'      => $base['sup_detail'],
				'sup_member_id'   => $memberId ?: (int) $existing['sup_member_id'],
				'sup_mails_off'   => \max( (int) $existing['sup_mails_off'], $mailsOff ),
				'sup_resolved_ts' => 0,
			), array( 'sup_id=?', $existing['sup_id'] ) );
			$row = \array_merge( $existing, array( 'sup_member_id' => $memberId ?: (int) $existing['sup_member_id'] ) );
		}
		catch ( \UnderflowException $e )
		{
			$row = $base + array( 'sup_member_id' => $memberId, 'sup_mails_off' => $mailsOff, 'sup_pm_ts' => 0, 'sup_resolved_ts' => 0 );
			$row['sup_id'] = \IPS\Db::i()->insert( 'awsses_suppressions', $row );
		}

		/* Automatyczna PW z prośbą o zmianę adresu */
		if ( $memberId AND \IPS\Settings::i()->awsses_pm_auto AND !(int) ( $row['sup_pm_ts'] ?? 0 ) )
		{
			try { static::sendPm( $row ); }
			catch ( \Exception $e ) { \IPS\Log::log( $e, 'awsses' ); }
		}
	}

	/**
	 * Czy tabela ma kolumny z 1.2.0 (konto, PW, rozwiązanie)?
	 *
	 * @return	bool
	 */
	public static function hasMemberColumns(): bool
	{
		static $has = NULL;
		if ( $has === NULL )
		{
			try { $has = \IPS\Db::i()->checkForColumn( 'awsses_suppressions', 'sup_pm_ts' ); }
			catch ( \Exception $e ) { $has = FALSE; }
		}
		return $has;
	}

	/* ============================================================ */
	/* Martwy adres użytkownika: komunikat, PW, zmiana adresu        */
	/* ============================================================ */

	/**
	 * Domyślne teksty (gdy w ustawieniach puste). Znaczniki: {name}, {email}, {link}.
	 */
	const DEFAULT_NOTICE   = "Nie możemy dostarczyć wiadomości na Twój adres e-mail {email} — serwer poczty go odrzuca. Przez to nie dostajesz powiadomień ani newslettera. Zmień adres e-mail w ustawieniach konta.";
	const DEFAULT_PM_TITLE = "Twój adres e-mail nie działa — zaktualizuj go";
	const DEFAULT_PM_BODY  = "Cześć {name},\n\nwiadomości wysyłane na Twój adres {email} wracają do nas — serwer poczty odbiorcy go odrzuca (np. skrzynka nie istnieje albo została zamknięta). Przez to nie dostajesz powiadomień z forum ani newslettera.\n\nZmień adres e-mail w ustawieniach konta: {link}\n\nPo zmianie wszystko wróci do normy. Jeśli masz pytania, odpisz na tę wiadomość.";

	/**
	 * Wpis supresji dla aktualnego adresu użytkownika (NULL = adres działa)
	 *
	 * @param	\IPS\Member	$member
	 * @return	array|NULL
	 */
	public static function rowForMember( \IPS\Member $member ): ?array
	{
		$email = \mb_strtolower( \trim( (string) $member->email ) );
		if ( !$member->member_id OR $email === '' ) { return NULL; }
		try
		{
			if ( !\IPS\Db::i()->checkForTable( 'awsses_suppressions' ) ) { return NULL; }
			return \IPS\Db::i()->select( '*', 'awsses_suppressions', array( 'sup_email=?', $email ) )->first();
		}
		catch ( \Exception $e ) { return NULL; }
	}

	/**
	 * Adres strony zmiany e-maila
	 *
	 * @return	\IPS\Http\Url
	 */
	public static function emailSettingsUrl(): \IPS\Http\Url
	{
		return \IPS\Http\Url::internal( 'app=core&module=system&controller=settings&area=email', 'front', 'settings_email' );
	}

	/**
	 * Podstaw znaczniki w tekście (wartości escapowane do HTML)
	 *
	 * @param	string		$text
	 * @param	\IPS\Member	$member
	 * @param	bool		$linkAsAnchor	{link} jako <a> (PW) zamiast samego adresu
	 * @return	string	HTML
	 */
	public static function fillTemplate( string $text, \IPS\Member $member, bool $linkAsAnchor = TRUE ): string
	{
		$e    = function( $v ) { return \htmlspecialchars( (string) $v, ENT_QUOTES, 'UTF-8' ); };
		$url  = (string) static::emailSettingsUrl();
		$html = $e( $text );
		return \str_replace(
			array( '{name}', '{email}', '{link}' ),
			array( $e( $member->name ), '<strong>' . $e( $member->email ) . '</strong>', $linkAsAnchor ? "<a href='" . $e( $url ) . "'>" . $e( $url ) . "</a>" : $e( $url ) ),
			$html
		);
	}

	/**
	 * HTML komunikatu na forum dla zalogowanego z martwym adresem (pusty = nie pokazuj).
	 * Wynik trzymany w sesji 10 min, żeby nie pytać bazy przy każdej stronie.
	 *
	 * @param	\IPS\Member	$member
	 * @return	string
	 */
	public static function noticeHtml( \IPS\Member $member ): string
	{
		if ( !\IPS\Settings::i()->awsses_notice_enabled OR !$member->member_id )
		{
			return '';
		}

		$email = \mb_strtolower( (string) $member->email );
		$cache = $_SESSION['awsses_notice'] ?? NULL;
		if ( !\is_array( $cache ) OR ( $cache['email'] ?? '' ) !== $email OR ( $cache['ts'] ?? 0 ) < \time() - 600 )
		{
			$cache = array( 'email' => $email, 'ts' => \time(), 'bad' => static::rowForMember( $member ) !== NULL );
			$_SESSION['awsses_notice'] = $cache;
		}
		if ( empty( $cache['bad'] ) )
		{
			return '';
		}

		$text = \trim( (string) \IPS\Settings::i()->awsses_notice_text ) ?: static::DEFAULT_NOTICE;
		$url  = \htmlspecialchars( (string) static::emailSettingsUrl(), ENT_QUOTES, 'UTF-8' );
		return "<div class='ipsMessage ipsMessage_warning ipsSpacer_bottom' data-awsses-notice>"
			. static::fillTemplate( $text, $member, FALSE )
			. " <a href='{$url}' class='ipsButton ipsButton_verySmall ipsButton_light ipsSpacer_left ipsSpacer_half'>Zmień adres e-mail</a></div>";
	}

	/**
	 * Wyślij PW z prośbą o zmianę adresu (bez powiadomienia e-mailem — adres i tak nie działa).
	 *
	 * @param	array	$row	wiersz awsses_suppressions
	 * @return	bool	TRUE = wysłano
	 * @throws	\DomainException	brak skonfigurowanego nadawcy
	 */
	public static function sendPm( array $row ): bool
	{
		$s = \IPS\Settings::i();
		$sender = \IPS\Member::load( (int) $s->awsses_pm_sender );
		if ( !$sender->member_id )
		{
			throw new \DomainException( 'Nie ustawiono nadawcy PW (AWS SES → Ustawienia → Martwe adresy).' );
		}

		$member = (int) ( $row['sup_member_id'] ?? 0 ) ? \IPS\Member::load( (int) $row['sup_member_id'] ) : \IPS\Member::load( (string) $row['sup_email'], 'email' );
		/* Tylko gdy konto nadal ma ten martwy adres i nie jest zbanowane */
		if ( !$member->member_id OR $member->member_id == $sender->member_id OR \mb_strtolower( (string) $member->email ) !== \mb_strtolower( (string) $row['sup_email'] ) OR $member->isBanned() )
		{
			return FALSE;
		}

		$title = \trim( (string) $s->awsses_pm_title ) ?: static::DEFAULT_PM_TITLE;
		$body  = \trim( (string) $s->awsses_pm_body ) ?: static::DEFAULT_PM_BODY;
		$html  = '';
		foreach ( \preg_split( "/\r?\n\s*\r?\n/", $body ) as $para )
		{
			$html .= '<p>' . \nl2br( static::fillTemplate( \trim( $para ), $member ) ) . '</p>';
		}

		$conversation = \IPS\core\Messenger\Conversation::createItem( $sender, $sender->ip_address ?: '127.0.0.1', \IPS\DateTime::create() );
		$conversation->title        = \mb_substr( static::fillPlain( $title, $member ), 0, 255 );
		$conversation->to_member_id = $member->member_id;
		$conversation->save();

		$message = \IPS\core\Messenger\Message::create( $conversation, $html, TRUE, NULL, NULL, $sender );
		$conversation->first_msg_id = $message->id;
		$conversation->save();
		/* authorize() ustawia nieprzeczytaną wiadomość i licznik w nagłówku forum; powiadomienia e-mail celowo nie wysyłamy */
		$conversation->authorize( array( $sender, $member ) );

		/* U nadawcy rozmowa trafia do osobnego folderu (tysiące PW nie zasypują skrzynki); gdy ktoś odpisze,
		   hook PmFolder przenosi ją z powrotem do skrzynki głównej */
		try
		{
			static::ensurePmFolder( $sender );
			\IPS\Db::i()->update( 'core_message_topic_user_map', array( 'map_folder_id' => static::PM_FOLDER ), array( 'map_topic_id=? AND map_user_id=?', $conversation->id, $sender->member_id ) );
		}
		catch ( \Exception $e ) {}

		if ( static::hasMemberColumns() AND isset( $row['sup_id'] ) )
		{
			\IPS\Db::i()->update( 'awsses_suppressions', array( 'sup_pm_ts' => \time(), 'sup_member_id' => $member->member_id ), array( 'sup_id=?', $row['sup_id'] ) );
		}
		return TRUE;
	}

	/**
	 * @brief	Folder w komunikatorze nadawcy na PW wysłane przez aplikację (bez odpowiedzi)
	 */
	const PM_FOLDER      = 'awsses';
	const PM_FOLDER_NAME = 'Martwe adresy (PW automatyczne)';

	/**
	 * Dodaj folder PW aplikacji do komunikatora nadawcy (jeśli go nie ma)
	 *
	 * @param	\IPS\Member	$sender
	 * @return	void
	 */
	public static function ensurePmFolder( \IPS\Member $sender ): void
	{
		$folders = \json_decode( (string) $sender->pconversation_filters, TRUE );
		if ( !\is_array( $folders ) ) { $folders = array(); }
		if ( !isset( $folders[ static::PM_FOLDER ] ) )
		{
			$folders[ static::PM_FOLDER ] = static::PM_FOLDER_NAME;
			$sender->pconversation_filters = \json_encode( $folders );
			$sender->save();
		}
	}

	/**
	 * Ktoś odpisał w rozmowie: u pozostałych uczestników wyjmij ją z folderu PW aplikacji do skrzynki głównej
	 *
	 * @param	int	$topicId	ID rozmowy
	 * @param	int	$authorId	Autor nowej wiadomości
	 * @return	void
	 */
	public static function pmReplied( int $topicId, int $authorId ): void
	{
		\IPS\Db::i()->update( 'core_message_topic_user_map', array( 'map_folder_id' => 'myconvo' ), array( 'map_topic_id=? AND map_folder_id=? AND map_user_id<>?', $topicId, static::PM_FOLDER, $authorId ) );
	}

	/**
	 * Tytuł bez HTML
	 */
	protected static function fillPlain( string $text, \IPS\Member $member ): string
	{
		return \str_replace( array( '{name}', '{email}', '{link}' ), array( (string) $member->name, (string) $member->email, (string) static::emailSettingsUrl() ), $text );
	}

	/**
	 * Użytkownik zmienił adres: oznacz wpis jako rozwiązany i przywróć maile od administracji,
	 * jeśli to aplikacja je wyłączyła (a nowy adres nie jest zablokowany).
	 *
	 * @param	\IPS\Member	$member
	 * @param	string		$oldEmail
	 * @param	string		$newEmail
	 * @return	bool	TRUE = był wpis dla starego adresu
	 */
	public static function resolveEmailChange( \IPS\Member $member, string $oldEmail, string $newEmail ): bool
	{
		$oldEmail = \mb_strtolower( \trim( $oldEmail ) );
		if ( $oldEmail === '' OR !\IPS\Db::i()->checkForTable( 'awsses_suppressions' ) )
		{
			return FALSE;
		}
		try
		{
			$row = \IPS\Db::i()->select( '*', 'awsses_suppressions', array( 'sup_email=?', $oldEmail ) )->first();
		}
		catch ( \UnderflowException $e )
		{
			return FALSE;
		}

		unset( $_SESSION['awsses_notice'] );

		if ( static::hasMemberColumns() )
		{
			\IPS\Db::i()->update( 'awsses_suppressions', array( 'sup_resolved_ts' => \time(), 'sup_member_id' => $member->member_id ), array( 'sup_id=?', $row['sup_id'] ) );
		}

		/* Stary adres zostaje na liście (jest martwy). Maile od administracji wracają tylko, jeśli to my je wyłączyliśmy.
		   Import martwych adresów z pliku (tools/remove-newsletter-csv.php) wyłączał je ORAZ powiadomienia e-mail,
		   zanim wpis trafił na listę — dlatego rozpoznajemy go po opisie wpisu. */
		$fromImport  = static::isImportEntry( $row );
		$weTurnedOff = ( !empty( $row['sup_mails_off'] ) || $fromImport || static::historyShowsOurOptOut( $member ) );
		if ( $weTurnedOff AND !static::isSuppressed( $newEmail ) )
		{
			static::restoreMemberMail( $member, $fromImport, 'email_changed' );
		}
		return TRUE;
	}

	/**
	 * Wpis z importu martwych adresów z pliku (narzędzie remove-newsletter-csv.php)?
	 *
	 * @param	array	$row	wiersz awsses_suppressions
	 * @return	bool
	 */
	public static function isImportEntry( array $row ): bool
	{
		return \stripos( (string) ( $row['sup_detail'] ?? '' ), 'Import z pliku' ) === 0;
	}

	/**
	 * Przywróć koncie pocztę: maile od administracji (newslettery, Bulk Mail) i — gdy wyłączył je import —
	 * domyślne ustawienia powiadomień (usunięcie własnych preferencji = domyślne z ACP, w tym e-mail).
	 *
	 * @param	\IPS\Member	$member
	 * @param	bool		$notifications	Przywrócić też powiadomienia e-mail
	 * @param	string		$why			Powód w historii konta
	 * @return	void
	 */
	public static function restoreMemberMail( \IPS\Member $member, bool $notifications, string $why ): void
	{
		if ( !$member->allow_admin_mails )
		{
			$member->allow_admin_mails = 1;
			$member->save();
			$member->logHistory( 'core', 'admin_mails', array( 'enabled' => TRUE, 'awsses' => $why ) );
		}
		if ( $notifications AND \IPS\Db::i()->checkForTable( 'core_notification_preferences' ) )
		{
			\IPS\Db::i()->delete( 'core_notification_preferences', array( 'member_id=?', (int) $member->member_id ) );
		}
	}

	/**
	 * Wpisy sprzed 1.2.0 nie mają sup_mails_off — sprawdź w historii konta, czy maile wyłączyła ta aplikacja
	 */
	protected static function historyShowsOurOptOut( \IPS\Member $member ): bool
	{
		try
		{
			$last = \IPS\Db::i()->select( 'log_data', 'core_member_history', array( 'log_member=? AND log_app=? AND log_type=?', $member->member_id, 'core', 'admin_mails' ), 'log_date DESC', 1 )->first();
			$data = \json_decode( (string) $last, TRUE );
			return ( \is_array( $data ) && empty( $data['enabled'] ) && isset( $data['awsses'] ) );
		}
		catch ( \Exception $e ) { return FALSE; }
	}

	/**
	 * Warunek: wpis czeka na PW (konto nadal ma ten adres, niezbanowane, PW nie wysłana, adres nie zmieniony)
	 */
	protected static function pendingWhere( int $afterId = 0 ): array
	{
		$where = array( array( 's.sup_pm_ts=0 AND s.sup_resolved_ts=0 AND m.temp_ban=0' ) );
		if ( $afterId ) { $where[] = array( 's.sup_id>?', $afterId ); }
		return $where;
	}

	/**
	 * Ile osób czeka na PW
	 *
	 * @return	int
	 */
	public static function pendingPmCount(): int
	{
		if ( !static::hasMemberColumns() ) { return 0; }
		return (int) \IPS\Db::i()->select( 'COUNT(*)', array( 'awsses_suppressions', 's' ), static::pendingWhere() )
			->join( array( 'core_members', 'm' ), 'm.email=s.sup_email', 'INNER' )->first();
	}

	/**
	 * Następne wpisy czekające na PW
	 *
	 * @param	int	$afterId
	 * @param	int	$limit
	 * @return	array
	 */
	public static function pendingPmRows( int $afterId, int $limit ): array
	{
		if ( !static::hasMemberColumns() ) { return array(); }
		return \iterator_to_array( \IPS\Db::i()->select( 's.*', array( 'awsses_suppressions', 's' ), static::pendingWhere( $afterId ), 's.sup_id ASC', $limit )
			->join( array( 'core_members', 'm' ), 'm.email=s.sup_email', 'INNER' ), FALSE );
	}

	/**
	 * Liczniki do strony „Lista supresji”
	 *
	 * @return	array	total, withMember, pmSent, pending, resolved
	 */
	public static function summary(): array
	{
		$db  = \IPS\Db::i();
		$out = array( 'total' => 0, 'withMember' => 0, 'pmSent' => 0, 'pending' => 0, 'resolved' => 0 );
		if ( !$db->checkForTable( 'awsses_suppressions' ) ) { return $out; }

		$out['total']      = (int) $db->select( 'COUNT(*)', 'awsses_suppressions' )->first();
		$out['withMember'] = (int) $db->select( 'COUNT(*)', array( 'awsses_suppressions', 's' ) )->join( array( 'core_members', 'm' ), 'm.email=s.sup_email', 'INNER' )->first();
		if ( static::hasMemberColumns() )
		{
			$out['pmSent']   = (int) $db->select( 'COUNT(*)', 'awsses_suppressions', array( 'sup_pm_ts>0' ) )->first();
			$out['resolved'] = (int) $db->select( 'COUNT(*)', 'awsses_suppressions', array( 'sup_resolved_ts>0' ) )->first();
			$out['pending']  = static::pendingPmCount();
		}
		return $out;
	}

	/**
	 * Zdejmij adres z listy supresji (ręcznie z ACP). Maile od administracji wracają, jeśli to my je wyłączyliśmy.
	 *
	 * @param	int	$supId
	 * @return	void
	 */
	public static function remove( int $supId ): void
	{
		try
		{
			$row = \IPS\Db::i()->select( '*', 'awsses_suppressions', array( 'sup_id=?', $supId ) )->first();
		}
		catch ( \UnderflowException $e ) { return; }

		\IPS\Db::i()->delete( 'awsses_suppressions', array( 'sup_id=?', $supId ) );

		try
		{
			$member = \IPS\Member::load( (string) $row['sup_email'], 'email' );
			if ( $member->member_id AND ( !empty( $row['sup_mails_off'] ) OR static::isImportEntry( $row ) OR static::historyShowsOurOptOut( $member ) ) )
			{
				static::restoreMemberMail( $member, static::isImportEntry( $row ), 'removed_from_suppression' );
			}
		}
		catch ( \Exception $e ) {}
	}

	/**
	 * Czy adres jest na liście supresji?
	 *
	 * @param	string	$email
	 * @return	bool
	 */
	public static function isSuppressed( string $email ): bool
	{
		$email = \mb_strtolower( \trim( $email ) );
		if ( $email === '' ) { return FALSE; }

		try
		{
			if ( !\IPS\Db::i()->checkForTable( 'awsses_suppressions' ) ) { return FALSE; }
			return (bool) \IPS\Db::i()->select( 'COUNT(*)', 'awsses_suppressions', array( 'sup_email=?', $email ) )->first();
		}
		catch ( \Exception $e ) { return FALSE; }
	}

	/**
	 * Usuń z listy odbiorców adresy z supresji (jedno zapytanie na paczkę po 500).
	 *
	 * @param	array	$recipients	[ email => zmienne ]
	 * @return	array
	 */
	public static function filterRecipients( array $recipients ): array
	{
		if ( !\count( $recipients ) )
		{
			return $recipients;
		}

		try
		{
			if ( !\IPS\Db::i()->checkForTable( 'awsses_suppressions' ) )
			{
				return $recipients;
			}

			$blocked = array();
			foreach ( \array_chunk( \array_map( function( $e ) { return \mb_strtolower( \trim( (string) $e ) ); }, \array_keys( $recipients ) ), 500 ) as $chunk )
			{
				foreach ( \IPS\Db::i()->select( 'sup_email', 'awsses_suppressions', \IPS\Db::i()->in( 'sup_email', $chunk ) ) as $email )
				{
					$blocked[ $email ] = TRUE;
				}
			}

			if ( !$blocked )
			{
				return $recipients;
			}

			$out = array();
			foreach ( $recipients as $email => $vars )
			{
				if ( !isset( $blocked[ \mb_strtolower( \trim( (string) $email ) ) ] ) )
				{
					$out[ $email ] = $vars;
				}
			}
			return $out;
		}
		catch ( \Exception $e )
		{
			return $recipients;
		}
	}

	/**
	 * Zapisz zdarzenie do statystyk.
	 *
	 * @param	string	$type		send|delivery|bounce|complaint|open|click|reject|deliverydelay|subscription
	 * @param	string	$email
	 * @param	string	$config		Configuration Set
	 * @param	string	$campaign	Znacznik kampanii (np. newsletter-347, bulk, test)
	 * @param	string	$detail		Kliknięty link / rodzaj odbicia / typ skargi
	 * @return	void
	 */
	public static function recordEvent( string $type, string $email = '', string $config = '', string $campaign = '', string $detail = '' ): void
	{
		if ( !\IPS\Db::i()->checkForTable( 'awsses_events' ) ) { return; }

		$row = array(
			'ev_type'   => \mb_substr( $type, 0, 20 ),
			'ev_email'  => $email ? \mb_strtolower( \mb_substr( $email, 0, 255 ) ) : NULL,
			'ev_config' => $config ? \mb_substr( $config, 0, 100 ) : NULL,
			'ev_ts'     => \time(),
		);

		try
		{
			\IPS\Db::i()->insert( 'awsses_events', $row + array(
				'ev_campaign' => $campaign !== '' ? \mb_substr( $campaign, 0, 100 ) : NULL,
				'ev_detail'   => $detail !== '' ? \mb_substr( $detail, 0, 255 ) : NULL,
			) );
		}
		catch ( \IPS\Db\Exception $e )
		{
			/* Kolumny z 1.1.0 jeszcze nie istnieją (niedokończona aktualizacja) — zapisz bez nich */
			\IPS\Db::i()->insert( 'awsses_events', $row );
		}
	}

	/* ---------- Wstrzymanie wysyłki, gdy AWS zawiesi konto ---------- */

	/**
	 * Czy odbicie wynika z wstrzymania konta SES (a nie z adresu odbiorcy)?
	 * SES zgłasza je jako Permanent/AccountSuspended z odpowiedzią „Sending paused for this account”.
	 *
	 * @param	string	$subType	bounceSubType
	 * @param	string	$diag		diagnosticCode
	 * @return	bool
	 */
	public static function isAccountPause( string $subType, string $diag = '' ): bool
	{
		return \strcasecmp( $subType, 'AccountSuspended' ) === 0
			OR \stripos( $diag, 'Sending paused for this account' ) !== FALSE
			OR \stripos( $diag, 'Account suspended' ) !== FALSE;
	}

	/**
	 * Stan wstrzymania: ostatnie zdarzenie „pause”/„resume” w awsses_events (trwałe, bez ustawień IPS —
	 * działa też w kroku aktualizacji, zanim IPS doda nowe ustawienia).
	 *
	 * @return	array|NULL	[ 'since' => unix, 'reason' => komunikat AWS ] albo NULL, gdy wysyłka nie jest wstrzymana
	 */
	public static function pauseInfo(): ?array
	{
		try
		{
			if ( !\IPS\Db::i()->checkForTable( 'awsses_events' ) ) { return NULL; }
			$r = \IPS\Db::i()->select( 'ev_type, ev_ts, ev_detail', 'awsses_events', array( "ev_type IN('pause','resume')" ), 'ev_id DESC', 1 )->first();
			return $r['ev_type'] === 'pause' ? array( 'since' => (int) $r['ev_ts'], 'reason' => (string) $r['ev_detail'] ) : NULL;
		}
		catch ( \UnderflowException $e ) { return NULL; }
	}

	/**
	 * Czy wysyłka przez SES jest wstrzymana (przez aplikację po sygnale z AWS)?
	 *
	 * @return	bool
	 */
	public static function isPaused(): bool
	{
		return static::pauseInfo() !== NULL;
	}

	/**
	 * Wstrzymaj wysyłkę przez SES (Bulk Mail i newslettery). Ponowne wywołanie w trakcie wstrzymania nic nie zmienia.
	 *
	 * @param	string	$reason
	 * @return	void
	 */
	public static function pauseSending( string $reason ): void
	{
		if ( static::isPaused() ) { return; }
		static::recordEvent( 'pause', '', '', '', \trim( $reason ) );
	}

	/**
	 * Wznów wysyłkę (z ACP, gdy AWS przywróci konto).
	 *
	 * @return	void
	 */
	public static function resumeSending(): void
	{
		if ( static::isPaused() ) { static::recordEvent( 'resume' ); }
	}

	/**
	 * Napraw skutki wstrzymania konta sprzed 1.2.2: odbicia „Sending paused” trafiały na listę supresji jak martwe adresy.
	 * Zdejmuje takie wpisy (maile od administracji wracają, jeśli wyłączyła je aplikacja) i oznacza te adresy
	 * w kolejce wydań newslettera jako niewysłane — wznowienie wydania wyśle do nich ponownie.
	 *
	 * @return	array	[ 'removed' => zdjęte z listy, 'requeued' => wiersze kolejki newslettera do ponownej wysyłki ]
	 */
	public static function repairAccountPause(): array
	{
		$out = array( 'removed' => 0, 'requeued' => 0 );
		$db  = \IPS\Db::i();

		/* Wpisy, których jedynym powodem jest wstrzymanie konta (późniejszy import / prawdziwe odbicie nadpisuje sup_detail) */
		if ( $db->checkForTable( 'awsses_suppressions' ) )
		{
			$ids = iterator_to_array( $db->select( 'sup_id', 'awsses_suppressions', array(
				"sup_detail LIKE ? OR sup_detail LIKE ?", '%Sending paused for this account%', '%AccountSuspended%'
			) ) );
			foreach ( $ids as $id )
			{
				static::remove( (int) $id );
				$out['removed']++;
			}
		}

		/* Adresy, do których wydanie „poszło” w czasie wstrzymania — w kolejce Newsletters wracają jako niewysłane */
		if ( $db->checkForTable( 'awsses_events' ) AND $db->checkForColumn( 'awsses_events', 'ev_campaign' ) AND $db->checkForTable( 'newsletters_queue' ) )
		{
			$byIssue = array();
			foreach ( $db->select( 'ev_email, ev_campaign', 'awsses_events', array(
				"ev_type='bounce' AND ev_campaign LIKE 'newsletter-%' AND ( ev_detail LIKE ? OR ev_detail LIKE ? )", '%AccountSuspended%', '%Sending paused for this account%'
			) ) as $r )
			{
				$issue = (int) \substr( (string) $r['ev_campaign'], 11 );
				if ( $issue AND $r['ev_email'] ) { $byIssue[ $issue ][ (string) $r['ev_email'] ] = TRUE; }
			}
			foreach ( $byIssue as $issue => $emails )
			{
				foreach ( \array_chunk( \array_keys( $emails ), 500 ) as $chunk )
				{
					$out['requeued'] += (int) $db->update( 'newsletters_queue', array( 'sent_date' => NULL ), array( array( 'issue_id=?', $issue ), array( $db->in( 'email', $chunk ) ), array( 'sent_date IS NOT NULL' ) ) );
				}
			}
		}

		return $out;
	}
}
