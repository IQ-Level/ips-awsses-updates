<?php
/**
 * Aktualizacja do 1.2.6: PW wysłane przez aplikację (martwe adresy) bez odpowiedzi przenieś u nadawcy do osobnego
 * folderu komunikatora „Martwe adresy (PW automatyczne)”. Rozmowy, w których ktoś odpisał, zostają w skrzynce.
 * Bez zależności od klas aplikacji (OPcache na serwerze potrafi podać ich starą wersję w trakcie aktualizacji).
 *
 * @author  IQL vel Espectro
 * @package awsses
 */

namespace IPS\awsses\setup\upg_12060;

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( isset( $_SERVER['SERVER_PROTOCOL'] ) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

/**
 * Upgrade
 */
class _Upgrade
{
	const FOLDER        = 'awsses';
	const FOLDER_NAME   = 'Martwe adresy (PW automatyczne)';
	const DEFAULT_TITLE = 'Twój adres e-mail nie działa — zaktualizuj go';

	/**
	 * Przenieś PW aplikacji bez odpowiedzi do folderu
	 *
	 * @return	bool
	 */
	public function step1()
	{
		try
		{
			$db       = \IPS\Db::i();
			$senderId = (int) \IPS\Settings::i()->awsses_pm_sender;
			if ( !$senderId OR !$db->checkForTable( 'core_message_topics' ) ) { return TRUE; }

			$sender = \IPS\Member::load( $senderId );
			if ( !$sender->member_id ) { return TRUE; }

			/* Folder w komunikatorze nadawcy */
			$folders = \json_decode( (string) $sender->pconversation_filters, TRUE );
			if ( !\is_array( $folders ) ) { $folders = array(); }
			if ( !isset( $folders[ static::FOLDER ] ) )
			{
				$folders[ static::FOLDER ] = static::FOLDER_NAME;
				$sender->pconversation_filters = \json_encode( $folders );
				$sender->save();
			}

			/* Tytuł PW (z ustawień albo domyślny); {name}/{email}/{link} → dowolny tekst */
			$title   = \trim( (string) \IPS\Settings::i()->awsses_pm_title ) ?: static::DEFAULT_TITLE;
			$pattern = \str_replace( array( '\\', '%', '_' ), array( '\\\\', '\\%', '\\_' ), $title );
			$pattern = \str_replace( array( '{name}', '{email}', '{link}' ), '%', $pattern );

			/* Rozmowy rozpoczęte przez nadawcę z tym tytułem, w których nikt poza nadawcą nie pisał */
			$ids = iterator_to_array( $db->select( 't.mt_id', array( 'core_message_topics', 't' ), array(
				array( 't.mt_starter_id=?', $senderId ),
				array( 't.mt_title LIKE ?', $pattern ),
				array( 'NOT EXISTS ( SELECT 1 FROM ' . $db->prefix . 'core_message_posts p WHERE p.msg_topic_id=t.mt_id AND p.msg_author_id<>? )', $senderId ),
			) ) );

			foreach ( \array_chunk( $ids, 500 ) as $chunk )
			{
				$db->update( 'core_message_topic_user_map', array( 'map_folder_id' => static::FOLDER ), array(
					array( 'map_user_id=?', $senderId ),
					array( "map_folder_id='myconvo'" ),
					array( $db->in( 'map_topic_id', $chunk ) ),
				) );
			}
		}
		catch ( \Throwable $e )
		{
			\IPS\Log::log( $e, 'awsses' );
		}

		return TRUE;
	}
}
