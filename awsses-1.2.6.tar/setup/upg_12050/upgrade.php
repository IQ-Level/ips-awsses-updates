<?php
/**
 * Aktualizacja do 1.2.5: konta z importu martwych adresów, które zmieniły adres przed tą wersją.
 *
 * Import z pliku (tools/remove-newsletter-csv.php) wyłączał maile od administracji i powiadomienia e-mail, ale do 1.2.4
 * zmiana adresu przywracała je tylko wtedy, gdy wpis miał sup_mails_off — a import go nie ustawiał. Ten krok
 * przywraca pocztę kontom, których wpis z importu jest już rozwiązany (adres zmieniony na działający).
 * Bez zależności od klas aplikacji (OPcache na serwerze potrafi podać ich starą wersję w trakcie aktualizacji).
 *
 * @author  IQL vel Espectro
 * @package awsses
 */

namespace IPS\awsses\setup\upg_12050;

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( isset( $_SERVER['SERVER_PROTOCOL'] ) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

/**
 * Upgrade
 */
class _Upgrade
{
	/**
	 * Przywróć pocztę kontom z rozwiązanych wpisów importu
	 *
	 * @return	bool
	 */
	public function step1()
	{
		try
		{
			$db = \IPS\Db::i();
			if ( !$db->checkForTable( 'awsses_suppressions' ) OR !$db->checkForColumn( 'awsses_suppressions', 'sup_resolved_ts' ) ) { return TRUE; }

			foreach ( $db->select( 'sup_member_id', 'awsses_suppressions', array( "sup_resolved_ts>0 AND sup_member_id>0 AND sup_detail LIKE 'Import z pliku%'" ) ) as $memberId )
			{
				try
				{
					$member = \IPS\Member::load( (int) $memberId );
					if ( !$member->member_id OR !$member->email ) { continue; }

					/* Nowy adres nie może być na liście supresji */
					if ( (int) $db->select( 'COUNT(*)', 'awsses_suppressions', array( 'sup_email=? AND sup_resolved_ts=0', \mb_strtolower( $member->email ) ) )->first() ) { continue; }

					if ( !$member->allow_admin_mails )
					{
						$member->allow_admin_mails = 1;
						$member->save();
						$member->logHistory( 'core', 'admin_mails', array( 'enabled' => TRUE, 'awsses' => 'email_changed' ) );
					}
					if ( $db->checkForTable( 'core_notification_preferences' ) )
					{
						$db->delete( 'core_notification_preferences', array( 'member_id=?', (int) $member->member_id ) );
					}
				}
				catch ( \Throwable $e )
				{
					\IPS\Log::log( $e, 'awsses' );
				}
			}
		}
		catch ( \Throwable $e )
		{
			\IPS\Log::log( $e, 'awsses' );
		}

		return TRUE;
	}
}
