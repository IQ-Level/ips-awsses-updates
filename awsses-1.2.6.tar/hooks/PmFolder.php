//<?php

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	exit;
}

/**
 * PW wysłane przez aplikację (martwe adresy) leżą u nadawcy w osobnym folderze. Gdy ktoś w takiej rozmowie odpisze,
 * rozmowa wraca do skrzynki głównej nadawcy. \IPS\core\Messenger\Message nie jest abstrakcyjna.
 */
class awsses_hook_PmFolder extends _HOOK_CLASS_
{
	/**
	 * Send notifications
	 *
	 * @return	void
	 */
	public function sendNotifications()
	{
		$result = parent::sendNotifications();

		try
		{
			if ( \method_exists( '\IPS\awsses\Suppression', 'pmReplied' ) )
			{
				\IPS\awsses\Suppression::pmReplied( (int) $this->item()->id, (int) $this->author()->member_id );
			}
		}
		catch ( \Throwable $e )
		{
			\IPS\Log::log( $e, 'awsses' );
		}

		return $result;
	}
}
