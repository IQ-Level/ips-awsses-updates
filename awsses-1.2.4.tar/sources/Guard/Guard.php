<?php
/**
 * Strażnik wysyłki: automatyczne wstrzymanie przy rosnących odbiciach/skargach i wznawianie przerwanych wysyłek.
 *
 * - check(): po każdym twardym odbiciu / skardze liczy odsetek w kampanii (od ostatniego wznowienia, maks. 24 h)
 *   i wstrzymuje wysyłkę przez SES, gdy przekroczy próg — zanim zrobi to AWS.
 * - markInterrupted(): transport zapisuje, które wydanie newslettera / Bulk Mail przerwało wstrzymanie.
 * - resumeInterrupted(): „Wznów wysyłkę” wznawia je tylko do tych, którzy jeszcze nie dostali.
 *
 * @author  IQL vel Espectro
 * @package awsses
 */

namespace IPS\awsses;

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( isset( $_SERVER['SERVER_PROTOCOL'] ) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

/**
 * Guard
 */
class _Guard
{
	/**
	 * @brief	Rodzaje „twardych” odbić, które NIE są winą odbiorcy (SES nie wysłał) — nie liczą się do progu
	 */
	const SES_BLOCKED = array( 'Permanent/Suppressed', 'Permanent/OnAccountSuppressionList', 'Permanent/EmailValidationSuppressed', 'Permanent/AccountSuspended' );

	/**
	 * Progi z ustawień (puste = domyślne). 0 wyłącza dany próg.
	 *
	 * @return	array	[ 'bounce' => %, 'complaint' => %, 'min' => min. wysłanych ]
	 */
	public static function thresholds(): array
	{
		$s = \IPS\Settings::i();
		$v = function( $val, $default ) { return ( $val === NULL OR $val === '' ) ? $default : (float) $val; };
		return array(
			'bounce'    => $v( $s->awsses_autopause_bounce, 5.0 ),
			'complaint' => $v( $s->awsses_autopause_complaint, 0.3 ),
			'min'       => (int) $v( $s->awsses_autopause_min, 300 ),
		);
	}

	/**
	 * ID ostatniego wznowienia (zdarzenie „resume”), 0 gdy nie było
	 *
	 * @return	int
	 */
	protected static function lastResumeId(): int
	{
		try
		{
			return (int) \IPS\Db::i()->select( 'ev_id', 'awsses_events', array( "ev_type='resume'" ), 'ev_id DESC', 1 )->first();
		}
		catch ( \UnderflowException $e ) { return 0; }
	}

	/**
	 * Policz odsetek odbić i skarg w kampanii (od ostatniego wznowienia, maks. 24 h)
	 *
	 * @param	string	$campaign
	 * @return	array	[ 'sent', 'hard', 'complaints', 'bounceRate', 'complaintRate' ]
	 */
	public static function campaignRates( string $campaign ): array
	{
		$db    = \IPS\Db::i();
		$since = \time() - 86400;
		$after = static::lastResumeId();
		$base  = array( array( 'ev_campaign=? AND ev_ts>? AND ev_id>?', $campaign, $since, $after ) );

		$sent = (int) $db->select( 'COUNT(*)', 'awsses_events', \array_merge( $base, array( array( "ev_type='send'" ) ) ) )->first();
		$hard = (int) $db->select( 'COUNT(*)', 'awsses_events', \array_merge( $base, array(
			array( "ev_type='bounce' AND ev_detail LIKE 'Permanent%'" ),
			array( $db->in( "SUBSTRING_INDEX(ev_detail,' | ',1)", static::SES_BLOCKED, TRUE ) ),
		) ) )->first();
		$complaints = (int) $db->select( 'COUNT(*)', 'awsses_events', \array_merge( $base, array( array( "ev_type='complaint'" ) ) ) )->first();

		return array(
			'sent'          => $sent,
			'hard'          => $hard,
			'complaints'    => $complaints,
			'bounceRate'    => $sent ? $hard / $sent * 100 : 0.0,
			'complaintRate' => $sent ? $complaints / $sent * 100 : 0.0,
		);
	}

	/**
	 * Sprawdź kampanię po twardym odbiciu / skardze; przy przekroczonym progu wstrzymaj wysyłkę.
	 *
	 * @param	string	$campaign	Znacznik kampanii (np. newsletter-350, bulk)
	 * @return	string|NULL			Powód wstrzymania albo NULL
	 */
	public static function check( string $campaign ): ?string
	{
		if ( $campaign === '' OR \in_array( $campaign, array( 'test', 'newsletter-test' ), TRUE ) ) { return NULL; }
		if ( !\IPS\Db::i()->checkForTable( 'awsses_events' ) OR \IPS\awsses\Suppression::isPaused() ) { return NULL; }

		$t = static::thresholds();
		if ( $t['bounce'] <= 0 AND $t['complaint'] <= 0 ) { return NULL; }

		$r = static::campaignRates( $campaign );
		if ( $r['sent'] < \max( 1, $t['min'] ) ) { return NULL; }

		$fmt = function( float $x ) { return \number_format( $x, \abs( $x ) < 1 ? 2 : 1, ',', '' ); };
		$reason = NULL;
		if ( $t['bounce'] > 0 AND $r['bounceRate'] >= $t['bounce'] )
		{
			$reason = "Aplikacja: odbicia twarde {$fmt( $r['bounceRate'] )} % w kampanii {$campaign} ({$r['hard']} z {$r['sent']} wysłanych, próg {$fmt( $t['bounce'] )} %)";
		}
		elseif ( $t['complaint'] > 0 AND $r['complaintRate'] >= $t['complaint'] )
		{
			$reason = "Aplikacja: skargi {$fmt( $r['complaintRate'] )} % w kampanii {$campaign} ({$r['complaints']} z {$r['sent']} wysłanych, próg {$fmt( $t['complaint'] )} %)";
		}

		if ( $reason !== NULL )
		{
			\IPS\awsses\Suppression::pauseSending( $reason );
		}
		return $reason;
	}

	/**
	 * Zapamiętaj przerwaną wysyłkę (raz na wstrzymanie)
	 *
	 * @param	string	$campaign	newsletter-<id wydania> albo bulk
	 * @return	void
	 */
	public static function markInterrupted( string $campaign ): void
	{
		try
		{
			$db = \IPS\Db::i();
			if ( !$db->checkForTable( 'awsses_events' ) ) { return; }
			$exists = (int) $db->select( 'COUNT(*)', 'awsses_events', array( "ev_type='interrupt' AND ev_campaign=? AND ev_id>?", $campaign, static::lastResumeId() ) )->first();
			if ( !$exists )
			{
				$db->insert( 'awsses_events', array( 'ev_type' => 'interrupt', 'ev_campaign' => $campaign, 'ev_ts' => \time() ) );
			}
		}
		catch ( \Exception $e ) {}
	}

	/**
	 * Przerwane wysyłki od ostatniego wznowienia
	 *
	 * @return	array	[ 'issues' => [ id wydania, ... ], 'bulk' => bool ]
	 */
	public static function interrupted(): array
	{
		$out = array( 'issues' => array(), 'bulk' => FALSE );
		try
		{
			foreach ( \IPS\Db::i()->select( 'DISTINCT ev_campaign', 'awsses_events', array( "ev_type='interrupt' AND ev_id>?", static::lastResumeId() ) ) as $c )
			{
				if ( \strpos( (string) $c, 'newsletter-' ) === 0 AND ( $id = (int) \substr( (string) $c, 11 ) ) ) { $out['issues'][] = $id; }
				if ( $c === 'bulk' ) { $out['bulk'] = TRUE; }
			}
		}
		catch ( \Exception $e ) {}
		return $out;
	}

	/**
	 * Wznów wydanie newslettera tylko do tych, którzy go nie dostali.
	 *
	 * Nie przez \IPS\Task::queue(): preQueueData Newsletters dopisuje całą listę odbiorców jeszcze raz (bez
	 * sprawdzania duplikatów). Zadanie wstawiamy bezpośrednio na istniejącą kolejkę wydania; distribute() pomija
	 * wysłanych (sent_date). Wypisani po publikacji wydania wypadają z kolejki.
	 *
	 * @param	int	$issueId
	 * @return	array	[ 'ok' => bool, 'msg' => string, 'unsent' => int ]
	 */
	public static function resumeIssue( int $issueId ): array
	{
		$db = \IPS\Db::i();
		if ( !$db->checkForTable( 'newsletters_issues' ) OR !$db->checkForTable( 'newsletters_queue' ) )
		{
			return array( 'ok' => FALSE, 'msg' => "wydanie #{$issueId}: brak aplikacji Newsletters", 'unsent' => 0 );
		}
		try
		{
			$issue = $db->select( '*', 'newsletters_issues', array( 'issue_id=?', $issueId ) )->first();
		}
		catch ( \UnderflowException $e )
		{
			return array( 'ok' => FALSE, 'msg' => "wydanie #{$issueId} nie istnieje", 'unsent' => 0 );
		}

		foreach ( $db->select( 'data', 'core_queue', array( '`app`=? AND `key`=?', 'newsletters', 'DistributeNewsletters' ) ) as $data )
		{
			$d = \json_decode( (string) $data, TRUE );
			if ( (int) ( $d['issue_id'] ?? 0 ) === $issueId )
			{
				return array( 'ok' => FALSE, 'msg' => "wydanie #{$issueId} już jest w kolejce wysyłki", 'unsent' => 0 );
			}
		}

		/* Wypisani po publikacji — kolejka ich nie wyrzuca */
		$unsub = iterator_to_array( $db->select( 'q.id', array( 'newsletters_queue', 'q' ), array(
				array( 'q.issue_id=?', $issueId ),
				array( 'q.sent_date IS NULL' ),
				array( 'ns.newsletter_id=?', $issue['newsletter_id'] ),
				array( 'ns.subscribed=0' ),
			) )
			->join( array( 'core_members', 'm' ), 'm.email=q.email', 'INNER' )
			->join( array( 'newsletters_subscriptions', 'ns' ), 'ns.member_id=m.member_id', 'INNER' ) );
		foreach ( \array_chunk( $unsub, 500 ) as $chunk )
		{
			$db->delete( 'newsletters_queue', $db->in( 'id', $chunk ) );
		}

		$unsent = (int) $db->select( 'COUNT(*)', 'newsletters_queue', array( 'issue_id=? AND sent_date IS NULL', $issueId ) )->first();
		if ( !$unsent )
		{
			return array( 'ok' => FALSE, 'msg' => "wydanie #{$issueId}: wszyscy już dostali", 'unsent' => 0 );
		}

		/* Liczniki od zera — distribute() pomija wysłanych i sam dochodzi do właściwego miejsca */
		$db->update( 'newsletters_issues', array( 'active' => 1, 'distributed' => 0, 'html_sent' => 0, 'plain_sent' => 0 ), array( 'issue_id=?', $issueId ) );
		$count = (int) $db->select( 'COUNT(*)', 'newsletters_queue', array( 'issue_id=?', $issueId ) )->first();
		$title = '';
		try { $title = (string) $db->select( 'name', 'newsletters_newsletters', array( 'newsletter_id=?', $issue['newsletter_id'] ) )->first(); } catch ( \Exception $e ) {}
		$db->insert( 'core_queue', array(
			'data'     => \json_encode( array( 'issue_id' => $issueId, 'title' => $title, 'count' => $count ) ),
			'date'     => \time(),
			'offset'   => 0,
			'app'      => 'newsletters',
			'key'      => 'DistributeNewsletters',
			'priority' => 3,
		) );
		$db->update( 'core_tasks', array( 'enabled' => 1 ), array( '`key`=?', 'queue' ) );

		return array( 'ok' => TRUE, 'msg' => "wydanie #{$issueId} wznowione ({$unsent} do wysłania)", 'unsent' => $unsent );
	}

	/**
	 * Wznów przerwane Bulk Mail: aktywne wysyłki bez zadania w kolejce wracają od zapisanego miejsca (mail_offset)
	 *
	 * @return	array	komunikaty
	 */
	public static function resumeBulk(): array
	{
		$db  = \IPS\Db::i();
		$out = array();
		if ( !$db->checkForTable( 'core_bulk_mail' ) ) { return $out; }

		$queued = array();
		foreach ( $db->select( 'data', 'core_queue', array( '`app`=? AND `key`=?', 'core', 'Bulkmail' ) ) as $data )
		{
			$d = \json_decode( (string) $data, TRUE );
			$queued[ (int) ( $d['mail_id'] ?? 0 ) ] = TRUE;
		}
		foreach ( $db->select( 'mail_id, mail_subject, mail_offset', 'core_bulk_mail', array( 'mail_active=1' ) ) as $m )
		{
			if ( isset( $queued[ (int) $m['mail_id'] ] ) ) { continue; }
			/* Postęp zadania Bulk Mail dzieli przez count — policz jak preQueueData rdzenia */
			try
			{
				$count = (int) \IPS\core\BulkMail\Bulkmailer::load( (int) $m['mail_id'] )->getQuery( \IPS\core\BulkMail\Bulkmailer::GET_COUNT_ONLY )->first();
			}
			catch ( \Throwable $e )
			{
				$out[] = 'Bulk Mail „' . $m['mail_subject'] . '” — nie udało się wznowić (' . $e->getMessage() . '), wyślij go ponownie w ACP';
				continue;
			}
			if ( $count <= (int) $m['mail_offset'] ) { continue; }
			$db->insert( 'core_queue', array(
				'data'     => \json_encode( array( 'mail_id' => (int) $m['mail_id'], 'count' => \max( 1, $count ) ) ),
				'date'     => \time(),
				'offset'   => (int) $m['mail_offset'],
				'app'      => 'core',
				'key'      => 'Bulkmail',
				'priority' => 5,
			) );
			$out[] = 'Bulk Mail „' . $m['mail_subject'] . '” wznowiony';
		}
		if ( $out ) { $db->update( 'core_tasks', array( 'enabled' => 1 ), array( '`key`=?', 'queue' ) ); }
		return $out;
	}

	/**
	 * „Wznów wysyłkę”: zdejmij wstrzymanie i wznów wszystko, co przerwało
	 *
	 * @return	array	komunikaty
	 */
	public static function resumeAll(): array
	{
		$todo = static::interrupted();
		\IPS\awsses\Suppression::resumeSending();

		$msgs = array();
		foreach ( \array_unique( $todo['issues'] ) as $id )
		{
			$msgs[] = static::resumeIssue( (int) $id )['msg'];
		}
		if ( $todo['bulk'] )
		{
			$msgs = \array_merge( $msgs, static::resumeBulk() );
		}
		return $msgs;
	}
}
