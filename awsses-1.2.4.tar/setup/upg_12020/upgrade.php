<?php
/**
 * Aktualizacja do 1.2.2: naprawa skutków wstrzymania konta SES.
 *
 * Do 1.2.1 odbicia „Permanent/AccountSuspended — Sending paused for this account” trafiały na listę supresji jak
 * martwe adresy (i wyłączały maile od administracji). Ten krok zdejmuje takie wpisy, oznacza te adresy w kolejce
 * wydań newslettera jako niewysłane i — jeśli AWS wstrzymał konto w ostatnich dniach — włącza wstrzymanie wysyłki.
 *
 * Celowo bez \IPS\awsses\Suppression: serwer z OPcache bez sprawdzania znaczników czasu potrafi w trakcie
 * aktualizacji podać starą wersję klasy. Wszystko tu jest na \IPS\Db i \IPS\Member.
 *
 * @author  IQL vel Espectro
 * @package awsses
 */

namespace IPS\awsses\setup\upg_12020;

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( isset( $_SERVER['SERVER_PROTOCOL'] ) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

/**
 * Upgrade
 */
class _Upgrade
{
	/**
	 * Naprawa wpisów i wstrzymanie wysyłki
	 *
	 * @return	bool
	 */
	public function step1()
	{
		try
		{
			$this->pauseIfSuspended();
		}
		catch ( \Throwable $e )
		{
			\IPS\Log::log( $e, 'awsses' );
		}

		try
		{
			$this->unsuppressPaused();
		}
		catch ( \Throwable $e )
		{
			\IPS\Log::log( $e, 'awsses' );
		}

		try
		{
			$this->requeuePaused();
		}
		catch ( \Throwable $e )
		{
			\IPS\Log::log( $e, 'awsses' );
		}

		return TRUE;
	}

	/**
	 * Wstrzymanie (zdarzenie „pause”), jeśli AWS zawiesił konto w ciągu 3 dni i nikt potem nie wznowił
	 *
	 * @return	void
	 */
	protected function pauseIfSuspended(): void
	{
		$db = \IPS\Db::i();
		if ( !$db->checkForTable( 'awsses_events' ) ) { return; }

		try
		{
			$state = $db->select( 'ev_type', 'awsses_events', array( "ev_type IN('pause','resume')" ), 'ev_id DESC', 1 )->first();
			if ( $state === 'pause' ) { return; }
		}
		catch ( \UnderflowException $e ) {}

		try
		{
			$last = $db->select( 'ev_id, ev_detail', 'awsses_events', array(
				"ev_type='bounce' AND ev_ts>? AND ( ev_detail LIKE ? OR ev_detail LIKE ? )", \time() - 3 * 86400, '%AccountSuspended%', '%Sending paused for this account%'
			), 'ev_id DESC', 1 )->first();
		}
		catch ( \UnderflowException $e ) { return; }

		if ( (int) $db->select( 'COUNT(*)', 'awsses_events', array( "ev_type='resume' AND ev_id>?", (int) $last['ev_id'] ) )->first() )
		{
			return;
		}

		$parts = \explode( ' | ', (string) $last['ev_detail'], 2 );
		$db->insert( 'awsses_events', array(
			'ev_type'   => 'pause',
			'ev_ts'     => \time(),
			'ev_detail' => \mb_substr( \trim( $parts[1] ?? $parts[0] ), 0, 255 ),
		) );
	}

	/**
	 * Zdejmij z listy supresji wpisy, których jedynym powodem jest wstrzymanie konta (późniejszy import / prawdziwe
	 * odbicie nadpisuje sup_detail). Maile od administracji wracają, jeśli wyłączyła je aplikacja.
	 *
	 * @return	void
	 */
	protected function unsuppressPaused(): void
	{
		$db = \IPS\Db::i();
		if ( !$db->checkForTable( 'awsses_suppressions' ) ) { return; }

		$hasMailsOff = $db->checkForColumn( 'awsses_suppressions', 'sup_mails_off' );
		$rows = iterator_to_array( $db->select( '*', 'awsses_suppressions', array(
			'sup_detail LIKE ? OR sup_detail LIKE ?', '%Sending paused for this account%', '%AccountSuspended%'
		) ) );

		foreach ( $rows as $row )
		{
			$db->delete( 'awsses_suppressions', array( 'sup_id=?', $row['sup_id'] ) );

			if ( !$hasMailsOff OR empty( $row['sup_mails_off'] ) ) { continue; }
			try
			{
				$member = \IPS\Member::load( (string) $row['sup_email'], 'email' );
				if ( $member->member_id AND !$member->allow_admin_mails )
				{
					$member->allow_admin_mails = 1;
					$member->save();
					$member->logHistory( 'core', 'admin_mails', array( 'enabled' => TRUE, 'awsses' => 'removed_from_suppression' ) );
				}
			}
			catch ( \Exception $e ) {}
		}
	}

	/**
	 * Adresy, do których wydanie „poszło” w czasie wstrzymania — w kolejce Newsletters wracają jako niewysłane
	 *
	 * @return	void
	 */
	protected function requeuePaused(): void
	{
		$db = \IPS\Db::i();
		if ( !$db->checkForTable( 'awsses_events' ) OR !$db->checkForColumn( 'awsses_events', 'ev_campaign' ) OR !$db->checkForTable( 'newsletters_queue' ) )
		{
			return;
		}

		$byIssue = array();
		foreach ( $db->select( 'ev_email, ev_campaign', 'awsses_events', array(
			"ev_type='bounce' AND ev_campaign LIKE 'newsletter-%' AND ( ev_detail LIKE ? OR ev_detail LIKE ? )", '%AccountSuspended%', '%Sending paused for this account%'
		) ) as $r )
		{
			$issue = (int) \substr( (string) $r['ev_campaign'], 11 );
			if ( $issue AND $r['ev_email'] ) { $byIssue[ $issue ][ (string) $r['ev_email'] ] = TRUE; }
		}
		foreach ( $byIssue as $issue => $emails )
		{
			foreach ( \array_chunk( \array_keys( $emails ), 500 ) as $chunk )
			{
				$db->update( 'newsletters_queue', array( 'sent_date' => NULL ), array( array( 'issue_id=?', $issue ), array( $db->in( 'email', $chunk ) ), array( 'sent_date IS NOT NULL' ) ) );
			}
		}
	}
}
