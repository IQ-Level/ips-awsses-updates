<?php
/**
 * Aktualizacja do 1.2.4: automatyczne wstrzymanie i wznawianie z ACP.
 *
 * Jeśli wysyłka jest wstrzymana (AWS zawiesił konto), wydania newslettera przerwane przez „Sending paused”
 * zostają zapamiętane jako przerwane — przycisk „Wznów wysyłkę” wznowi je tylko do tych, którzy nie dostali.
 * Bez zależności od klas aplikacji (OPcache na serwerze potrafi podać ich starą wersję w trakcie aktualizacji).
 *
 * @author  IQL vel Espectro
 * @package awsses
 */

namespace IPS\awsses\setup\upg_12040;

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( isset( $_SERVER['SERVER_PROTOCOL'] ) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

/**
 * Upgrade
 */
class _Upgrade
{
	/**
	 * Zapamiętaj wydania przerwane przez wstrzymanie konta
	 *
	 * @return	bool
	 */
	public function step1()
	{
		try
		{
			$db = \IPS\Db::i();
			if ( !$db->checkForTable( 'awsses_events' ) OR !$db->checkForTable( 'newsletters_queue' ) ) { return TRUE; }

			try
			{
				$state = $db->select( 'ev_type', 'awsses_events', array( "ev_type IN('pause','resume')" ), 'ev_id DESC', 1 )->first();
			}
			catch ( \UnderflowException $e ) { return TRUE; }
			if ( $state !== 'pause' ) { return TRUE; }

			try { $lastResume = (int) $db->select( 'ev_id', 'awsses_events', array( "ev_type='resume'" ), 'ev_id DESC', 1 )->first(); }
			catch ( \UnderflowException $e ) { $lastResume = 0; }

			foreach ( $db->select( 'DISTINCT ev_campaign', 'awsses_events', array(
				"ev_type='bounce' AND ev_campaign LIKE 'newsletter-%' AND ev_ts>? AND ( ev_detail LIKE ? OR ev_detail LIKE ? )",
				\time() - 3 * 86400, '%AccountSuspended%', '%Sending paused for this account%'
			) ) as $campaign )
			{
				$issue = (int) \substr( (string) $campaign, 11 );
				if ( !$issue ) { continue; }
				if ( !(int) $db->select( 'COUNT(*)', 'newsletters_queue', array( 'issue_id=? AND sent_date IS NULL', $issue ) )->first() ) { continue; }
				if ( (int) $db->select( 'COUNT(*)', 'awsses_events', array( "ev_type='interrupt' AND ev_campaign=? AND ev_id>?", $campaign, $lastResume ) )->first() ) { continue; }
				$db->insert( 'awsses_events', array( 'ev_type' => 'interrupt', 'ev_campaign' => (string) $campaign, 'ev_ts' => \time() ) );
			}
		}
		catch ( \Throwable $e )
		{
			\IPS\Log::log( $e, 'awsses' );
		}

		return TRUE;
	}
}
