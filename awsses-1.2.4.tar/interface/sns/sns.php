<?php
/**
 * AWS SES — endpoint SNS (bounce / complaint / statystyki).
 *
 * Plik interface aplikacji. URL do subskrypcji SNS (typ HTTPS):
 *   https://twojeforum/applications/awsses/interface/sns/sns.php?t=<awsses_sns_token>
 *
 * @author  IQL vel Espectro
 * @package awsses
 */

require_once \str_replace( 'applications/awsses/interface/sns/sns.php', 'init.php', \str_replace( '\\', '/', __FILE__ ) );

/* ---------- helpers ---------- */
function awsses_sns_fail( $code, $msg )
{
	\http_response_code( $code );
	\header( 'Content-Type: text/plain; charset=utf-8' );
	echo $msg;
	exit;
}

function awsses_sns_amazonHost( string $url ): bool
{
	$host = \parse_url( $url, PHP_URL_HOST );
	if ( !$host ) { return FALSE; }
	$host = \mb_strtolower( $host );
	return (bool) \preg_match( '/(^|\.)amazonaws\.com$/', $host ) AND \strpos( $url, 'https://' ) === 0;
}

function awsses_sns_verify( array $sns ): bool
{
	if ( empty( $sns['Signature'] ) OR empty( $sns['SigningCertURL'] ) OR !awsses_sns_amazonHost( $sns['SigningCertURL'] ) )
	{
		return FALSE;
	}

	if ( \in_array( $sns['Type'], array( 'SubscriptionConfirmation', 'UnsubscribeConfirmation' ) ) )
	{
		$keys = array( 'Message', 'MessageId', 'SubscribeURL', 'Timestamp', 'Token', 'TopicArn', 'Type' );
	}
	else
	{
		$keys = array( 'Message', 'MessageId', 'Subject', 'Timestamp', 'TopicArn', 'Type' );
	}

	$stringToSign = '';
	foreach ( $keys as $k )
	{
		if ( isset( $sns[ $k ] ) AND $sns[ $k ] !== '' )
		{
			$stringToSign .= $k . "\n" . $sns[ $k ] . "\n";
		}
	}

	try
	{
		$pem = (string) \IPS\Http\Url::external( $sns['SigningCertURL'] )->request( \IPS\LONG_REQUEST_TIMEOUT )->get();
	}
	catch ( \Exception $e )
	{
		return FALSE;
	}

	$publicKey = @\openssl_pkey_get_public( $pem );
	if ( !$publicKey )
	{
		return FALSE;
	}

	$algo = ( isset( $sns['SignatureVersion'] ) AND $sns['SignatureVersion'] == '2' ) ? OPENSSL_ALGO_SHA256 : OPENSSL_ALGO_SHA1;
	return \openssl_verify( $stringToSign, \base64_decode( $sns['Signature'] ), $publicKey, $algo ) === 1;
}

/**
 * Odbicie z powodu wstrzymania konta SES (nie z winy odbiorcy)? Bez zależności od nowych metod Suppression —
 * serwer z nieodświeżonym OPcache może jeszcze trzymać starą wersję tej klasy.
 */
function awsses_sns_isAccountPause( string $subType, string $diag ): bool
{
	return \strcasecmp( $subType, 'AccountSuspended' ) === 0
		OR \stripos( $diag, 'Sending paused for this account' ) !== FALSE
		OR \stripos( $diag, 'Account suspended' ) !== FALSE;
}

/**
 * Wstrzymaj wysyłkę (zdarzenie „pause”); jedno zdarzenie na wstrzymanie
 */
function awsses_sns_pause( string $reason ): void
{
	if ( \method_exists( '\IPS\awsses\Suppression', 'pauseSending' ) )
	{
		\IPS\awsses\Suppression::pauseSending( $reason );
		return;
	}
	try
	{
		if ( \IPS\Db::i()->select( 'ev_type', 'awsses_events', array( "ev_type IN('pause','resume')" ), 'ev_id DESC', 1 )->first() === 'pause' ) { return; }
	}
	catch ( \UnderflowException $e ) {}
	\IPS\Db::i()->insert( 'awsses_events', array( 'ev_type' => 'pause', 'ev_ts' => \time(), 'ev_detail' => \mb_substr( \trim( $reason ), 0, 255 ) ) );
}

/**
 * Strażnik progów (automatyczne wstrzymanie). Błąd strażnika nie może zgubić zdarzenia SNS.
 */
function awsses_sns_guard( string $campaign ): void
{
	try
	{
		if ( $campaign !== '' AND \class_exists( '\IPS\awsses\Guard' ) )
		{
			\IPS\awsses\Guard::check( $campaign );
		}
	}
	catch ( \Throwable $e )
	{
		\IPS\Log::log( $e, 'awsses' );
	}
}

function awsses_sns_handleEvent( array $m ): void
{
	$type     = $m['eventType'] ?? ( $m['notificationType'] ?? '' );
	$config   = (string) ( $m['mail']['tags']['ses:configuration-set'][0] ?? '' );
	$campaign = (string) ( $m['mail']['tags']['campaign'][0] ?? '' );

	switch ( $type )
	{
		case 'Bounce':
			$bounceType = (string) ( $m['bounce']['bounceType'] ?? '' );
			$detail     = \trim( $bounceType . '/' . ( $m['bounce']['bounceSubType'] ?? '' ), '/' );
			foreach ( ( $m['bounce']['bouncedRecipients'] ?? array() ) as $r )
			{
				$addr = (string) ( $r['emailAddress'] ?? '' );
				if ( $addr !== '' )
				{
					/* Rodzaj + odpowiedź serwera odbiorcy (np. „550 5.1.1 user unknown”) — pokazywane w statystykach */
					$diag = \trim( \preg_replace( '/\s+/', ' ', (string) ( $r['diagnosticCode'] ?? '' ) ) );
					\IPS\awsses\Suppression::recordEvent( 'bounce', $addr, $config, $campaign, $diag !== '' ? $detail . ' | ' . $diag : $detail );

					/* AWS wstrzymał wysyłkę z konta — adres odbiorcy jest w porządku: NIE blokuj go, wstrzymaj wysyłkę */
					if ( awsses_sns_isAccountPause( (string) ( $m['bounce']['bounceSubType'] ?? '' ), $diag ) )
					{
						awsses_sns_pause( $diag !== '' ? $diag : $detail );
						continue;
					}

					if ( $bounceType === 'Permanent' )
					{
						\IPS\awsses\Suppression::suppress( $addr, 'bounce', 'Permanent: ' . ( $r['diagnosticCode'] ?? '' ) );
					}
				}
			}
			/* Odsetek twardych odbić w kampanii ponad próg → wstrzymaj, zanim zrobi to AWS */
			if ( $bounceType === 'Permanent' )
			{
				awsses_sns_guard( $campaign );
			}
			break;

		case 'Complaint':
			$detail = (string) ( $m['complaint']['complaintFeedbackType'] ?? '' );
			foreach ( ( $m['complaint']['complainedRecipients'] ?? array() ) as $r )
			{
				$addr = (string) ( $r['emailAddress'] ?? '' );
				if ( $addr !== '' )
				{
					\IPS\awsses\Suppression::recordEvent( 'complaint', $addr, $config, $campaign, $detail );
					\IPS\awsses\Suppression::suppress( $addr, 'complaint', $detail );
				}
			}
			awsses_sns_guard( $campaign );
			break;

		case 'Send':
		case 'Delivery':
		case 'Open':
		case 'Click':
		case 'Reject':
		case 'DeliveryDelay':
			$addr   = (string) ( $m['mail']['destination'][0] ?? '' );
			$detail = '';
			if ( $type === 'Click' )         { $detail = (string) ( $m['click']['link'] ?? '' ); }
			if ( $type === 'Reject' )        { $detail = (string) ( $m['reject']['reason'] ?? '' ); }
			if ( $type === 'DeliveryDelay' ) { $detail = (string) ( $m['deliveryDelay']['delayType'] ?? '' ); }
			\IPS\awsses\Suppression::recordEvent( \mb_strtolower( $type ), $addr, $config, $campaign, $detail );
			break;
	}
}

/* ---------- opcjonalny sekret ---------- */
$expectedToken = \IPS\Settings::i()->awsses_sns_token;
if ( $expectedToken )
{
	$given = isset( $_GET['t'] ) ? (string) $_GET['t'] : '';
	if ( !\hash_equals( $expectedToken, $given ) )
	{
		awsses_sns_fail( 403, 'forbidden' );
	}
}

/* ---------- odczyt / parsowanie ---------- */
$raw = \file_get_contents( 'php://input' );
if ( !$raw ) { awsses_sns_fail( 400, 'empty' ); }

$sns = \json_decode( $raw, TRUE );
if ( !\is_array( $sns ) OR !isset( $sns['Type'] ) ) { awsses_sns_fail( 400, 'bad json' ); }

/* ---------- weryfikacja podpisu ---------- */
if ( !awsses_sns_verify( $sns ) )
{
	\IPS\Log::log( 'AWS SNS: nieprawidłowy podpis', 'awsses_sns' );
	awsses_sns_fail( 403, 'bad signature' );
}

/* ---------- obsługa ---------- */
switch ( $sns['Type'] )
{
	case 'SubscriptionConfirmation':
	case 'UnsubscribeConfirmation':
		if ( isset( $sns['SubscribeURL'] ) AND awsses_sns_amazonHost( $sns['SubscribeURL'] ) )
		{
			try
			{
				\IPS\Http\Url::external( $sns['SubscribeURL'] )->request( \IPS\LONG_REQUEST_TIMEOUT )->get();
				\IPS\awsses\Suppression::recordEvent( 'subscription', '', '' );
			}
			catch ( \Exception $e ) { \IPS\Log::log( $e, 'awsses_sns' ); }
		}
		break;

	case 'Notification':
		$message = \json_decode( $sns['Message'] ?? '', TRUE );
		if ( \is_array( $message ) ) { awsses_sns_handleEvent( $message ); }
		break;
}

\http_response_code( 200 );
echo 'ok';
